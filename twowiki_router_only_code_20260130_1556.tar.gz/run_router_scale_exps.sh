#!/usr/bin/env bash
# 顺序跑路由器缩放实验：
# N = 1w, 2w, 5w, full
# E = 1, 2, 3, 5, 10
# 每次都：
#   1) 训练 router
#   2) 全量评测（limit<=0 视为全量；如果你的脚本不是这样写，可以改成删掉 --limit）
#   3) 备份 router 权重为 router_mlp_E{E}_N{TAG}.pt

set -euo pipefail

ROOT="/home/peiyu/router_only_best"
PYTHON="/home/peiyu/envs/brmog_gpu/bin/python"
DEVICE="6"
BUDGET="1024"

cd "$ROOT"

# 避免 PYTHONPATH 未定义导致错误
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"

mkdir -p logs

# 训练样本数：10000, 20000, 50000, full(-1 表示全量)
NS=(10000 20000 50000 -1)
# 训练轮数
ES=(1 2 3 5 10)

for N in "${NS[@]}"; do
  # N_TAG 用来区分 full/数字
  if [[ "$N" -gt 0 ]]; then
    N_TAG="$N"
    MAX_EX="--max_examples ${N}"
  else
    N_TAG="full"
    MAX_EX="--max_examples -1"
  fi

  for E in "${ES[@]}"; do
    echo "==============================="
    echo ">>> Train router: N=${N_TAG}, epochs=${E}"
    echo "==============================="

    TRAIN_LOG="logs/train_router_E${E}_N${N_TAG}.log"
    EVAL_LOG="logs/hotpot_dev_multi_router_only_B${BUDGET}_E${E}_N${N_TAG}_full.log"
    CKPT_SAVE="router_mlp_E${E}_N${N_TAG}.pt"

    # 1) 训练路由器
    CUDA_VISIBLE_DEVICES=${DEVICE} \
    "${PYTHON}" -m mog_rag.train_router \
      --device cuda \
      --epochs "${E}" \
      ${MAX_EX} \
      --topk_per_gran 32 \
      --temp 0.5 \
      > "${TRAIN_LOG}" 2>&1

    # 2) 备份当前 router 权重
    if [[ -f router_mlp.pt ]]; then
      cp router_mlp.pt "${CKPT_SAVE}"
    else
      echo "[WARN] router_mlp.pt 不存在，可能训练失败，请查看 ${TRAIN_LOG}"
    fi

    # 3) 全量评测（不使用预算器）
    echo ">>> Evaluate router: N=${N_TAG}, epochs=${E} (full dev)"
    CUDA_VISIBLE_DEVICES=${DEVICE} \
    USE_ROUTER=1 USE_BUDGET=0 CTX_BUDGET=${BUDGET} \
    "${PYTHON}" -m mog_rag.evaluate_hotpot \
      --limit 0 \
      > "${EVAL_LOG}" 2>&1

    # 打印一下结果行
    echo ">>> Result summary (from ${EVAL_LOG}):"
    grep "\[RESULT\]" "${EVAL_LOG}" || echo "[WARN] 未找到 [RESULT] 行，请检查日志。"
    echo
  done
done

echo "所有 router 缩放实验已跑完。权重文件和日志见 logs/ 和 router_mlp_E*_N*.pt"
