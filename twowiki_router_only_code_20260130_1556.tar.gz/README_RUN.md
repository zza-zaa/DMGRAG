# MoG-RAG v2 Router+Budgeter Patch (Policy Router + Budgeted Selector)

## Files included (copy into your repo)
- mog_rag/policies.py (NEW)
- mog_rag/router.py (REPLACE)
- mog_rag/budgeter_runtime.py (REPLACE)
- mog_rag/rag_pipeline.py (REPLACE)
- mog_rag/build_oracle_labels.py (REPLACE)
- mog_rag/train_router_from_oracle.py (REPLACE/NEW)
- mog_rag/train_budget_scorer_from_oracle.py (REPLACE/NEW)

## 0) In your repo
Assume repo root:
`/mnt/raid/peiyu/twowiki_router_only`

Copy the files above to:
`/mnt/raid/peiyu/twowiki_router_only/mog_rag/`
(overwrite existing ones; keep a backup).

## 1) Build oracle labels (recommended)
### Example: 2wiki, train split, budgets match your CTX_BUDGET range
```bash
CUDA_VISIBLE_DEVICES=0 \
PYTHONPATH=/mnt/raid/peiyu/twowiki_router_only:$PYTHONPATH \
LLM_PATH=/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct \
DATASET_NAME=2wiki \
ORACLE_BUDGETS=1024,2048,3072,4096,5200 \
STAGE1_TOTAL_TOPK=160 RERANK_TOP_M=160 TOTAL_TOPK=120 USE_RERANKER=0 \
/mnt/raid/peiyu/envs/brmog_gpu/bin/python -m mog_rag.build_oracle_labels \
  --split train --limit 20000 \
  --out data/oracle_policy_train_v2.jsonl
```

## 2) Train the router (policy distillation)
```bash
CUDA_VISIBLE_DEVICES=0 \
PYTHONPATH=/mnt/raid/peiyu/twowiki_router_only:$PYTHONPATH \
DATASET_NAME=2wiki \
EMB_MODEL_PATH=/mnt/raid/peiyu/models/bge-large-en-v1.5 \
/mnt/raid/peiyu/envs/brmog_gpu/bin/python -m mog_rag.train_router_from_oracle \
  --oracle data/oracle_policy_train_v2.jsonl \
  --out ckpts/router_policy_v2.pt \
  --epochs 3 --batch_size 128 --lr 2e-4
```

## 3) Train the budget scorer (BudgetRegressor)
```bash
CUDA_VISIBLE_DEVICES=0 \
PYTHONPATH=/mnt/raid/peiyu/twowiki_router_only:$PYTHONPATH \
LLM_PATH=/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct \
DATASET_NAME=2wiki \
/mnt/raid/peiyu/envs/brmog_gpu/bin/python -m mog_rag.train_budget_scorer_from_oracle \
  --oracle data/oracle_policy_train_v2.jsonl \
  --out budget_regressor_v2.pt \
  --epochs 2 --lr 2e-4 --accum 8 \
  --retrieval_split train --stage1_topk 160 --rerank_top_m 160 --total_topk 120
```

## 4) Evaluate full pipeline
```bash
CUDA_VISIBLE_DEVICES=0 \
PYTHONPATH=/mnt/raid/peiyu/twowiki_router_only:$PYTHONPATH \
LLM_PATH=/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct \
DATASET_NAME=2wiki \
USE_ROUTER=1 USE_BUDGETER=1 \
ROUTER_CKPT=/mnt/raid/peiyu/twowiki_router_only/ckpts/router_policy_v2.pt \
BUDGETER_CKPT=/mnt/raid/peiyu/twowiki_router_only/budget_regressor_v2.pt \
CTX_BUDGET=5200 TOTAL_TOPK=100 STAGE1_TOTAL_TOPK=160 RERANK_TOP_M=160 \
USE_RERANKER=0 \
/mnt/raid/peiyu/envs/brmog_gpu/bin/python -m mog_rag.evaluate_hotpot \
  --split dev --limit 1500 \
  > logs/dev_router_budgeter_v2_CTX5200_L1500.log 2>&1
```

### Notes
- If you want the budgeter to use the learned scorer more strongly:
  `export BUDGETER_W_LEARNED=0.8` (default is moderate).
- Router policy set can be overridden by env `ROUTER_POLICIES`, but default is already good.
