#!/usr/bin/env bash
set -e

# 修改成你要跑实验的目录（new_gpu / new_gpu_baseline_v1 均可）
WORKDIR=/home/peiyu/new_gpu_baseline_v1
cd "$WORKDIR"

# 防止 set -u 时 PYTHONPATH 未定义报错
export PYTHONPATH="$WORKDIR:${PYTHONPATH:-}"

run_exp () {
  local gran_mode="$1"   # sent-only / para-only / doc-only
  local log_name="$2"    # 日志文件名

  echo "====== Running GRAN_MODE=${gran_mode}, log=${log_name} ======"

  CUDA_VISIBLE_DEVICES=6 \
  GRAN_MODE="${gran_mode}" \
  USE_ROUTER=0 \
  USE_BUDGET=0 \
  CTX_BUDGET=1024 \
  /home/peiyu/envs/brmog_gpu/bin/python -m mog_rag.evaluate_hotpot \
    > "logs/${log_name}" 2>&1

  echo "------ RESULT from logs/${log_name} ------"
  grep "\[RESULT\]" "logs/${log_name}" || echo "No [RESULT] line found."
  echo
}

# 1) 仅句子级 sent-only，全量 dev
run_exp sent-only hotpot_dev_sent_plain_B1024_full.log

# 2) 仅段落级 para-only，全量 dev
run_exp para-only hotpot_dev_para_plain_B1024_full.log

# 3) 仅文档级 doc-only，全量 dev
run_exp doc-only hotpot_dev_doc_plain_B1024_full.log
