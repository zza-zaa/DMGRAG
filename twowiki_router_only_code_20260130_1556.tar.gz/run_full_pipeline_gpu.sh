#!/usr/bin/env bash
set -e

cd /home/peiyu/new
source /home/peiyu/envs/brmog/bin/activate

# 可选：只需要跑一次的就注释掉
# echo "==== Step 1: Build Hotpot multi-granularity chunks ===="
# python -m mog_rag.hotpot_chunking

# echo "==== Step 2: Build train/dev indices ===="
# python -m mog_rag.hotpot_index

echo "==== Step 3: Train granularity router on GPU0 ===="
CUDA_VISIBLE_DEVICES=0 python -m mog_rag.train_router &

echo "==== Step 4: Train budget regressor on GPU1 ===="
CUDA_VISIBLE_DEVICES=1 python -m mog_rag.train_budget_regressor &

# 等这两个训练都结束
wait

echo "==== Step 5: Evaluate RAG on Hotpot dev using 8 GPUs for Qwen ===="
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python -m mog_rag.evaluate_hotpot

echo "==== ALL DONE ===="
