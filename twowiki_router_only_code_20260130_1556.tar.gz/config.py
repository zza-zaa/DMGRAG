from __future__ import annotations
from pathlib import Path
import os

"""
项目配置文件（已适配 /mnt/raid/peiyu/router_only_best 目录布局）

约定：
- 项目根目录：/mnt/raid/peiyu/router_only_best
- 数据根目录：/mnt/raid/peiyu/data
- 模型根目录：/mnt/raid/peiyu/models

如需在别的机器或路径下复用，优先通过环境变量 PEIYU_ROOT 覆盖：
    export PEIYU_ROOT=/mnt/raid/peiyu
"""

# -----------------------------------------------------------------------------
# 1. 根路径设置
# -----------------------------------------------------------------------------

# 项目根目录：自动推断为当前文件的上一级目录（mog_rag 的父目录）
PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]

# 用户主目录（数据 & 模型所在位置）
# 默认是 /mnt/raid/peiyu，如有变化可以：
#   export PEIYU_ROOT=/your/new/root
PEIYU_ROOT: Path = Path(os.getenv("PEIYU_ROOT", "/mnt/raid/peiyu")).resolve()

# 数据 & 模型根目录
DATA_ROOT: Path = PEIYU_ROOT / "data"
MODEL_ROOT: Path = PEIYU_ROOT / "models"

# -----------------------------------------------------------------------------
# 2. HotpotQA 数据路径
# -----------------------------------------------------------------------------

# Hotpot 训练集和 dev 集
HOTPOT_TRAIN: Path = DATA_ROOT / "hotpot" / "hotpot_train_v1.1.json"
HOTPOT_DEV: Path = DATA_ROOT / "hotpot" / "hotpot_dev_distractor_v1.json"

# 如果之后要扩展到其它数据集（2Wiki、Musique 等），可以在这里继续加：
# TWO_WIKI_TRAIN  = DATA_ROOT / "2wiki" / "train.json"
# TWO_WIKI_DEV    = DATA_ROOT / "2wiki" / "dev.json"
# MUSIQUE_TRAIN   = DATA_ROOT / "musique" / "train.json"
# MUSIQUE_DEV     = DATA_ROOT / "musique" / "dev.json"

# -----------------------------------------------------------------------------
# 3. 索引路径（FAISS indices）
# -----------------------------------------------------------------------------

# Hotpot 索引目录：
#   /mnt/raid/peiyu/router_only_best/indices/hotpot/{split}/{gran}/index.faiss
#   /mnt/raid/peiyu/router_only_best/indices/hotpot/{split}/{gran}/meta.jsonl
INDEX_DIR: Path = PROJECT_ROOT / "indices" / "hotpot"

# 如果将来给 2Wiki 等单独建索引，也可以：
# TWO_WIKI_INDEX_DIR = PROJECT_ROOT / "indices" / "2wiki"
# MUSIQUE_INDEX_DIR  = PROJECT_ROOT / "indices" / "musique"

# -----------------------------------------------------------------------------
# 4. 模型路径：LLM / Embedding / Reranker
# -----------------------------------------------------------------------------

# LLM：Qwen2.5-14B-Instruct
LLM_MODEL_PATH: Path = MODEL_ROOT / "Qwen2.5-14B-Instruct"

# Dense embedding：bge-large-en-v1.5
EMB_MODEL_PATH: Path = MODEL_ROOT / "bge-large-en-v1.5"

# Cross-encoder reranker：bge-reranker-large
RERANKER_MODEL_PATH: Path = MODEL_ROOT / "bge-reranker-large"

# -----------------------------------------------------------------------------
# 5. 粒度与上下文预算等超参数
# -----------------------------------------------------------------------------

# 粒度列表的“唯一真源头”，所有地方都按这个顺序：
# id: 0 -> "sent", 1 -> "para", 2 -> "doc"
GRANULARITIES = ("sent", "para", "doc")

# 默认上下文 budget（token 级），可以被环境变量 CTX_BUDGET 覆盖
#   export CTX_BUDGET=1024
DEFAULT_MAX_CONTEXT_TOKENS = 1024

def _get_max_ctx_from_env() -> int:
    v = os.getenv("CTX_BUDGET")
    if v is None:
        return DEFAULT_MAX_CONTEXT_TOKENS
    try:
        x = int(v)
        if x > 0:
            return x
    except Exception:
        pass
    return DEFAULT_MAX_CONTEXT_TOKENS

MAX_CONTEXT_TOKENS: int = _get_max_ctx_from_env()

# -----------------------------------------------------------------------------
# 6. 一些小工具：打印当前配置（调试用）
# -----------------------------------------------------------------------------

def print_config() -> None:
    print("=== mog_rag.config 当前配置 ===")
    print(f"PROJECT_ROOT      = {PROJECT_ROOT}")
    print(f"PEIYU_ROOT        = {PEIYU_ROOT}")
    print(f"DATA_ROOT         = {DATA_ROOT}")
    print(f"MODEL_ROOT        = {MODEL_ROOT}")
    print()
    print(f"HOTPOT_TRAIN      = {HOTPOT_TRAIN}  (exists={HOTPOT_TRAIN.exists()})")
    print(f"HOTPOT_DEV        = {HOTPOT_DEV}    (exists={HOTPOT_DEV.exists()})")
    print(f"INDEX_DIR         = {INDEX_DIR}     (exists={INDEX_DIR.exists()})")
    print()
    print(f"LLM_MODEL_PATH    = {LLM_MODEL_PATH}    (exists={LLM_MODEL_PATH.exists()})")
    print(f"EMB_MODEL_PATH    = {EMB_MODEL_PATH}    (exists={EMB_MODEL_PATH.exists()})")
    print(f"RERANKER_MODEL_PATH = {RERANKER_MODEL_PATH} (exists={RERANKER_MODEL_PATH.exists()})")
    print()
    print(f"GRANULARITIES     = {GRANULARITIES}")
    print(f"MAX_CONTEXT_TOKENS= {MAX_CONTEXT_TOKENS}")
    print("================================")


if __name__ == "__main__":
    # 方便你在命令行直接检查配置是否写对
    print_config()
