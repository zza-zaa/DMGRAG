# mog_rag/router.py
from __future__ import annotations
from dataclasses import dataclass
from typing import List

import torch
import torch.nn as nn

from .config import GRANULARITIES

@dataclass
class RouterOutput:
    probs: torch.Tensor            # [G] for single query OR [B,G] for batch
    granularity_order: List[str]   # config order

class GranularityRouter(nn.Module):
    """
    Router = lightweight MLP.
    Input: query embedding (from retriever emb_model) + 4 extra features.
    """

    def __init__(self, emb_dim: int, hidden_size: int = 512):
        super().__init__()
        input_dim = emb_dim + 4
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, len(GRANULARITIES)),
        )

    def _feat(self, v, B: int, device, norm: float = 1.0) -> torch.Tensor:
        """
        Make a feature tensor with shape [B,1] on device.
        v can be scalar / int / float / tensor.
        """
        if isinstance(v, torch.Tensor):
            t = v.to(device).float()
            if t.dim() == 0:
                t = t.view(1, 1).expand(B, 1)
            elif t.dim() == 1:
                # [B] or [1]
                if t.numel() == 1:
                    t = t.view(1, 1).expand(B, 1)
                else:
                    t = t.view(-1, 1)
                    if t.size(0) != B:
                        # fallback: broadcast first value
                        t = t[:1].expand(B, 1)
            elif t.dim() >= 2:
                # take first column if needed
                t = t.view(t.size(0), -1)[:, :1]
                if t.size(0) != B:
                    t = t[:1].expand(B, 1)
        else:
            t = torch.full((B, 1), float(v), dtype=torch.float32, device=device)
        if norm != 0.0:
            t = t / float(norm)
        return t

    def forward(
        self,
        q_emb: torch.Tensor,             # [d] / [1,d] / [B,d]
        budget_tokens: int,
        q_len_chars: int = 0,
        hop_feat: float = 0.0,
        type_feat: float = 0.0,
        budget_norm: float = 2048.0,
        qlen_norm: float = 256.0,
    ) -> RouterOutput:
        # Normalize q_emb to [B, d]
        single = False
        if q_emb.dim() == 1:
            q_emb = q_emb.unsqueeze(0)
            single = True
        elif q_emb.dim() == 2 and q_emb.size(0) == 1:
            single = True

        q_emb = q_emb.float()
        B = q_emb.size(0)
        device = q_emb.device

        # Build extra features as [B,4]
        f_budget = self._feat(budget_tokens, B, device, norm=budget_norm)   # [B,1]
        f_qlen   = self._feat(q_len_chars,  B, device, norm=qlen_norm)      # [B,1]
        f_hop    = self._feat(hop_feat,     B, device, norm=1.0)            # [B,1]
        f_type   = self._feat(type_feat,    B, device, norm=1.0)            # [B,1]
        extra = torch.cat([f_budget, f_qlen, f_hop, f_type], dim=1)          # [B,4]

        x = torch.cat([q_emb, extra], dim=1)                                # [B,d+4]
        logits = self.mlp(x)                                                # [B,G]
        probs = torch.softmax(logits, dim=-1)                               # [B,G]

        if single:
            probs = probs.squeeze(0)                                        # [G]

        return RouterOutput(probs=probs, granularity_order=list(GRANULARITIES))
