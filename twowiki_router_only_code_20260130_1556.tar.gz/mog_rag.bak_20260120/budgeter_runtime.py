# mog_rag/budgeter_runtime.py
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

from .config import MAX_CONTEXT_TOKENS


@dataclass
class BudgetOutput:
    budget_tokens: int
    share: Dict[str, float]   # doc/para/sent


class BudgetRegressor(nn.Module):
    """
    输入：q_emb + 4个额外特征（budget_norm, q_len, hop_feat, type_feat）
    输出：
      - budget bucket logits
      - gran share logits (doc/para/sent)
    """
    def __init__(self, emb_dim: int, hidden: int = 512, num_buckets: int = 5, num_grans: int = 3):
        super().__init__()
        in_dim = emb_dim + 4
        self.trunk = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
        )
        self.bucket_head = nn.Linear(hidden, num_buckets)
        self.share_head = nn.Linear(hidden, num_grans)

    def forward(
        self,
        q_emb: torch.Tensor,  # [d] or [1,d]
        budget_tokens: int,
        q_len_chars: int,
        hop_feat: float,
        type_feat: float,
        budget_norm: float = 2048.0,
        qlen_norm: float = 256.0,
    ):
        if q_emb.dim() == 2:
            q_emb = q_emb.squeeze(0)
        q_emb = q_emb.float()

        extra = torch.tensor(
            [
                float(budget_tokens) / float(budget_norm),
                float(q_len_chars) / float(qlen_norm),
                float(hop_feat),
                float(type_feat),
            ],
            dtype=torch.float32,
            device=q_emb.device,
        )
        x = torch.cat([q_emb, extra], dim=-1)
        h = self.trunk(x)
        return self.bucket_head(h), self.share_head(h)


class BudgeterRuntime:
    def __init__(self, emb_dim: int, device: torch.device, ckpt_path: str = "budget_mlp.pt"):
        self.device = device
        self.buckets: List[int] = [512, 768, 1024, 1536, 2048]
        self.model = BudgetRegressor(emb_dim=emb_dim, hidden=512, num_buckets=len(self.buckets), num_grans=3).to(device)

        ckpt = Path(ckpt_path)
        self.has_ckpt = ckpt.exists()
        if self.has_ckpt:
            state = torch.load(str(ckpt), map_location="cpu")
            ms = self.model.state_dict()
            filtered = {k: v for k, v in state.items() if k in ms and v.shape == ms[k].shape}
            self.model.load_state_dict(filtered, strict=False)

    def predict(
        self,
        q_emb_np: np.ndarray,       # [1,d]
        default_budget: int,
        q_len_chars: int,
        hop_feat: float,
        type_feat: float,
    ) -> BudgetOutput:
        if not self.has_ckpt:
            return BudgetOutput(
                budget_tokens=int(default_budget),
                share={"doc": 1/3, "para": 1/3, "sent": 1/3},
            )

        q_emb_t = torch.from_numpy(q_emb_np).to(self.device)
        with torch.no_grad():
            bucket_logits, share_logits = self.model(
                q_emb=q_emb_t,
                budget_tokens=int(default_budget),
                q_len_chars=int(q_len_chars),
                hop_feat=float(hop_feat),
                type_feat=float(type_feat),
                budget_norm=float(MAX_CONTEXT_TOKENS),
                qlen_norm=256.0,
            )
        bucket_probs = torch.softmax(bucket_logits, dim=-1).detach().float().cpu().numpy()
        share_probs = torch.softmax(share_logits, dim=-1).detach().float().cpu().numpy()

        b_idx = int(np.argmax(bucket_probs))
        budget_tokens = int(self.buckets[max(0, min(b_idx, len(self.buckets)-1))])

        share = {"doc": float(share_probs[0]), "para": float(share_probs[1]), "sent": float(share_probs[2])}
        s = sum(share.values())
        if s > 0:
            share = {k: v / s for k, v in share.items()}
        else:
            share = {"doc": 1/3, "para": 1/3, "sent": 1/3}

        return BudgetOutput(budget_tokens=budget_tokens, share=share)
