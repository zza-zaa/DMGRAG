# mog_rag/utils.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional
from pathlib import Path
import json
import re

# --------- generic loader ---------
def load_json_or_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    if path.suffix == ".jsonl":
        out = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        return out
    with path.open("r", encoding="utf-8") as f:
        obj = json.load(f)
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict) and "data" in obj and isinstance(obj["data"], list):
        return obj["data"]
    raise ValueError(f"Unrecognized json format: {path}")

def load_hotpot(path: Path) -> List[Dict[str, Any]]:
    # 保留旧函数名，内部做通用加载
    return load_json_or_jsonl(Path(path))

# --------- answer extraction (2wiki/hotpot compatible) ---------
def get_answer(ex: Dict[str, Any]) -> str:
    # Hotpot: "answer"
    if "answer" in ex and isinstance(ex["answer"], str):
        return ex["answer"].strip()
    # Some datasets: "answers": [...]
    if "answers" in ex:
        ans = ex["answers"]
        if isinstance(ans, list) and ans:
            if isinstance(ans[0], str):
                return ans[0].strip()
            if isinstance(ans[0], dict) and "text" in ans[0]:
                return str(ans[0]["text"]).strip()
        if isinstance(ans, str):
            return ans.strip()
    # Some formats: "output"
    if "output" in ex and isinstance(ex["output"], str):
        return ex["output"].strip()
    return ""

# --------- evidence extraction (best-effort) ---------
def get_supporting_facts(ex: Dict[str, Any]) -> List[Tuple[str, int]]:
    """
    Return list of (title, sent_id). Works for Hotpot; for 2Wiki we best-effort parse.
    """
    # Hotpot format: list of [title, sent_id]
    sf = ex.get("supporting_facts", None)
    if isinstance(sf, list) and sf:
        out: List[Tuple[str, int]] = []
        for item in sf:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                title = str(item[0])
                try:
                    sid = int(item[1])
                except Exception:
                    continue
                out.append((title, sid))
            elif isinstance(item, dict):
                title = str(item.get("title", ""))
                sid = item.get("sent_id", item.get("sentence_id", None))
                if title and sid is not None:
                    try:
                        out.append((title, int(sid)))
                    except Exception:
                        pass
        return out

    # 2Wiki-like possible keys (very heterogeneous)
    for key in ["evidence", "supporting_sentences", "supports", "supporting"]:
        ev = ex.get(key, None)
        if isinstance(ev, list) and ev:
            out: List[Tuple[str, int]] = []
            for item in ev:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    title = str(item[0])
                    try:
                        sid = int(item[1])
                    except Exception:
                        continue
                    out.append((title, sid))
                elif isinstance(item, dict):
                    title = str(item.get("title", ""))
                    sid = item.get("sent_id", item.get("sentence_id", None))
                    if title and sid is not None:
                        try:
                            out.append((title, int(sid)))
                        except Exception:
                            pass
            if out:
                return out

    return []

# --------- normalization helpers ---------
def _norm_text(s: str) -> str:
    s = s.lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s

def _norm_answer(a: str) -> str:
    a = _norm_text(a)
    # strip punctuation-ish
    a = re.sub(r"[\"'`.,;:!?()\[\]{}]", " ", a)
    a = re.sub(r"\s+", " ", a).strip()
    return a

# --------- overlap between a chunk meta and evidence ---------
def chunk_support_overlap(meta: Dict[str, Any], supporting_facts: List[Tuple[str, int]]) -> Tuple[int, int]:
    """
    Return (covered_count, total_support).
    Meta schema is best-effort:
    - title in meta["title"]
    - sentence id may be meta["sent_id"] OR meta["sent_ids"] OR meta["sentence_id"]...
    """
    if not supporting_facts:
        return 0, 0

    title = str(meta.get("title", ""))
    if not title:
        return 0, len(supporting_facts)

    # candidate sent ids
    sent_id = meta.get("sent_id", meta.get("sentence_id", None))
    sent_ids = meta.get("sent_ids", meta.get("sentence_ids", None))

    covered = 0
    if sent_id is not None:
        try:
            sid = int(sent_id)
        except Exception:
            sid = None
        if sid is not None:
            for t, s in supporting_facts:
                if t == title and s == sid:
                    covered += 1
    elif isinstance(sent_ids, list):
        try:
            sid_set = set(int(x) for x in sent_ids)
        except Exception:
            sid_set = set()
        for t, s in supporting_facts:
            if t == title and s in sid_set:
                covered += 1
    else:
        # doc-level fallback: if title matches any evidence title, count all those
        ev_titles = [t for (t, _) in supporting_facts]
        if title in ev_titles:
            covered = sum(1 for (t, _) in supporting_facts if t == title)

    return covered, len(supporting_facts)

# --------- answer-in-chunk heuristic (for 2Wiki teacher) ---------
def answer_in_chunk(answer: str, chunk_text: str) -> bool:
    a = _norm_answer(answer)
    if not a:
        return False
    t = _norm_text(chunk_text)
    return a in _norm_answer(t)
