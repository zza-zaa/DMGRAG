from __future__ import annotations

import os
import re
import inspect
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .retrieval import MultiGranRetriever, RetrievedChunk

try:
    from .config import MAX_CONTEXT_TOKENS as _DEFAULT_CTX_BUDGET
except Exception:
    _DEFAULT_CTX_BUDGET = 2048


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, str(int(default))).strip().lower()
    return v in ("1", "true", "yes", "y", "on")


def _env_int(name: str, default: int) -> int:
    v = os.getenv(name, str(default)).strip()
    try:
        return int(v)
    except Exception:
        return default


def _clean_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def _norm_text_for_dedup(s: str) -> str:
    s = _clean_spaces(s).lower()
    s = s.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
    return s


class HotpotRAGPipeline:
    """
    兼容 evaluate_*：
    - answer(question, debug=True) -> (pred, debug_dict)
    """

    def __init__(self, split: Optional[str] = None, llm_path: Optional[str] = None) -> None:
        self.split = split or os.getenv("SPLIT", "dev").strip()

        # ===== Switches =====
        self.use_router = _env_bool("USE_ROUTER", False)
        self.use_budgeter = _env_bool("USE_BUDGETER", False) or _env_bool("USE_BUDGET", False)

        # ===== Device（router/budgeter 用；LLM 用 device_map="auto"）=====
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # ===== Retriever（保持原 pipeline）=====
        use_reranker = _env_bool("USE_RERANKER", False)
        self.retriever = MultiGranRetriever(split=self.split, use_reranker=use_reranker, router=None)

        # ===== LLM =====
        self.llm_path = llm_path or os.getenv("LLM_PATH", "").strip()
        if not self.llm_path:
            raise RuntimeError(
                "请设置环境变量 LLM_PATH，例如：\n"
                "export LLM_PATH=/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct"
            )

        # tokenizer：加 fallback，避免某些 qwen 目录 fast tokenizer 坏掉时报错
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True)
        except Exception:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True, use_fast=False)

        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        torch_dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            self.llm_path,
            torch_dtype=torch_dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()

        # ===== Router（仅增加：不改其它逻辑）=====
        self.router = None
        if self.use_router:
            from .router import GranularityRouter

            qdim = int(self.retriever._encode_query("dummy").shape[1])

            router_ckpt = os.getenv("ROUTER_CKPT", "router_mlp.pt").strip()
            hidden = _env_int("ROUTER_HIDDEN", 512)
            extra_dim = _env_int("ROUTER_EXTRA_DIM", 4)  # 你 router.py 默认 4

            # 1) 若 ckpt 存在：尽量从 ckpt 推断 hidden/extra_dim（减少 missing/unexpected）
            if router_ckpt and Path(router_ckpt).exists():
                try:
                    st = torch.load(router_ckpt, map_location="cpu")
                    if isinstance(st, dict) and "state_dict" in st and isinstance(st["state_dict"], dict):
                        st = st["state_dict"]

                    w = None
                    if isinstance(st, dict):
                        if "mlp.0.weight" in st and hasattr(st["mlp.0.weight"], "shape"):
                            w = st["mlp.0.weight"]
                        else:
                            for k, v in st.items():
                                if k.endswith(".0.weight") and hasattr(v, "shape") and v.ndim == 2:
                                    w = v
                                    break
                    if w is not None:
                        hidden = int(w.shape[0])
                        in_feat = int(w.shape[1])
                        extra_dim = max(0, in_feat - qdim)
                except Exception:
                    pass

            # 2) **关键修复**：不硬编码参数名，按 __init__ 签名只传它支持的 kwargs
            sig = inspect.signature(GranularityRouter.__init__)
            params = sig.parameters

            args = []
            kwargs: Dict[str, Any] = {}

            # 输入维：emb_dim / input_dim / dim / d_model / in_dim（都可能）
            if "emb_dim" in params:
                kwargs["emb_dim"] = qdim
            elif "input_dim" in params:
                kwargs["input_dim"] = qdim
            elif "dim" in params:
                kwargs["dim"] = qdim
            elif "d_model" in params:
                kwargs["d_model"] = qdim
            elif "in_dim" in params:
                kwargs["in_dim"] = qdim
            else:
                # 退化：第一个位置参数通常就是输入维
                args.append(qdim)

            # hidden：hidden_size / hidden / hid / mlp_hidden
            if "hidden_size" in params:
                kwargs["hidden_size"] = hidden
            elif "hidden" in params:
                kwargs["hidden"] = hidden
            elif "hid" in params:
                kwargs["hid"] = hidden
            elif "mlp_hidden" in params:
                kwargs["mlp_hidden"] = hidden

            # extra_dim
            if "extra_dim" in params:
                kwargs["extra_dim"] = extra_dim
            elif "extra" in params:
                kwargs["extra"] = extra_dim

            # 输出维：有的 router 固定 3 类，不需要传；如果它支持就传 3
            for name in ["out_dim", "num_gran", "n_gran", "num_classes", "n_classes", "output_dim"]:
                if name in params:
                    kwargs[name] = 3
                    break

            self.router = GranularityRouter(*args, **kwargs).to(self.device)

            # 3) load ckpt（只加载 shape 对得上的 key，避免 strict 崩）
            if router_ckpt and Path(router_ckpt).exists():
                st = torch.load(router_ckpt, map_location="cpu")
                if isinstance(st, dict) and "state_dict" in st and isinstance(st["state_dict"], dict):
                    st = st["state_dict"]

                model_state = self.router.state_dict()
                filtered = {}
                if isinstance(st, dict):
                    for k, v in st.items():
                        if k in model_state and hasattr(v, "shape") and v.shape == model_state[k].shape:
                            filtered[k] = v
                missing, unexpected = self.router.load_state_dict(filtered, strict=False)
                print(f"[Router] loaded ckpt={router_ckpt} missing={len(missing)} unexpected={len(unexpected)}")
            else:
                print(f"[Router] ckpt not found: {router_ckpt} (router uses random init)")

            # 挂到 retriever：让 retrieve_multi_gran 内部按 router 分配 topk
            self.retriever.router = self.router

        # ===== Budgeter（仅增加）=====
        self.budgeter = None
        if self.use_budgeter:
            from .budgeter_runtime import BudgeterRuntime

            qdim = int(self.retriever._encode_query("dummy").shape[1])
            budget_ckpt = os.getenv("BUDGETER_CKPT", os.getenv("BUDGET_CKPT", "budgeter_mlp.pt")).strip()
            self.budgeter = BudgeterRuntime(
                emb_dim=qdim,
                device=("cuda" if torch.cuda.is_available() else "cpu"),
                ckpt_path=(budget_ckpt if budget_ckpt else None),
                debug=_env_bool("BUDGETER_DEBUG", False),
            )

    # ----------------------------
    # Context packing（保持原逻辑）
    # ----------------------------
    def _chunk_to_ctx_block(self, c: RetrievedChunk, idx: int) -> str:
        title = _clean_spaces(c.title)
        text = _clean_spaces(c.text)
        return f"[{idx}][{c.granularity}] title={title}\n{text}"

    def _count_tokens(self, s: str) -> int:
        return int(len(self.tokenizer.encode(s, add_special_tokens=False)))

    def _effective_ctx_budget(self, req_budget: int, max_new_tokens: int) -> int:
        model_max = int(getattr(self.tokenizer, "model_max_length", 0) or 0)
        if model_max <= 0 or model_max > 10**7:
            model_max = int(getattr(self.model.config, "max_position_embeddings", 8192) or 8192)
        safety_margin = _env_int("PROMPT_SAFETY_MARGIN", 512)
        eff = model_max - max_new_tokens - safety_margin
        eff = max(256, eff)
        return min(req_budget, eff)

    def _dedup_chunks(self, chunks: List[RetrievedChunk]) -> Tuple[List[RetrievedChunk], int]:
        seen = set()
        out = []
        removed = 0
        for c in chunks:
            key = _norm_text_for_dedup(c.text)
            if not key:
                continue
            if key in seen:
                removed += 1
                continue
            seen.add(key)
            out.append(c)
        return out, removed

    def _rank_score(self, c: RetrievedChunk) -> float:
        if getattr(c, "rerank_score", 0.0) and float(c.rerank_score) != 0.0:
            return float(c.rerank_score)
        return float(c.dense_score)

    def _pack_context(
        self,
        candidates: List[RetrievedChunk],
        ctx_budget: int,
        max_ctx_chunks: int,
    ) -> Tuple[List[RetrievedChunk], Dict[str, int]]:
        cand_sorted = sorted(candidates, key=self._rank_score, reverse=True)
        selected: List[RetrievedChunk] = []
        stats: Dict[str, int] = {}
        used = 0
        for c in cand_sorted:
            if len(selected) >= max_ctx_chunks:
                break
            block = self._chunk_to_ctx_block(c, idx=len(selected) + 1)
            t = self._count_tokens(block) + 2
            if used + t > ctx_budget:
                continue
            selected.append(c)
            used += t
            stats[c.granularity] = stats.get(c.granularity, 0) + t
        return selected, stats

    # ----------------------------
    # Prompt + Generation（保持原逻辑）
    # ----------------------------
    def _build_messages(self, question: str, ctx_blocks: str) -> List[Dict[str, str]]:
        strict = _env_bool("STRICT_CONTEXT", False)
        system = (
            "You are a question answering assistant. "
            "Answer with a short span (entity / name / place / date)."
        )
        if strict:
            instr = (
                "Use ONLY the provided context to answer. "
                "If the answer is not present, output unknown."
            )
        else:
            instr = (
                "Use the provided context as primary evidence. "
                "If the context is insufficient, make your best guess."
            )
        user = (
            f"{instr}\n\n"
            f"Question:\n{question}\n\n"
            f"Context:\n{ctx_blocks}\n\n"
            f"Answer (only the answer string):"
        )
        return [{"role": "system", "content": system}, {"role": "user", "content": user}]

    def _generate(self, messages: List[Dict[str, str]]) -> str:
        max_new_tokens = _env_int("MAX_NEW_TOKENS", 64)
        do_sample = _env_bool("DO_SAMPLE", False)
        num_beams = _env_int("NUM_BEAMS", 1)
        temperature = float(os.getenv("TEMPERATURE", "0.7"))
        top_p = float(os.getenv("TOP_P", "0.9"))
        top_k = _env_int("TOP_K", 50)

        prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)

        gen_kwargs: Dict[str, Any] = dict(
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            num_beams=num_beams,
            eos_token_id=self.tokenizer.eos_token_id,
            pad_token_id=self.tokenizer.pad_token_id,
        )
        if do_sample and num_beams == 1:
            gen_kwargs.update(dict(temperature=temperature, top_p=top_p, top_k=top_k))

        with torch.inference_mode():
            out = self.model.generate(**inputs, **gen_kwargs)

        new_tokens = out[0, inputs["input_ids"].shape[1]:]
        text = self.tokenizer.decode(new_tokens, skip_special_tokens=True)
        return text.strip()

    def _postprocess_answer(self, s: str) -> str:
        s = (s or "").strip()
        if not s:
            return "unknown"
        s = s.splitlines()[0].strip()
        s = re.sub(r"^(answer\s*[:\-]\s*)", "", s, flags=re.IGNORECASE).strip()
        s = s.strip().strip('"').strip("'").strip()
        s = re.sub(r"^(only the answer string[:\-]?\s*)", "", s, flags=re.IGNORECASE).strip()
        if len(s) <= 1:
            return "unknown"
        return s

    # ----------------------------
    # Public API
    # ----------------------------
    def answer(self, question: str, debug: bool = False) -> Tuple[str, Dict[str, Any]]:
        question = _clean_spaces(question)

        req_budget = _env_int("CTX_BUDGET", int(_DEFAULT_CTX_BUDGET))
        max_new_tokens = _env_int("MAX_NEW_TOKENS", 64)
        eff_budget = self._effective_ctx_budget(req_budget, max_new_tokens)

        total_topk = _env_int("TOTAL_TOPK", 100)
        max_ctx_chunks = _env_int("MAX_CTX_CHUNKS", 64)

        stage1_total_topk = _env_int("STAGE1_TOTAL_TOPK", total_topk)
        rerank_top_m = _env_int("RERANK_TOP_M", stage1_total_topk)

        prior_share = None
        budgeter_out = None
        if self.use_budgeter and self.budgeter is not None:
            q_emb_np = self.retriever._encode_query(question)
            budgeter_out = self.budgeter.predict(
                q_emb_np=q_emb_np,
                default_budget=req_budget,
                q_len_chars=len(question),
                hop_feat=0.0,
                type_feat=0.0,
            )
            prior_share = budgeter_out.share
            if _env_bool("BUDGETER_OVERRIDE_BUDGET", True):
                req_budget = int(budgeter_out.budget_tokens)
                eff_budget = self._effective_ctx_budget(req_budget, max_new_tokens)

        # ===== retrieve：router-only 仍用 retrieve_multi_gran；budgeter-on 才走 stagewise =====
        if self.use_budgeter and prior_share is not None:
            # 注意：retrieve_stagewise 接受 query，不接受 question=（修你之前的报错）
            candidates, _alloc = self.retriever.retrieve_stagewise(
                question,
                budget_tokens=req_budget,
                stage1_total_topk=stage1_total_topk,
                rerank_top_m=rerank_top_m,
                total_topk=total_topk,
                prior_share=prior_share,
            )
            alloc = dict(_alloc)
        else:
            candidates = self.retriever.retrieve_multi_gran(
                question,
                budget_tokens=req_budget,
                total_topk=total_topk,
            )
            alloc = dict(getattr(self.retriever, "last_alloc", {}) or {})

        gran_counts: Dict[str, int] = {}
        for c in candidates:
            gran_counts[c.granularity] = gran_counts.get(c.granularity, 0) + 1

        cand_dedup, removed_cand = self._dedup_chunks(candidates)

        selected, ctx_token_stats = self._pack_context(
            cand_dedup,
            ctx_budget=eff_budget,
            max_ctx_chunks=max_ctx_chunks,
        )
        selected_dedup, removed_sel = self._dedup_chunks(selected)

        ctx_blocks = "\n\n".join([self._chunk_to_ctx_block(c, idx=i + 1) for i, c in enumerate(selected_dedup)])

        messages = self._build_messages(question, ctx_blocks)
        raw = self._generate(messages)
        pred = self._postprocess_answer(raw)

        if _env_bool("PRINT_CTX_STATS", False):
            total_ctx_tokens = self._count_tokens(ctx_blocks)
            print(
                f"[CTX] req={req_budget} eff={eff_budget} total_ctx_tokens={total_ctx_tokens} "
                f"removed_cand={removed_cand} removed_sel={removed_sel} ctx_token_stats={ctx_token_stats}"
            )

        if debug:
            print(f"[DEBUG][Candidates] gran_counts={gran_counts}")

        dbg: Dict[str, Any] = {}
        if debug:
            dbg = dict(
                question=question,
                pred=pred,
                raw=raw,
                req_budget=req_budget,
                eff_budget=eff_budget,
                total_topk=total_topk,
                max_ctx_chunks=max_ctx_chunks,
                stage1_total_topk=stage1_total_topk,
                rerank_top_m=rerank_top_m,
                removed_cand=removed_cand,
                removed_sel=removed_sel,
                gran_counts=gran_counts,
                alloc=alloc,
                budgeter=(None if budgeter_out is None else dict(budget_tokens=budgeter_out.budget_tokens, share=budgeter_out.share, bucket=budgeter_out.bucket)),
                ctx_token_stats=ctx_token_stats,
                selected_chunks=[asdict(c) for c in selected_dedup],
            )
        return pred, dbg
