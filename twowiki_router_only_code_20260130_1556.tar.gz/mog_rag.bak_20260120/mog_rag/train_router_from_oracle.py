# mog_rag/train_router_from_oracle.py
from __future__ import annotations
import argparse
import json
from typing import List, Dict

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sentence_transformers import SentenceTransformer

from .config import EMB_MODEL_PATH, MAX_CONTEXT_TOKENS, GRANULARITIES
from .router import GranularityRouter


def _kl(p: torch.Tensor, q: torch.Tensor) -> torch.Tensor:
    eps = 1e-8
    p = torch.clamp(p, eps, 1.0)
    q = torch.clamp(q, eps, 1.0)
    return torch.sum(q * (torch.log(q) - torch.log(p)), dim=-1).mean()


class OracleRouterDS(Dataset):
    def __init__(self, jsonl: str, emb: SentenceTransformer):
        self.rows: List[Dict] = []
        with open(jsonl, "r", encoding="utf-8") as f:
            for line in f:
                self.rows.append(json.loads(line))
        self.emb = emb

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        q = (r.get("question") or "").strip()
        y = r.get("router_target_doc_para_sent", None)
        if not y or len(y) != 3:
            y = [1/3, 1/3, 1/3]

        # 统一映射到 GRANULARITIES 的顺序
        # 假设你的 GRANULARITIES 为 ["doc","para","sent"]（如果不是，也能兼容）
        dist = torch.zeros(len(GRANULARITIES), dtype=torch.float32)
        m = {"doc": y[0], "para": y[1], "sent": y[2]}
        s = sum(m.values())
        if s <= 0:
            m = {"doc": 1/3, "para": 1/3, "sent": 1/3}
        else:
            m = {k: v / s for k, v in m.items()}
        for gi, g in enumerate(GRANULARITIES):
            dist[gi] = float(m.get(g, 0.0))

        q_emb = self.emb.encode([q], normalize_embeddings=True)[0]  # [d]
        return torch.tensor(q_emb, dtype=torch.float32), dist, len(q)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsonl", type=str, required=True)
    ap.add_argument("--out", type=str, default="router_mlp.pt")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--hidden", type=int, default=512)
    ap.add_argument("--cuda", type=int, default=1)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() and args.cuda else "cpu")

    emb = SentenceTransformer(str(EMB_MODEL_PATH), device=("cuda" if torch.cuda.is_available() and args.cuda else "cpu"))
    emb_dim = int(emb.get_sentence_embedding_dimension())
    model = GranularityRouter(emb_dim=emb_dim, hidden_size=args.hidden).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)

    ds = OracleRouterDS(args.jsonl, emb=emb)
    dl = DataLoader(ds, batch_size=args.bs, shuffle=True, num_workers=0)

    model.train()
    for ep in range(args.epochs):
        tot = 0.0
        for q_emb, y, qlen in dl:
            q_emb = q_emb.to(device)
            y = y.to(device)
            out = model(
                q_emb,
                budget_tokens=1024,
                q_len_chars=int(qlen[0].item()) if hasattr(qlen, "shape") else 0,
                budget_norm=float(MAX_CONTEXT_TOKENS),
                qlen_norm=256.0,
            )
            p = out.probs
            loss = _kl(p, y)
            opt.zero_grad()
            loss.backward()
            opt.step()
            tot += float(loss.item())
        print(f"[EP {ep}] loss={tot/max(1,len(dl)):.4f}")

    torch.save(model.mlp.state_dict(), args.out)
    print(f"[OK] saved router: {args.out}")


if __name__ == "__main__":
    main()
