# mog_rag/build_oracle_labels.py
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from transformers import AutoTokenizer

from .config import DEV_JSON, TEST_JSON, LLM_MODEL_PATH
from .utils import load_hotpot, get_answer
from .retrieval import MultiGranRetriever, RetrievedChunk
from .packer import CoveragePacker


def _normalize(s: str) -> str:
    if s is None:
        return ""
    s = s.lower().strip()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\s]", "", s)
    return s


def _gold_to_list(gold: Any) -> List[str]:
    if gold is None:
        return []
    if isinstance(gold, str):
        return [gold]
    if isinstance(gold, (list, tuple)):
        return [str(x) for x in gold]
    return [json.dumps(gold, ensure_ascii=False)]


def _gold_in_context(gold: Any, ctx: str) -> float:
    ctxn = _normalize(ctx or "")
    if not ctxn:
        return 0.0
    best = 0.0
    for g in _gold_to_list(gold):
        gn = _normalize(g)
        if gn and gn in ctxn:
            best = 1.0
            break
    return best


def _build_context(chunks: List[RetrievedChunk]) -> str:
    lines = []
    for c in chunks:
        lines.append(f"[{c.granularity.upper()}][{c.title}]")
        lines.append((c.text or "").strip())
        lines.append("")
    return "\n".join(lines).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, default="dev", choices=["dev", "test"])
    ap.add_argument("--limit", type=int, default=20000)
    ap.add_argument("--out", type=str, required=True)
    ap.add_argument("--stage1_topk", type=int, default=100)
    ap.add_argument("--rerank_top_m", type=int, default=160)
    ap.add_argument("--max_per_title", type=int, default=3)
    args = ap.parse_args()

    path = DEV_JSON if args.split == "dev" else TEST_JSON
    data = load_hotpot(path)
    if args.limit and args.limit > 0:
        data = data[:args.limit]

    tokenizer = AutoTokenizer.from_pretrained(str(LLM_MODEL_PATH), trust_remote_code=True, use_fast=False)
    # --- robust tokenizer loader for Qwen3 (fast tokenizer.json may be incompatible) ---
    tokenizer = None
    try:
        tokenizer = AutoTokenizer.from_pretrained(
            str(LLM_MODEL_PATH),
            trust_remote_code=True,
            use_fast=False,   # IMPORTANT: avoid TokenizerFast.from_file(tokenizer.json)
        )
        print("[OK] Loaded LLM tokenizer with use_fast=False")
    except Exception as e:
        print(f"[WARN] Failed to load slow tokenizer (use_fast=False): {e}")
        try:
            tokenizer = AutoTokenizer.from_pretrained(
                str(LLM_MODEL_PATH),
                trust_remote_code=True,
                use_fast=True,
            )
            print("[OK] Loaded LLM tokenizer with use_fast=True")
        except Exception as e2:
            print(f"[WARN] Failed to load fast tokenizer too. Fallback to whitespace token counting. err={e2}")
            tokenizer = None

    def count_tokens(t: str) -> int:
        if not t:
            return 0
        if tokenizer is None:
            return len(t.split())
        try:
            return len(tokenizer.encode(t))
        except Exception:
            return len(t.split())


    packer = CoveragePacker(count_tokens=count_tokens, max_per_title=args.max_per_title)

    # 一个 retriever，全粒度索引都加载；我们通过 prior_share 控制“偏好”
    retriever = MultiGranRetriever(split=args.split, use_reranker=True, router=None)

    # policy 列表：你后续可以加更多 share 分布
    policies: List[Tuple[str, Dict[str, float]]] = [
        ("doc_only", {"doc": 1.0, "para": 0.0, "sent": 0.0}),
        ("para_only", {"doc": 0.0, "para": 1.0, "sent": 0.0}),
        ("sent_only", {"doc": 0.0, "para": 0.0, "sent": 1.0}),
        ("mix_uniform", {"doc": 1/3, "para": 1/3, "sent": 1/3}),
        ("mix_para_heavy", {"doc": 0.2, "para": 0.6, "sent": 0.2}),
        ("mix_doc_heavy", {"doc": 0.6, "para": 0.3, "sent": 0.1}),
    ]

    budgets = [512, 1024, 1536, 2048]

    outp = Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)

    with outp.open("w", encoding="utf-8") as f:
        for i, ex in enumerate(data):
            q = (ex.get("question") or "").strip()
            gold = get_answer(ex)

            best = None  # (score, -small_budget, policy_name, budget, share, selected_chunks)
            for b in budgets:
                for name, share in policies:
                    cands, alloc = retriever.retrieve_stagewise(
                        query=q,
                        budget_tokens=int(b),
                        stage1_total_topk=int(args.stage1_topk),
                        rerank_top_m=int(args.rerank_top_m),
                        prior_share=share,
                    )
                    pack = packer.pack(q, cands, budget_tokens=int(b))
                    ctx = _build_context(pack.selected)
                    score = _gold_in_context(gold, ctx)

                    key = (float(score), -int(b))
                    if best is None or key > (best[0], best[1]):
                        best = (float(score), -int(b), name, int(b), dict(share), pack.selected, dict(alloc))

            assert best is not None
            _, _, best_name, best_budget, best_share, best_sel, best_alloc = best

            # router_target：用 share 作为 soft label（doc/para/sent）
            router_target = [float(best_share.get("doc", 0.0)),
                             float(best_share.get("para", 0.0)),
                             float(best_share.get("sent", 0.0))]
            s = sum(router_target)
            if s > 0:
                router_target = [x / s for x in router_target]
            else:
                router_target = [1/3, 1/3, 1/3]

            # budget_bucket：离散到 buckets 列表
            bucket_list = budgets
            bucket_id = int(bucket_list.index(best_budget)) if best_budget in bucket_list else int(1)

            rec = {
                "idx": i,
                "qid": ex.get("id", ex.get("_id", i)),
                "question": q,
                "gold": gold,
                "best_policy": best_name,
                "best_budget": int(best_budget),
                "budget_bucket_id": int(bucket_id),
                "router_target_doc_para_sent": router_target,
                "prior_share": best_share,
                "alloc_stage1": best_alloc,
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"[OK] wrote oracle labels: {outp}")


if __name__ == "__main__":
    main()
