# mog_rag/config.py
from __future__ import annotations
from pathlib import Path
import os

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# ---------------------------
# Dataset
# ---------------------------
DATASET_NAME = os.getenv("DATASET_NAME", "2wiki")  # "hotpot" / "2wiki" / "musique"
DATA_ROOT = Path(os.getenv("DATA_ROOT", "/mnt/raid/peiyu/data"))

if DATASET_NAME.lower().startswith("2wiki"):
    DATASET_DIR = DATA_ROOT / "2Wiki"
    TRAIN_JSON = DATASET_DIR / "train.json"
    DEV_JSON = DATASET_DIR / "dev.json"
    TEST_JSON = DATASET_DIR / "test.json"
else:
    # 兼容你原来的 Hotpot 项目（你需要时再改）
    DATASET_DIR = DATA_ROOT / "hotpot"
    TRAIN_JSON = DATASET_DIR / "hotpot_train_v1.1.json"
    DEV_JSON = DATASET_DIR / "hotpot_dev_distractor_v1.json"
    TEST_JSON = DATASET_DIR / "hotpot_test_distractor_v1.json"

# 兼容旧名字（你很多脚本还在 import HOTPOT_*）
HOTPOT_TRAIN = TRAIN_JSON
HOTPOT_DEV = DEV_JSON
HOTPOT_TEST = TEST_JSON

# chunk jsonl（hotpot_chunking.py 已经写到了这里）
TRAIN_SENT_JSONL = DATASET_DIR / "train_sent.jsonl"
TRAIN_PARA_JSONL = DATASET_DIR / "train_para.jsonl"
TRAIN_DOC_JSONL  = DATASET_DIR / "train_doc.jsonl"
DEV_SENT_JSONL   = DATASET_DIR / "dev_sent.jsonl"
DEV_PARA_JSONL   = DATASET_DIR / "dev_para.jsonl"
DEV_DOC_JSONL    = DATASET_DIR / "dev_doc.jsonl"

CORPUS_DIR = DATASET_DIR

# ---------------------------
# Index
# ---------------------------
INDEX_DIR = PROJECT_ROOT / "indices" / DATASET_NAME.lower()

# ---------------------------
# Models
# ---------------------------
MODEL_ROOT = Path(os.getenv("MODEL_ROOT", "/mnt/raid/peiyu/models"))
LLM_MODEL_PATH = Path(os.getenv("LLM_MODEL_PATH", str(MODEL_ROOT / "Qwen2.5-14B-Instruct")))
#LLM_MODEL_PATH = Path("/mnt/raid/zsb/llm_models/Qwen3-32B")
EMB_MODEL_PATH = Path(os.getenv("EMB_MODEL_PATH", str(MODEL_ROOT / "bge-large-en-v1.5")))
RERANKER_MODEL_PATH = Path(os.getenv("RERANKER_MODEL_PATH", str(MODEL_ROOT / "bge-reranker-large")))

# ---------------------------
# RAG settings
# ---------------------------
GRANULARITIES = ("sent", "para", "doc")

MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "2048"))
TOTAL_TOPK = int(os.getenv("TOTAL_TOPK", "60"))

EMB_BATCH_SIZE = int(os.getenv("EMB_BATCH_SIZE", "256"))

def _exists(p: Path) -> bool:
    try:
        return p.exists()
    except Exception:
        return False

if __name__ == "__main__":
    print("PROJECT_ROOT:", PROJECT_ROOT)
    print(f"{DATASET_NAME} train:", TRAIN_JSON, _exists(TRAIN_JSON))
    print(f"{DATASET_NAME} dev:  ", DEV_JSON, _exists(DEV_JSON))
    print(f"{DATASET_NAME} test: ", TEST_JSON, _exists(TEST_JSON))
    print("INDEX_DIR:  ", INDEX_DIR, _exists(INDEX_DIR))
    print("LLM_MODEL:  ", LLM_MODEL_PATH, _exists(LLM_MODEL_PATH))
    print("EMB_MODEL:  ", EMB_MODEL_PATH, _exists(EMB_MODEL_PATH))
    print("RERANKER:   ", RERANKER_MODEL_PATH, _exists(RERANKER_MODEL_PATH))
