# mog_rag/retrieval.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import json
import os

import numpy as np
import torch
import faiss
from sentence_transformers import SentenceTransformer, CrossEncoder

from .config import (
    INDEX_DIR,
    EMB_MODEL_PATH,
    RERANKER_MODEL_PATH,
    GRANULARITIES,
    MAX_CONTEXT_TOKENS,
    TOTAL_TOPK,
)

FAISS_HAS_GPU = hasattr(faiss, "StandardGpuResources")


@dataclass
class RetrievedChunk:
    chunk_id: int
    text: str
    granularity: str
    granularity_id: int
    ex_id: int
    title: str
    dense_score: float
    rerank_score: float = 0.0


class MultiGranRetriever:
    def __init__(
        self,
        split: str = "dev",
        use_reranker: bool = True,
        router: Optional[object] = None,
    ):
        self.split = split
        self.use_reranker = use_reranker
        self.router = router

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # GRAN_MODE=sent-only / para-only / doc-only / default(all)
        gran_mode = os.getenv("GRAN_MODE", "").strip().lower()
        if gran_mode == "sent-only":
            self.active_grans = ["sent"]
        elif gran_mode == "para-only":
            self.active_grans = ["para"]
        elif gran_mode == "doc-only":
            self.active_grans = ["doc"]
        else:
            self.active_grans = list(GRANULARITIES)

        print(f"[Retrieval] active_granularities={self.active_grans}")

        # FAISS GPU resource
        if torch.cuda.is_available() and FAISS_HAS_GPU:
            self.gpu_id = 0
            self.gpu_res = faiss.StandardGpuResources()
            print(f"[FAISS] {split}: index on GPU{self.gpu_id}")
        else:
            self.gpu_id = -1
            self.gpu_res = None
            print(f"[FAISS] {split}: index on CPU")

        self.indices: Dict[str, faiss.Index] = {}
        self.metas: Dict[str, List[Dict]] = {}
        self._load_indices()

        emb_device = "cuda" if torch.cuda.is_available() else "cpu"
        self.emb_model = SentenceTransformer(str(EMB_MODEL_PATH), device=emb_device)

        if self.use_reranker:
            rr_device = "cuda" if torch.cuda.is_available() else "cpu"
            self.reranker = CrossEncoder(str(RERANKER_MODEL_PATH), device=rr_device)
        else:
            self.reranker = None

        self.gran2id = {g: i for i, g in enumerate(GRANULARITIES)}

        # 给日志对齐用：最后一次的“按粒度分配的topk”
        self.last_alloc: Dict[str, int] = {}

    def _load_indices(self) -> None:
        for gran in self.active_grans:
            out_dir = INDEX_DIR / self.split / gran
            index_path = out_dir / "index.faiss"
            meta_path = out_dir / "meta.jsonl"
            if not index_path.exists():
                print(f"[WARN] index not found for {self.split}-{gran}, skip.")
                continue

            index_cpu = faiss.read_index(str(index_path))
            if self.gpu_res is not None and self.gpu_id >= 0:
                index = faiss.index_cpu_to_gpu(self.gpu_res, self.gpu_id, index_cpu)
                print(f"[LOAD][GPU] {self.split}-{gran}")
            else:
                index = index_cpu
                print(f"[LOAD][CPU] {self.split}-{gran}")

            metas: List[Dict] = []
            with meta_path.open("r", encoding="utf-8") as f:
                for line in f:
                    metas.append(json.loads(line))

            self.indices[gran] = index
            self.metas[gran] = metas
            print(f"[LOAD] {self.split}-{gran}: {len(metas)} chunks")

    def _encode_query(self, q: str) -> np.ndarray:
        emb = self.emb_model.encode([q], normalize_embeddings=True)
        return np.asarray(emb, dtype="float32")  # [1,d]

    def _allocate_topk(
        self,
        query: str,
        q_emb: np.ndarray,
        budget_tokens: int,
        total_topk: int,
        prior_share: Optional[Dict[str, float]] = None,
    ) -> Dict[str, int]:
        """
        分配 stage1 的检索配额（gran -> k）
        - router 有：用 router 概率（可和 prior_share 做线性混合）
        - router 无：用 prior_share 或 uniform
        """
        available = [g for g in self.active_grans if g in self.indices]
        if not available:
            return {}
        if len(available) == 1:
            return {available[0]: total_topk}

        # ===== no router =====
        if self.router is None:
            if prior_share:
                pairs = [(g, float(prior_share.get(g, 0.0))) for g in available]
                s = sum(p for _, p in pairs)
                if s <= 0:
                    pairs = [(g, 1.0 / len(available)) for g in available]
                else:
                    pairs = [(g, p / s) for g, p in pairs]
            else:
                pairs = [(g, 1.0 / len(available)) for g in available]

            alloc: Dict[str, int] = {}
            left = total_topk
            for i, (g, p) in enumerate(pairs):
                if i == len(pairs) - 1:
                    k = left
                else:
                    k = int(round(total_topk * p))
                k = max(1, k)
                alloc[g] = k
                left -= k

            cur = sum(alloc.values())
            if cur != total_topk:
                diff = total_topk - cur
                alloc[available[0]] = max(1, alloc[available[0]] + diff)
            return alloc

        # ===== router exists =====
        router_device = next(self.router.mlp.parameters()).device
        q_emb_t = torch.from_numpy(q_emb).to(router_device)
        out = self.router(
            q_emb_t,
            budget_tokens=budget_tokens,
            q_len_chars=len(query),
            budget_norm=float(MAX_CONTEXT_TOKENS),
        )
        probs = out.probs.detach().float().cpu().numpy()  # [G_all]

        # 取出 available 对应概率
        pairs = []
        for g in available:
            idx = self.gran2id[g]
            pairs.append((g, float(probs[idx])))

        # 与 prior_share 混合（可选）
        alpha = float(os.getenv("PRIOR_MIX_ALPHA", "0.0"))  # 0=不用prior，1=只用prior
        if prior_share and alpha > 0:
            mixed = []
            for g, p in pairs:
                pp = float(prior_share.get(g, 0.0))
                mixed.append((g, (1 - alpha) * float(p) + alpha * float(pp)))
            pairs = mixed

        s = sum(p for _, p in pairs)
        if s <= 0:
            pairs = [(g, 1.0 / len(pairs)) for g, _ in pairs]
        else:
            pairs = [(g, p / s) for g, p in pairs]

        # base quota（避免某粒度饿死）
        base_default = {"doc": 6, "para": 10, "sent": 10}
        alloc: Dict[str, int] = {}
        base_sum = 0
        for g in available:
            k = int(base_default.get(g, 0))
            if k > 0:
                alloc[g] = k
                base_sum += k

        if base_sum >= total_topk:
            G = len(available)
            base = max(1, total_topk // G)
            rem = total_topk - base * G
            return {g: base + (1 if i < rem else 0) for i, g in enumerate(available)}

        remain = total_topk - base_sum
        left = remain
        for i, (g, p) in enumerate(pairs):
            if i == len(pairs) - 1:
                k = left
            else:
                k = int(round(remain * p))
                k = max(0, k)
            alloc[g] = alloc.get(g, 0) + k
            left -= k

        # sent cap
        sent_cap = int(total_topk * 0.45)
        if "sent" in alloc and alloc["sent"] > sent_cap:
            overflow = alloc["sent"] - sent_cap
            alloc["sent"] = sent_cap
            targets = [g for g in available if g != "sent"]
            if targets and overflow > 0:
                per = overflow // len(targets)
                rem2 = overflow % len(targets)
                for i, tg in enumerate(targets):
                    alloc[tg] = alloc.get(tg, 0) + per + (1 if i < rem2 else 0)

        # fix sum
        cur = sum(max(0, v) for v in alloc.values())
        if cur != total_topk:
            diff = total_topk - cur
            for pref in ["doc", "para", "sent"]:
                if pref in alloc:
                    alloc[pref] = max(1, alloc[pref] + diff)
                    break

        alloc = {g: int(v) for g, v in alloc.items() if v > 0}
        return alloc

    # 兼容旧调用：完整 rerank 所有候选（慢，但不破坏你已有脚本）
    def retrieve_multi_gran(
        self,
        query: str,
        budget_tokens: int = MAX_CONTEXT_TOKENS,
        total_topk: int = TOTAL_TOPK,
    ) -> List[RetrievedChunk]:
        if not self.indices:
            return []

        q_emb = self._encode_query(query)
        alloc = self._allocate_topk(query, q_emb, budget_tokens, total_topk, prior_share=None)
        self.last_alloc = dict(alloc)

        all_chunks: List[RetrievedChunk] = []
        for gran, k in alloc.items():
            if gran not in self.indices or k <= 0:
                continue
            index = self.indices[gran]
            metas = self.metas[gran]
            if not metas:
                continue

            k_eff = min(int(k), len(metas))
            scores, idxs = index.search(q_emb, k_eff)
            scores = scores[0]
            idxs = idxs[0]

            for score, idx in zip(scores, idxs):
                if idx < 0:
                    continue
                meta = metas[int(idx)]
                all_chunks.append(
                    RetrievedChunk(
                        chunk_id=int(idx),
                        text=meta.get("text", ""),
                        granularity=gran,
                        granularity_id=self.gran2id.get(gran, 0),
                        ex_id=int(meta.get("ex_id", -1)),
                        title=meta.get("title", ""),
                        dense_score=float(score),
                    )
                )

        if not all_chunks:
            return []

        if self.use_reranker and self.reranker is not None:
            pairs = [(query, c.text) for c in all_chunks]
            with torch.no_grad():
                rr = self.reranker.predict(pairs)
            for c, s in zip(all_chunks, rr):
                c.rerank_score = float(s)
            all_chunks.sort(key=lambda x: x.rerank_score, reverse=True)
        else:
            all_chunks.sort(key=lambda x: x.dense_score, reverse=True)

        return all_chunks[:total_topk]

    # 新增：stagewise（先dense大池，再只rerank top-M）
    def retrieve_stagewise(
        self,
        query: str,
        budget_tokens: int,
        stage1_total_topk: int,
        rerank_top_m: int,
        prior_share: Optional[Dict[str, float]] = None,
    ) -> Tuple[List[RetrievedChunk], Dict[str, int]]:
        if not self.indices:
            return [], {}

        q_emb = self._encode_query(query)
        alloc = self._allocate_topk(query, q_emb, budget_tokens, stage1_total_topk, prior_share=prior_share)
        self.last_alloc = dict(alloc)

        pool: List[RetrievedChunk] = []
        for gran, k in alloc.items():
            if gran not in self.indices or k <= 0:
                continue
            metas = self.metas.get(gran, [])
            if not metas:
                continue
            index = self.indices[gran]
            k_eff = min(int(k), len(metas))
            scores, idxs = index.search(q_emb, k_eff)
            scores = scores[0]
            idxs = idxs[0]
            for score, idx in zip(scores, idxs):
                if idx < 0:
                    continue
                meta = metas[int(idx)]
                pool.append(
                    RetrievedChunk(
                        chunk_id=int(idx),
                        text=meta.get("text", ""),
                        granularity=gran,
                        granularity_id=self.gran2id.get(gran, 0),
                        ex_id=int(meta.get("ex_id", -1)),
                        title=meta.get("title", ""),
                        dense_score=float(score),
                    )
                )

        if not pool:
            return [], alloc

        pool.sort(key=lambda x: x.dense_score, reverse=True)

        if self.use_reranker and self.reranker is not None:
            m = min(int(rerank_top_m), len(pool))
            head = pool[:m]
            pairs = [(query, c.text) for c in head]
            with torch.no_grad():
                rr = self.reranker.predict(pairs)
            for c, s in zip(head, rr):
                c.rerank_score = float(s)
            head.sort(key=lambda x: x.rerank_score, reverse=True)
            pool = head + pool[m:]

        return pool, alloc
