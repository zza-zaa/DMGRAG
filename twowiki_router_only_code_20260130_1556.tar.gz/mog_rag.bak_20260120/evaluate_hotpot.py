# mog_rag/evaluate_hotpot.py
import json
import re
import string
import time
from typing import Any, Dict, List, Optional, Tuple

from tqdm import tqdm

from .config import DEV_JSON, TEST_JSON, DATASET_NAME
from .rag_pipeline import HotpotRAGPipeline
from .utils import load_hotpot, get_answer

SEP = "=" * 80


def _normalize_answer(s: str) -> str:
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_score(prediction: str, ground_truth: str) -> float:
    pred_tokens = _normalize_answer(prediction).split()
    gold_tokens = _normalize_answer(ground_truth).split()
    if not pred_tokens and not gold_tokens:
        return 1.0
    if not pred_tokens or not gold_tokens:
        return 0.0

    common: Dict[str, int] = {}
    for t in pred_tokens:
        common[t] = common.get(t, 0) + 1

    num_same = 0
    for t in gold_tokens:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0

    p = num_same / len(pred_tokens)
    r = num_same / len(gold_tokens)
    return 2 * p * r / (p + r)


def _qa_em_f1(prediction: str, ground_truth: str) -> Tuple[float, float]:
    em = float(_normalize_answer(prediction) == _normalize_answer(ground_truth))
    f1 = _f1_score(prediction, ground_truth)
    return em, f1


def _as_str_gold(gold: Any) -> str:
    if gold is None:
        return ""
    if isinstance(gold, str):
        return gold
    if isinstance(gold, (list, tuple)):
        return " | ".join(str(x) for x in gold)
    return json.dumps(gold, ensure_ascii=False)


def _safe_get(d: Any, *keys: str, default=None):
    if not isinstance(d, dict):
        return default
    for k in keys:
        if k in d:
            return d[k]
    return default


def _count_tokens(pipeline: HotpotRAGPipeline, text: str) -> int:
    if text is None:
        return 0
    try:
        tok = getattr(pipeline, "tokenizer", None)
        if tok is not None and hasattr(tok, "encode"):
            return len(tok.encode(text))
    except Exception:
        pass
    return len(text.split())


def _extract_candidates(debug_ctx: Any) -> Tuple[Optional[Dict[str, int]], Optional[str], Optional[str]]:
    """
    Return: (gran_counts, top1_text, top1_gran)
    兼容两种来源：
    - pipeline 直接给：gran_counts / top1_text / top1_gran
    - 或者老格式：retrieved_by_gran 等
    """
    if not isinstance(debug_ctx, dict):
        return None, None, None

    # NEW: direct fields (推荐)
    gran_counts = _safe_get(debug_ctx, "gran_counts", default=None)
    if not isinstance(gran_counts, dict):
        gran_counts = None

    top1_text = _safe_get(debug_ctx, "top1_text", default=None)
    if isinstance(top1_text, dict):
        top1_text = json.dumps(top1_text, ensure_ascii=False)
    if top1_text is not None:
        top1_text = str(top1_text)

    top1_gran = _safe_get(debug_ctx, "top1_gran", "chosen_gran", "chosen_granularity", default=None)
    if isinstance(top1_gran, str):
        top1_gran = top1_gran.strip()

    return gran_counts, top1_text, top1_gran


def _format_example_block(
    idx: int,
    question: str,
    gold: Any,
    pred: str,
    gran_counts: Optional[Dict[str, int]],
    top1_text: Optional[str],
    top1_gran: Optional[str],
    token_stats_by_gran: Optional[Dict[str, int]],
) -> str:
    lines: List[str] = []
    if gran_counts is not None:
        lines.append(f"[DEBUG][Candidates] gran_counts={gran_counts}")
    lines.append(SEP)
    lines.append(f"[{idx}] Question:\n{question}")
    lines.append(f"[{idx}] Gold Answer:\n{_as_str_gold(gold)}")
    lines.append(f"[{idx}] Pred Answer:\n{pred}")
    lines.append("")  # blank line

    if top1_text is not None:
        g = top1_gran if top1_gran is not None else "unknown"
        lines.append(f"[{idx}] Top-1 Retrieved Chunk (gran={g}):")
        lines.append(str(top1_text).rstrip())
        lines.append("")

    if token_stats_by_gran is not None and len(token_stats_by_gran) > 0:
        lines.append(f"[{idx}] Context token stats by granularity: {token_stats_by_gran}")

    lines.append(SEP)
    lines.append("")
    return "\n".join(lines)


def evaluate(
    split: str = "dev",
    limit: int = 1500,
    log_examples: int = 1,
    log_every: int = 1,
    log_first_n: int = 0,
    dump_jsonl: Optional[str] = None,
    dump_wrong_only: int = 0,
    dump_context_chars: int = 800,
) -> None:
    path = DEV_JSON if split == "dev" else TEST_JSON
    data = load_hotpot(path)
    if limit and limit > 0:
        data = data[:limit]

    pipeline = HotpotRAGPipeline()

    n = len(data)
    total_em = 0.0
    total_f1 = 0.0

    dump_f = None
    if dump_jsonl:
        dump_f = open(dump_jsonl, "w", encoding="utf-8")

    # 对齐你日志：desc 末尾有冒号
    pbar = tqdm(data, desc=f"Evaluating {DATASET_NAME} {split}:", dynamic_ncols=True)
    for idx, ex in enumerate(pbar):
        q = ex.get("question", "").strip()
        gold = get_answer(ex)

        pred, debug_ctx = pipeline.answer(q, debug=True)

        em, f1 = 0.0, 0.0
        if gold:
            em, f1 = _qa_em_f1(pred, gold)
            total_em += em
            total_f1 += f1

        gran_counts, top1_text, top1_gran = _extract_candidates(debug_ctx)

        # token stats：优先读 pipeline 直接提供的 ctx_token_stats
        token_stats_by_gran = _safe_get(debug_ctx, "ctx_token_stats", default=None)
        if not isinstance(token_stats_by_gran, dict):
            token_stats_by_gran = {}

        # per-example log printing
        should_log = bool(log_examples)
        if should_log:
            if log_first_n and log_first_n > 0 and idx >= log_first_n:
                should_log = False
            if log_every and log_every > 1 and (idx % log_every != 0):
                should_log = False

        if should_log:
            block = _format_example_block(
                idx=idx,
                question=q,
                gold=gold,
                pred=pred,
                gran_counts=gran_counts,
                top1_text=top1_text,
                top1_gran=top1_gran,
                token_stats_by_gran=token_stats_by_gran if token_stats_by_gran else None,
            )
            tqdm.write(block)

        # optional jsonl dump
        if dump_f:
            should_dump = True
            if dump_wrong_only:
                should_dump = (em == 0.0)
            if should_dump:
                # best-effort context preview
                ctx_preview = ""
                if "selected_chunks" in debug_ctx and isinstance(debug_ctx["selected_chunks"], list):
                    # 拼一个轻量预览，避免爆文件
                    tmp = []
                    for c in debug_ctx["selected_chunks"][:6]:
                        try:
                            tmp.append(f"[{getattr(c,'granularity','?')}] {getattr(c,'title','')}\n{getattr(c,'text','')}")
                        except Exception:
                            tmp.append(str(c))
                    ctx_preview = "\n\n".join(tmp)[:dump_context_chars]

                rec = {
                    "ts": time.time(),
                    "idx": idx,
                    "qid": ex.get("id", ex.get("_id", idx)),
                    "question": q,
                    "gold": gold,
                    "pred": pred,
                    "em": float(em),
                    "f1": float(f1),
                    "gran_counts": gran_counts,
                    "top1_gran": top1_gran,
                    "top1_text": (top1_text[:dump_context_chars] if isinstance(top1_text, str) else top1_text),
                    "token_stats_by_gran": token_stats_by_gran,
                    "context_preview": ctx_preview,
                }
                dump_f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                dump_f.flush()

    if dump_f:
        dump_f.close()

    avg_em = total_em / n if n > 0 else 0.0
    avg_f1 = total_f1 / n if n > 0 else 0.0
    # 对齐你日志的 RESULT 行格式
    print(f"[RESULT] N={n}  EM={avg_em:.3f}  F1={avg_f1:.3f}")


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, default="dev", choices=["dev", "test"])
    ap.add_argument("--limit", type=int, default=1500, help="0 means full")

    ap.add_argument("--log_examples", type=int, default=1, choices=[0, 1])
    ap.add_argument("--log_every", type=int, default=1)
    ap.add_argument("--log_first_n", type=int, default=0)

    ap.add_argument("--dump_jsonl", type=str, default=None)
    ap.add_argument("--dump_wrong_only", type=int, default=0, choices=[0, 1])
    ap.add_argument("--dump_context_chars", type=int, default=800)

    args = ap.parse_args()

    evaluate(
        split=args.split,
        limit=args.limit,
        log_examples=args.log_examples,
        log_every=args.log_every,
        log_first_n=args.log_first_n,
        dump_jsonl=args.dump_jsonl,
        dump_wrong_only=args.dump_wrong_only,
        dump_context_chars=args.dump_context_chars,
    )
