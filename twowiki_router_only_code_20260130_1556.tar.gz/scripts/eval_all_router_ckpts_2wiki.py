#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evaluate all trained router checkpoints on 2Wiki with limit=1500, EM/F1.

- Scans ckpts/router_policy_v2_B5200_E*_N*.pt
- Runs: python -m mog_rag.evaluate_hotpot --split {split} --limit {limit}
- Sets env: DATASET_NAME=2wiki, USE_ROUTER=1, USE_BUDGETER=0, ROUTER_CKPT=...
- Parses "[RESULT] N=... EM=... F1=..." from log
- Writes CSV summary

This script itself does NOT import mog_rag; it only spawns subprocesses.
"""

import argparse
import os
import re
import sys
import glob
import csv
import time
import subprocess
from pathlib import Path
from typing import Optional, Tuple, List, Dict

RESULT_RE = re.compile(r"\[RESULT\]\s+N=(\d+)\s+EM=([0-9.]+)\s+F1=([0-9.]+)")

def parse_result_from_log(log_path: Path) -> Tuple[Optional[int], Optional[float], Optional[float]]:
    if not log_path.exists():
        return None, None, None
    # Read from end-ish to be fast
    try:
        with log_path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 200_000), os.SEEK_SET)
            text = f.read().decode("utf-8", errors="ignore")
    except Exception:
        text = log_path.read_text(encoding="utf-8", errors="ignore")

    m = None
    for line in text.splitlines()[::-1]:
        mm = RESULT_RE.search(line)
        if mm:
            m = mm
            break
    if not m:
        return None, None, None
    n = int(m.group(1))
    em = float(m.group(2))
    f1 = float(m.group(3))
    return n, em, f1

def extract_E_N(ckpt_name: str) -> Tuple[int, int]:
    # router_policy_v2_B5200_E3_N20000.pt
    e = 0
    n = 0
    m = re.search(r"_E(\d+)_N(\d+)\.pt$", ckpt_name)
    if m:
        e = int(m.group(1))
        n = int(m.group(2))
    return e, n

def run_one(py: str, repo_root: Path, ckpt: Path, args) -> Dict:
    e, ntr = extract_E_N(ckpt.name)

    out_dir = repo_root / "logs" / f"grid_eval_router_only_2wiki_B{args.B}"
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / f"eval_router_only_B{args.B}_E{e}_N{ntr}_{args.split}_L{args.limit}.log"

    # env for the child process (evaluate_hotpot)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
    env["PYTHONPATH"] = f"{repo_root}:{env.get('PYTHONPATH','')}"
    env["DATASET_NAME"] = "2wiki"
    env["DATA_ROOT"] = args.data_root
    env["LLM_PATH"] = args.llm_path

    env["USE_ROUTER"] = "1"
    env["USE_BUDGETER"] = "0"
    env["ROUTER_CKPT"] = str(ckpt)

    # keep your usual eval knobs
    env["CTX_BUDGET"] = str(args.B)
    env["STAGE1_TOTAL_TOPK"] = str(args.stage1_total_topk)
    env["RERANK_TOP_M"] = str(args.rerank_top_m)
    env["TOTAL_TOPK"] = str(args.total_topk)

    cmd = [
        py, "-m", "mog_rag.evaluate_hotpot",
        "--split", args.split,
        "--limit", str(args.limit),
    ]
    # (optional dump)
    if args.dump_jsonl:
        env["PRINT_CTX_STATS"] = env.get("PRINT_CTX_STATS", "0")
        cmd += ["--dump_jsonl", str(out_dir / f"dumps_router_only_B{args.B}_E{e}_N{ntr}_{args.split}_L{args.limit}.jsonl")]

    t0 = time.time()
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[CMD] " + " ".join(cmd) + "\n")
        f.write(f"[ENV] CUDA_VISIBLE_DEVICES={env['CUDA_VISIBLE_DEVICES']}\n")
        f.write(f"[ENV] DATASET_NAME={env['DATASET_NAME']}\n")
        f.write(f"[ENV] USE_ROUTER={env['USE_ROUTER']} USE_BUDGETER={env['USE_BUDGETER']}\n")
        f.write(f"[ENV] ROUTER_CKPT={env['ROUTER_CKPT']}\n")
        f.write(f"[ENV] CTX_BUDGET={env['CTX_BUDGET']} STAGE1_TOTAL_TOPK={env['STAGE1_TOTAL_TOPK']} "
                f"RERANK_TOP_M={env['RERANK_TOP_M']} TOTAL_TOPK={env['TOTAL_TOPK']}\n\n")
        f.flush()

        p = subprocess.run(cmd, cwd=str(repo_root), env=env, stdout=f, stderr=subprocess.STDOUT)
        rc = p.returncode

    n_eval, em, f1 = parse_result_from_log(log_path)
    status = "OK" if (rc == 0 and em is not None and f1 is not None) else f"CRASH(rc={rc})"

    return {
        "mode": "router_only",
        "B": args.B,
        "epoch": e,
        "n_train": ntr,
        "split": args.split,
        "limit": args.limit,
        "ckpt": str(ckpt),
        "status": status,
        "EM": "" if em is None else f"{em:.6f}",
        "F1": "" if f1 is None else f"{f1:.6f}",
        "eval_log": str(log_path),
        "elapsed_sec": f"{(time.time()-t0):.1f}",
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", default="/mnt/raid/peiyu/twowiki_router_only")
    ap.add_argument("--py", default="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python")
    ap.add_argument("--cuda", type=int, default=0)

    ap.add_argument("--split", default="dev", choices=["dev", "test"])
    ap.add_argument("--limit", type=int, default=1500)

    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--stage1_total_topk", type=int, default=160)
    ap.add_argument("--rerank_top_m", type=int, default=160)
    ap.add_argument("--total_topk", type=int, default=100)

    ap.add_argument("--data_root", default="/mnt/raid/peiyu/data")
    ap.add_argument("--llm_path", default="/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct")

    ap.add_argument("--glob", default="ckpts/router_policy_v2_B5200_E*_N*.pt")
    ap.add_argument("--smoke", type=int, default=0, help="1 -> only run first ckpt and set limit=20")
    ap.add_argument("--dump_jsonl", type=int, default=0)
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    if args.smoke == 1:
        args.limit = 20

    ckpts = [Path(p) for p in glob.glob(str(repo_root / args.glob))]
    ckpts = [p for p in ckpts if p.exists()]
    ckpts.sort(key=lambda p: extract_E_N(p.name))

    out_dir = repo_root / "logs" / f"grid_eval_router_only_2wiki_B{args.B}"
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / "summary.csv"

    if not ckpts:
        print(f"[ERR] no ckpts found by glob: {args.glob}")
        print(f"      looked under: {repo_root}")
        sys.exit(2)

    rows: List[Dict] = []
    print(f"[INFO] found {len(ckpts)} ckpts. split={args.split} limit={args.limit} cuda={args.cuda}")

    for i, ckpt in enumerate(ckpts):
        print(f"[RUN {i+1}/{len(ckpts)}] {ckpt.name}")
        row = run_one(args.py, repo_root, ckpt, args)
        rows.append(row)
        print(f"  -> {row['status']} EM={row['EM']} F1={row['F1']} log={Path(row['eval_log']).name}")

        if args.smoke == 1:
            break

        # write incremental
        with summary_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    # final save
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(f"saved: {summary_path}")

if __name__ == "__main__":
    main()
