#!/usr/bin/env bash
set -euo pipefail

# -------------------------
# Config (edit if needed)
# -------------------------
PY="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

CUDA_ID="${1:-1}"          # GPU id
SMOKE="${2:-0}"            # 1 => limit=20
SPLIT="${3:-dev}"          # dev by default
LIMIT="${4:-1500}"         # eval questions
if [[ "${SMOKE}" == "1" ]]; then LIMIT="20"; fi

B=5200
E_LIST=(1 3 5 7 9)
N_LIST=(1000 5000 10000 15000 20000)

# oracle file (full label file, N=20000)
ORACLE_FULL="${ROOT}/data/oracle_policy_train_v2_B${B}_N20000.jsonl"

# Models/paths
EMB_MODEL_PATH="/mnt/raid/peiyu/models/bge-large-en-v1.5"
LLM_PATH="/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct"
DATA_ROOT="/mnt/raid/peiyu/data"

# Retrieval hyperparams (match your eval setup)
CTX_BUDGET="${B}"
STAGE1_TOTAL_TOPK="160"
RERANK_TOP_M="160"
TOTAL_TOPK="100"

OUT_DIR="${ROOT}/logs/grid_train_eval_router_2wiki_B${B}"
CKPT_DIR="${ROOT}/ckpts"

mkdir -p "${OUT_DIR}" "${CKPT_DIR}" "${ROOT}/data"

SUMMARY="${OUT_DIR}/summary.csv"
echo "mode,B,epoch,n_train,split,limit,ckpt,status,EM,F1,train_log,eval_log" > "${SUMMARY}"

cd "${ROOT}"

if [[ ! -f "${ORACLE_FULL}" ]]; then
  echo "[FATAL] oracle file not found: ${ORACLE_FULL}"
  echo "        Please place your B=5200 oracle label here (N=20000)."
  exit 1
fi

parse_emf1 () {
  # args: log_path
  "${PY}" - <<'PY'
import re, sys
p = sys.argv[1]
try:
    s = open(p, "r", errors="ignore").read()
except FileNotFoundError:
    print("", "")
    raise SystemExit(0)
ms = list(re.finditer(r"\[RESULT\].*?EM=([0-9.]+)\s+F1=([0-9.]+)", s))
if not ms:
    print("", "")
else:
    m = ms[-1]
    print(m.group(1), m.group(2))
PY
}

for E in "${E_LIST[@]}"; do
  for N in "${N_LIST[@]}"; do
    ORACLE_SUB="${ROOT}/data/oracle_policy_train_v2_B${B}_N${N}.jsonl"
    if [[ ! -f "${ORACLE_SUB}" ]]; then
      echo "[MAKE] ${ORACLE_SUB} (head -n ${N} from ${ORACLE_FULL})"
      head -n "${N}" "${ORACLE_FULL}" > "${ORACLE_SUB}"
    fi

    CKPT="${CKPT_DIR}/router_policy_v2_B${B}_E${E}_N${N}.pt"
    TRAIN_LOG="${OUT_DIR}/train_router_B${B}_E${E}_N${N}.log"
    EVAL_LOG="${OUT_DIR}/eval_router_only_B${B}_E${E}_N${N}_${SPLIT}_L${LIMIT}.log"

    # -------------------------
    # 1) Train router
    # -------------------------
    echo "[TRAIN] E=${E} N=${N} -> ${CKPT}"
    set +e
    CUDA_VISIBLE_DEVICES="${CUDA_ID}" \
    PYTHONPATH="${ROOT}:${PYTHONPATH:-}" \
    DATASET_NAME="2wiki" \
    EMB_MODEL_PATH="${EMB_MODEL_PATH}" \
    "${PY}" -m mog_rag.train_router_from_oracle \
      --oracle "${ORACLE_SUB}" \
      --out "${CKPT}" \
      --epochs "${E}" --batch_size 128 --lr 2e-4 \
      > "${TRAIN_LOG}" 2>&1
    trc=$?
    set -e

    if [[ ${trc} -ne 0 || ! -f "${CKPT}" ]]; then
      status="TRAIN_CRASH(rc=${trc})"
      echo "[WARN] ${status} E=${E} N=${N}. see ${TRAIN_LOG}"
      echo "router,${B},${E},${N},${SPLIT},${LIMIT},${CKPT},${status},,,${TRAIN_LOG},${EVAL_LOG}" >> "${SUMMARY}"
      continue
    fi

    # -------------------------
    # 2) Eval router-only
    # -------------------------
    echo "[EVAL] router-only ckpt=${CKPT}"
    set +e
    CUDA_VISIBLE_DEVICES="${CUDA_ID}" \
    PYTHONPATH="${ROOT}:${PYTHONPATH:-}" \
    DATASET_NAME="2wiki" \
    DATA_ROOT="${DATA_ROOT}" \
    LLM_PATH="${LLM_PATH}" \
    USE_ROUTER="1" USE_BUDGETER="0" \
    ROUTER_CKPT="${CKPT}" \
    CTX_BUDGET="${CTX_BUDGET}" \
    STAGE1_TOTAL_TOPK="${STAGE1_TOTAL_TOPK}" \
    RERANK_TOP_M="${RERANK_TOP_M}" \
    TOTAL_TOPK="${TOTAL_TOPK}" \
    "${PY}" -m mog_rag.evaluate_hotpot \
      --split "${SPLIT}" --limit "${LIMIT}" \
      > "${EVAL_LOG}" 2>&1
    erc=$?
    set -e

    if [[ ${erc} -ne 0 ]]; then
      status="EVAL_CRASH(rc=${erc})"
      echo "[WARN] ${status} E=${E} N=${N}. see ${EVAL_LOG}"
      echo "router,${B},${E},${N},${SPLIT},${LIMIT},${CKPT},${status},,,${TRAIN_LOG},${EVAL_LOG}" >> "${SUMMARY}"
      continue
    fi

    read -r EM F1 < <(parse_emf1 "${EVAL_LOG}")
    status="OK"
    echo "router,${B},${E},${N},${SPLIT},${LIMIT},${CKPT},${status},${EM},${F1},${TRAIN_LOG},${EVAL_LOG}" >> "${SUMMARY}"

    echo "[OK] E=${E} N=${N} EM=${EM} F1=${F1}"
  done
done

echo "saved: ${SUMMARY}"
