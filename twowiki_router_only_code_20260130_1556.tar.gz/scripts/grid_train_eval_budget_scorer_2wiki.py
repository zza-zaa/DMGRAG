#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse
import csv
import os
import random
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def read_lines(path: Path) -> List[str]:
    with path.open("r", encoding="utf-8") as f:
        return f.readlines()


def write_lines(path: Path, lines: List[str]) -> None:
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        for ln in lines:
            f.write(ln if ln.endswith("\n") else ln + "\n")


def build_subset_oracle(full_oracle: Path, n: int, seed: int, out_path: Path) -> None:
    lines = read_lines(full_oracle)
    if n > len(lines):
        raise ValueError(f"N={n} > full_oracle lines={len(lines)}: {full_oracle}")
    rnd = random.Random(seed)
    idxs = list(range(len(lines)))
    rnd.shuffle(idxs)
    subset = [lines[i] for i in idxs[:n]]
    write_lines(out_path, subset)


def run_cmd_to_log(cmd: List[str], env: Dict[str, str], log_path: Path) -> int:
    ensure_dir(log_path.parent)
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[CMD] " + " ".join(cmd) + "\n")
        keys = [
            "CUDA_VISIBLE_DEVICES", "PYTHONPATH", "DATASET_NAME", "DATA_ROOT",
            "EMB_MODEL_PATH", "LLM_PATH", "RERANKER_MODEL_PATH",
            "USE_ROUTER", "USE_BUDGETER", "BUDGETER_CKPT",
            "CTX_BUDGET", "TOTAL_TOPK", "STAGE1_TOTAL_TOPK", "RERANK_TOP_M",
            "TOKENIZERS_PARALLELISM", "SEED", "PYTHONHASHSEED",
        ]
        for k in keys:
            if k in env:
                f.write(f"[ENV] {k}={env.get(k,'')}\n")
        f.write("\n")
        p = subprocess.run(cmd, env=env, stdout=f, stderr=subprocess.STDOUT)
        return int(p.returncode)


def parse_em_f1_from_log(log_path: Path) -> Tuple[Optional[float], Optional[float]]:
    try:
        txt = log_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None, None

    em = None
    f1 = None

    # EM=0.491000 F1=0.573000
    for m in re.finditer(r"\bEM\s*=\s*([0-9]*\.?[0-9]+)\b", txt):
        try:
            em = float(m.group(1))
        except Exception:
            pass
    for m in re.finditer(r"\bF1\s*=\s*([0-9]*\.?[0-9]+)\b", txt):
        try:
            f1 = float(m.group(1))
        except Exception:
            pass

    # handle percent
    if em is not None and 1.0 < em <= 100.0:
        em /= 100.0
    if f1 is not None and 1.0 < f1 <= 100.0:
        f1 /= 100.0

    return em, f1


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cuda", type=int, required=True, help="physical GPU id (2/3/5/6/7)")
    ap.add_argument("--epochs", type=int, required=True, help="train epochs for this run")
    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--split", type=str, default="dev")
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--smoke", type=int, default=0, help="if 1 -> limit=20")
    ap.add_argument("--Ns", type=str, default="1000,5000,10000,15000,20000")

    # your confirmed full oracle
    ap.add_argument("--full_oracle", type=str, default="data/oracle_policy_train_v2_B5200_N20000.jsonl")
    ap.add_argument("--py", type=str, default="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python")

    # match your correct training command
    ap.add_argument("--lr", type=str, default="2e-4")
    ap.add_argument("--accum", type=int, default=64)

    # eval params
    ap.add_argument("--ctx_budget", type=int, default=5200)
    ap.add_argument("--total_topk", type=int, default=100)
    ap.add_argument("--stage1_total_topk", type=int, default=160)
    ap.add_argument("--rerank_top_m", type=int, default=160)

    args = ap.parse_args()

    root = Path("/mnt/raid/peiyu/twowiki_router_only")
    os.chdir(str(root))

    full_oracle = Path(args.full_oracle)
    if not full_oracle.exists():
        raise SystemExit(f"[FATAL] full_oracle not found: {full_oracle}")

    Ns = [int(x) for x in args.Ns.split(",") if x.strip()]
    E = int(args.epochs)
    limit = 20 if int(args.smoke) == 1 else int(args.limit)

    # output dirs
    ckpt_dir = root / "ckpts" / "grid_budgeter_B5200"
    log_dir = root / "logs" / f"grid_budgeter_train_eval_B{args.B}_E{E}"
    oracle_tmp_dir = root / "data" / "tmp_budget_oracles_B5200"
    ensure_dir(ckpt_dir)
    ensure_dir(log_dir)
    ensure_dir(oracle_tmp_dir)

    summary_path = log_dir / "summary.csv"
    write_header = not summary_path.exists()

    # base env (align with your correct command)
    base_env = dict(os.environ)
    base_env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
    base_env["TOKENIZERS_PARALLELISM"] = "false"
    base_env["PYTHONPATH"] = str(root) + ":" + base_env.get("PYTHONPATH", "")
    base_env["DATASET_NAME"] = "2wiki"
    base_env["SEED"] = str(args.seed)
    base_env["PYTHONHASHSEED"] = str(args.seed)

    with summary_path.open("a", encoding="utf-8", newline="") as fcsv:
        w = csv.writer(fcsv)
        if write_header:
            w.writerow([
                "mode", "B", "epoch", "n_train", "split", "limit",
                "ckpt", "rc_train", "rc_eval", "status", "EM", "F1",
                "train_log", "eval_log", "oracle_subset"
            ])

        for N in Ns:
            subset_path = oracle_tmp_dir / f"budget_oracle_train_B{args.B}_E{E}_N{N}_seed{args.seed}.jsonl"
            print(f"[ORACLE] build subset N={N} seed={args.seed} -> {subset_path}")
            build_subset_oracle(full_oracle, N, args.seed, subset_path)

            ckpt_path = ckpt_dir / f"budget_regressor_v2_B{args.B}_E{E}_N{N}.pt"
            train_log = log_dir / f"train_budget_scorer_B{args.B}_E{E}_N{N}.log"
            eval_log = log_dir / f"eval_budgeter_only_B{args.B}_E{E}_N{N}_{args.split}_L{limit}.log"

            # -------- TRAIN (exactly match your working command style) --------
            train_cmd = [
                args.py, "-m", "mog_rag.train_budget_scorer_from_oracle",
                "--oracle", str(subset_path),
                "--out", str(ckpt_path),
                "--epochs", str(E),
                "--lr", str(args.lr),
                "--accum", str(args.accum),
            ]
            print(f"[TRAIN] cuda={args.cuda} B={args.B} E={E} N={N} -> {ckpt_path}")
            rc_train = run_cmd_to_log(train_cmd, base_env, train_log)

            if rc_train != 0 or (not ckpt_path.exists()):
                print(f"[TRAIN][FAIL] E={E} N={N} rc={rc_train} log={train_log}")
                w.writerow([
                    "budgeter_train_eval", args.B, E, N, args.split, limit,
                    str(ckpt_path), rc_train, "", f"TRAIN_FAIL(rc={rc_train})",
                    "", "", str(train_log), str(eval_log), str(subset_path)
                ])
                fcsv.flush()
                continue

            print(f"[TRAIN][OK]  saved {ckpt_path}")

            # -------- EVAL (budgeter-only) --------
            eval_env = dict(base_env)
            eval_env["USE_ROUTER"] = "0"
            eval_env["USE_BUDGETER"] = "1"
            eval_env["BUDGETER_CKPT"] = str(ckpt_path)
            eval_env["CTX_BUDGET"] = str(args.ctx_budget)
            eval_env["TOTAL_TOPK"] = str(args.total_topk)
            eval_env["STAGE1_TOTAL_TOPK"] = str(args.stage1_total_topk)
            eval_env["RERANK_TOP_M"] = str(args.rerank_top_m)

            eval_cmd = [args.py, "-m", "mog_rag.evaluate_hotpot", "--split", args.split, "--limit", str(limit)]
            print(f"[EVAL]  budgeter-only ckpt={ckpt_path} split={args.split} limit={limit}")
            rc_eval = run_cmd_to_log(eval_cmd, eval_env, eval_log)

            em, f1 = parse_em_f1_from_log(eval_log)
            status = "OK" if (rc_eval == 0 and em is not None and f1 is not None) else f"EVAL_FAIL(rc={rc_eval})"
            print(f"[EVAL]  rc={rc_eval} EM={em} F1={f1} log={eval_log}")

            w.writerow([
                "budgeter_train_eval", args.B, E, N, args.split, limit,
                str(ckpt_path), rc_train, rc_eval, status,
                "" if em is None else f"{em:.6f}",
                "" if f1 is None else f"{f1:.6f}",
                str(train_log), str(eval_log), str(subset_path)
            ])
            fcsv.flush()

    print(f"saved: {summary_path}")


if __name__ == "__main__":
    main()
