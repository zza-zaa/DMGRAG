#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Grid train+eval for 2Wiki Router (B=5200 labels).

- Train Router for epochs in {1,3,5,7,9} and n_train in {1000,5000,10000,15000,20000}
- Eval router-only on 2Wiki dev/test with --limit (default 1500)
- Save logs + summary.csv

Smoke:
  /mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python scripts/grid_train_eval_router_2wiki.py --cuda 1 --smoke 1

Full:
  /mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python scripts/grid_train_eval_router_2wiki.py --cuda 1 --split dev --limit 1500
"""

from __future__ import annotations
import argparse
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

RE_EM = re.compile(r"\bEM\s*=\s*([0-9]*\.?[0-9]+)")
RE_F1 = re.compile(r"\bF1\s*=\s*([0-9]*\.?[0-9]+)")

DEFAULT_EPOCHS = [1, 3, 5, 7, 9]
DEFAULT_NTRAIN = [1000, 5000, 10000, 15000, 20000]


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _tail_text(p: Path, n: int = 120) -> str:
    if not p.exists():
        return ""
    lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
    return "\n".join(lines[-n:])


def _parse_result(log_path: Path) -> Tuple[Optional[float], Optional[float]]:
    txt = _tail_text(log_path, 250)
    em, f1 = None, None
    m1 = RE_EM.search(txt)
    m2 = RE_F1.search(txt)
    if m1:
        try:
            em = float(m1.group(1))
        except Exception:
            em = None
    if m2:
        try:
            f1 = float(m2.group(1))
        except Exception:
            f1 = None
    return em, f1


def _is_argparse_error(log_tail: str) -> bool:
    s = (log_tail or "").lower()
    return ("unrecognized arguments" in s) or ("usage:" in s and "error:" in s)


def _run(cmd: List[str], env: Dict[str, str], log_path: Path) -> int:
    _ensure_dir(log_path.parent)
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[CMD] " + " ".join(shlex.quote(x) for x in cmd) + "\n")
        keys = (
            "PYTHONPATH", "CUDA_VISIBLE_DEVICES", "DATASET_NAME", "DATA_ROOT",
            "USE_ROUTER", "USE_BUDGETER", "ROUTER_CKPT", "ROUTER_CKPT_OUT",
            "CTX_BUDGET", "STAGE1_TOTAL_TOPK", "RERANK_TOP_M", "TOTAL_TOPK",
            "TRAIN_BUDGET", "LABEL_BUDGET", "BUDGET"
        )
        for k in keys:
            if k in env:
                f.write(f"[ENV] {k}={env[k]}\n")
        f.write("\n")
        f.flush()
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, env=env)
        return int(proc.returncode)


def _candidate_train_modules() -> List[str]:
    # 你项目里可能叫这些名字；找得到哪个就用哪个
    return [
        "mog_rag.train_router_policy",
        "mog_rag.train_router",
        "mog_rag.train_router_only",
        "mog_rag.train_router_mlp",
        "mog_rag.train_router_v2",
        "mog_rag.train_router_policy_v2",
    ]


def _find_train_module(repo: Path) -> Optional[str]:
    # 关键：先让当前进程能 import mog_rag，再 find_spec
    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))
    import importlib.util
    for m in _candidate_train_modules():
        try:
            if importlib.util.find_spec(m) is not None:
                return m
        except Exception:
            continue
    return None


def _train_variants(python: str, module: str, E: int, N: int, B: int, ckpt: Path) -> List[List[str]]:
    base = [python, "-m", module]
    # 多种常见参数名；哪个能跑通用哪个
    return [
        base + ["--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--save", str(ckpt)],
        base + ["--epochs", str(E), "--n_train", str(N), "--ctx_budget", str(B), "--ckpt", str(ckpt)],
        base + ["--epoch", str(E), "--train_size", str(N), "--budget", str(B), "--out", str(ckpt)],
        base + ["--epochs", str(E), "--n_train", str(N), "--out_ckpt", str(ckpt)],
        base + ["--epochs", str(E), "--n_train", str(N), "--save_path", str(ckpt)],
        base + ["--epochs", str(E), "--n_train", str(N)],  # rely on env/output defaults
    ]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cuda", type=int, default=0, help="CUDA_VISIBLE_DEVICES")
    ap.add_argument("--B", type=int, default=5200, help="Budget B for labels/training")
    ap.add_argument("--split", type=str, default="dev", choices=["dev", "test"])
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--epochs", type=str, default="1,3,5,7,9")
    ap.add_argument("--n_train", type=str, default="1000,5000,10000,15000,20000")
    ap.add_argument("--smoke", type=int, default=0, help="1: quick sanity run (E=1,N=1000,limit=20)")
    ap.add_argument("--force_train", type=int, default=0, help="1: retrain even if ckpt exists")
    ap.add_argument("--python", type=str, default=sys.executable, help="python executable to use for subprocs")
    ap.add_argument("--llm_path", type=str, default="/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct")
    ap.add_argument("--data_root", type=str, default="", help="optional DATA_ROOT")
    ap.add_argument("--train_cmd", type=str, default="",
                    help='Optional custom train cmd template. Placeholders: {PY},{E},{N},{B},{CKPT}')
    ap.add_argument("--train_module", type=str, default="",
                    help="Optional: explicitly specify training module, e.g., mog_rag.train_router_policy")
    args = ap.parse_args()

    if args.smoke:
        epochs_list = [1]
        ntrain_list = [1000]
        limit = 20
    else:
        epochs_list = [int(x) for x in args.epochs.split(",") if x.strip()]
        ntrain_list = [int(x) for x in args.n_train.split(",") if x.strip()]
        limit = int(args.limit)

    repo = Path(__file__).resolve().parents[1]
    # 关键修复：当前进程可 import mog_rag（否则 find_spec 会报 mog_rag not found）
    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))

    logs_dir = repo / "logs" / f"grid_train_eval_router_2wiki_B{args.B}"
    ckpt_dir = repo / "ckpts"
    _ensure_dir(logs_dir)
    _ensure_dir(ckpt_dir)

    summary_path = logs_dir / "summary.csv"
    if not summary_path.exists():
        summary_path.write_text(
            "mode,B,epoch,n_train,split,limit,ckpt,status,EM,F1,train_log,eval_log\n",
            encoding="utf-8",
        )

    base_env = os.environ.copy()
    base_env["PYTHONPATH"] = str(repo) + (":" + base_env["PYTHONPATH"] if base_env.get("PYTHONPATH") else "")
    base_env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
    base_env["DATASET_NAME"] = "2wiki"
    if args.data_root.strip():
        base_env["DATA_ROOT"] = args.data_root.strip()
    base_env["LLM_PATH"] = args.llm_path

    # B=5200 label semantics
    base_env["CTX_BUDGET"] = str(args.B)
    base_env["TRAIN_BUDGET"] = str(args.B)
    base_env["LABEL_BUDGET"] = str(args.B)
    base_env["BUDGET"] = str(args.B)

    # match your evaluation pipeline
    base_env["STAGE1_TOTAL_TOPK"] = "160"
    base_env["RERANK_TOP_M"] = "160"
    base_env["TOTAL_TOPK"] = "100"

    train_cmd_tmpl = args.train_cmd.strip()
    module = args.train_module.strip() or None
    if not train_cmd_tmpl and not module:
        module = _find_train_module(repo)

    if not train_cmd_tmpl and not module:
        raise RuntimeError(
            "No router training entrypoint found in this repo. "
            "Please provide --train_cmd or --train_module."
        )

    for E in epochs_list:
        for N in ntrain_list:
            ckpt = ckpt_dir / f"router_policy_v2_B{args.B}_E{E}_N{N}.pt"
            train_log = logs_dir / f"train_router_B{args.B}_E{E}_N{N}.log"
            eval_log = logs_dir / f"eval_router_only_B{args.B}_E{E}_N{N}_{args.split}_L{limit}.log"

            # -------- Train --------
            if ckpt.exists() and not args.force_train:
                train_status = "SKIP_TRAIN_EXISTS"
            else:
                env = dict(base_env)
                env["USE_ROUTER"] = "1"
                env["USE_BUDGETER"] = "0"
                env["ROUTER_CKPT_OUT"] = str(ckpt)

                rc = 1
                if train_cmd_tmpl:
                    cmd_str = train_cmd_tmpl.format(PY=args.python, E=E, N=N, B=args.B, CKPT=str(ckpt))
                    cmd = shlex.split(cmd_str)
                    rc = _run(cmd, env, train_log)
                else:
                    assert module is not None
                    for cmd in _train_variants(args.python, module, E, N, args.B, ckpt):
                        rc = _run(cmd, env, train_log)
                        if rc == 0:
                            break
                        tail = _tail_text(train_log, 120)
                        if _is_argparse_error(tail):
                            continue
                        break  # non-argparse crash, stop trying

                if rc != 0:
                    with summary_path.open("a", encoding="utf-8") as f:
                        f.write(f"router,{args.B},{E},{N},{args.split},{limit},{ckpt},TRAIN_CRASH(rc={rc}),,,{train_log},{eval_log}\n")
                    continue

                train_status = "TRAIN_OK"
                if not ckpt.exists():
                    train_status = "TRAIN_OK_BUT_CKPT_NOT_FOUND"

            # -------- Eval (router-only) --------
            env2 = dict(base_env)
            env2["USE_ROUTER"] = "1"
            env2["USE_BUDGETER"] = "0"
            env2["ROUTER_CKPT"] = str(ckpt)
            env2.pop("BUDGETER_CKPT", None)

            eval_cmd = [args.python, "-m", "mog_rag.evaluate_hotpot", "--split", args.split, "--limit", str(limit)]
            rc2 = _run(eval_cmd, env2, eval_log)
            if rc2 != 0:
                with summary_path.open("a", encoding="utf-8") as f:
                    f.write(f"router,{args.B},{E},{N},{args.split},{limit},{ckpt},EVAL_CRASH(rc={rc2}),,,{train_log},{eval_log}\n")
                continue

            em, f1 = _parse_result(eval_log)
            with summary_path.open("a", encoding="utf-8") as f:
                f.write(f"router,{args.B},{E},{N},{args.split},{limit},{ckpt},OK,{em},{f1},{train_log},{eval_log}\n")

    print(f"saved: {summary_path}")


if __name__ == "__main__":
    main()
