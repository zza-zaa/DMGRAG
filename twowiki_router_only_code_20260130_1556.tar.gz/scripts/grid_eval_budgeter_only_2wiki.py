#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Grid eval: budgeter-only on 2Wiki (B=5200 labels).
Vary epochs and train sizes, evaluate on dev with limit=1500 by default.

Key points:
- Strictly select budgeter ckpts (budget/regressor in filename), exclude router ckpts.
- Missing ckpt -> SKIP (no crash).
- If a run fails, print tail of the log for quick debugging.

Example:
  cd /mnt/raid/peiyu/twowiki_router_only
  python scripts/grid_eval_budgeter_only_2wiki.py --smoke 1 --cuda 1 --ckpt /mnt/raid/peiyu/twowiki_router_only/budget_regressor_v2_B5200.pt
"""

from __future__ import annotations
import argparse
import csv
import os
import re
import sys
import time
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple, Dict


RESULT_RE = re.compile(r"\[RESULT\]\s+N=(\d+)\s+EM=([0-9.]+)\s+F1=([0-9.]+)")


def parse_list_int(s: str) -> List[int]:
    s = (s or "").strip()
    if not s:
        return []
    out = []
    for x in re.split(r"[,\s]+", s):
        x = x.strip()
        if not x:
            continue
        out.append(int(x))
    return out


def tail_text(path: Path, n_lines: int = 80) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        return "".join(lines[-n_lines:])
    except Exception:
        return ""


def find_budgeter_ckpt(ckpt_dir: Path, B: int, E: int, N: int) -> Optional[Path]:
    """
    Only match budgeter ckpts. Exclude router ckpts aggressively.
    Recommended naming:
      budget_regressor_*_B{B}_E{E}_N{N}.pt
    """
    patterns = [
        f"*budget*B{B}*E{E}*N{N}*.pt",
        f"*regressor*B{B}*E{E}*N{N}*.pt",
        f"*budgeter*B{B}*E{E}*N{N}*.pt",
    ]
    cand: List[Path] = []
    for pat in patterns:
        cand.extend(list(ckpt_dir.glob(pat)))

    # exclude router-like ckpts
    filtered = []
    for p in cand:
        name = p.name.lower()
        if "router" in name or "policy" in name:
            continue
        # must contain budget/regressor/budgeter keyword to be safe
        if ("budget" not in name) and ("regressor" not in name) and ("budgeter" not in name):
            continue
        filtered.append(p)

    if not filtered:
        return None
    if len(filtered) == 1:
        return filtered[0]

    # multiple matches -> pick latest modified
    filtered.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return filtered[0]


def run_eval(
    *,
    project_root: Path,
    logs_dir: Path,
    cuda: Optional[int],
    B: int,
    E: int,
    N: int,
    split: str,
    limit: int,
    llm_path: Optional[str],
    budgeter_ckpt: Path,
) -> Tuple[int, Optional[float], Optional[float], Path, str]:
    """
    Return: (rc, EM, F1, log_path, status)
    """
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_path = logs_dir / f"budgeter_only_B{B}_E{E}_N{N}_{split}_L{limit}.log"

    env = os.environ.copy()
    if cuda is not None:
        env["CUDA_VISIBLE_DEVICES"] =str(cuda)

    env["DATASET_NAME"] = "2wiki"
    # keep existing DATA_ROOT if user set; otherwise don't force
    # env["DATA_ROOT"] = env.get("DATA_ROOT", "/mnt/raid/peiyu/data")

    if llm_path:
        env["LLM_PATH"] = llm_path

    # budgeter-only
    env["USE_ROUTER"] = "0"
    env["USE_BUDGETER"] = "1"
    env["BUDGETER_CKPT"] = str(budgeter_ckpt)

    # keep same retrieval hyperparams you used in 2wiki
    env["CTX_BUDGET"] = str(B)
    env["STAGE1_TOTAL_TOPK"] = env.get("STAGE1_TOTAL_TOPK", "160")
    env["RERANK_TOP_M"] = env.get("RERANK_TOP_M", "160")
    env["TOTAL_TOPK"] = env.get("TOTAL_TOPK", "100")

    # run
    pybin = os.environ.get("PYTHON_BIN", "").strip() or sys.executable
    cmd = [
        sys.executable,
        "-m",
        "mog_rag.evaluate_hotpot",
        "--split",
        split,
        "--limit",
        str(limit),
    ]

    with log_path.open("w", encoding="utf-8") as f:
        f.write(f"[CMD] {' '.join(cmd)}\n")
        f.write(f"[ENV] CUDA_VISIBLE_DEVICES={env.get('CUDA_VISIBLE_DEVICES','')}\n")
        f.write(f"[ENV] DATASET_NAME={env.get('DATASET_NAME','')}\n")
        f.write(f"[ENV] USE_ROUTER={env.get('USE_ROUTER','')}, USE_BUDGETER={env.get('USE_BUDGETER','')}\n")
        f.write(f"[ENV] BUDGETER_CKPT={env.get('BUDGETER_CKPT','')}\n")
        f.write(f"[ENV] CTX_BUDGET={env.get('CTX_BUDGET','')}, STAGE1_TOTAL_TOPK={env.get('STAGE1_TOTAL_TOPK','')}, "
                f"RERANK_TOP_M={env.get('RERANK_TOP_M','')}, TOTAL_TOPK={env.get('TOTAL_TOPK','')}\n\n")
        f.flush()

        proc = subprocess.run(cmd, cwd=str(project_root), env=env, stdout=f, stderr=subprocess.STDOUT)
        rc = int(proc.returncode)

    # parse result if success
    text = log_path.read_text(encoding="utf-8", errors="ignore")
    m = RESULT_RE.search(text)
    if m:
        em = float(m.group(2))
        f1 = float(m.group(3))
    else:
        em, f1 = None, None

    status = "OK" if (rc == 0 and em is not None and f1 is not None) else ("CRASH" if rc != 0 else "NO_RESULT_LINE")
    return rc, em, f1, log_path, status


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--epochs", type=str, default="1,3,5,7,9")
    ap.add_argument("--train_sizes", type=str, default="1000,5000,10000,15000,20000")
    ap.add_argument("--split", type=str, default="dev")
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--cuda", type=int, default=None)
    ap.add_argument("--smoke", type=int, default=0)
    ap.add_argument("--llm_path", type=str, default=None)

    # ckpt selection
    ap.add_argument("--ckpt_dir", type=str, default=None,
                    help="Directory to search budgeter ckpts. default: project root.")
    ap.add_argument("--ckpt", type=str, default=None,
                    help="Use a single budgeter ckpt for ALL grid points (useful for smoke).")

    args = ap.parse_args()

    project_root = Path(__file__).resolve().parents[1]
    logs_dir = project_root / "logs" / f"grid_budgeter_only_2wiki_B{args.B}"
    logs_dir.mkdir(parents=True, exist_ok=True)

    if args.smoke:
        epochs = [3]
        train_sizes = [20000]
        limit = 20
    else:
        epochs = parse_list_int(args.epochs)
        train_sizes = parse_list_int(args.train_sizes)
        limit = int(args.limit)

    ckpt_dir = Path(args.ckpt_dir).resolve() if args.ckpt_dir else project_root
    single_ckpt = Path(args.ckpt).resolve() if args.ckpt else None

    rows: List[Dict[str, object]] = []
    for E in epochs:
        for N in train_sizes:
            if single_ckpt is not None:
                ckpt = single_ckpt
                ckpt_note = "single_ckpt"
            else:
                ckpt = find_budgeter_ckpt(ckpt_dir, args.B, E, N)
                ckpt_note = "matched" if ckpt else "missing"

            if ckpt is None or (not ckpt.exists()):
                row = {
                    "mode": "budgeter_only",
                    "B": args.B,
                    "epoch": E,
                    "n_train": N,
                    "split": args.split,
                    "limit": limit,
                    "ckpt": "" if ckpt is None else str(ckpt),
                    "rc": "",
                    "status": "MISSING_CKPT",
                    "EM": "",
                    "F1": "",
                }
                print(f"[SKIP] missing budgeter ckpt for E={E}, N={N} under {ckpt_dir}")
                rows.append(row)
                continue

            print(f"[RUN] E={E} N={N} ckpt={ckpt} ({ckpt_note})")
            rc, em, f1, log_path, status = run_eval(
                project_root=project_root,
                logs_dir=logs_dir,
                cuda=args.cuda,
                B=args.B,
                E=E,
                N=N,
                split=args.split,
                limit=limit,
                llm_path=args.llm_path,
                budgeter_ckpt=ckpt,
            )

            if status != "OK":
                print(f"[WARN] status={status} rc={rc} for E={E}, N={N}. log={log_path}")
                print("----- log tail -----")
                print(tail_text(log_path, 80))
                print("--------------------")

            rows.append({
                "mode": "budgeter_only",
                "B": args.B,
                "epoch": E,
                "n_train": N,
                "split": args.split,
                "limit": limit,
                "ckpt": str(ckpt),
                "rc": rc,
                "status": status,
                "EM": "" if em is None else f"{em:.6f}",
                "F1": "" if f1 is None else f"{f1:.6f}",
            })

    out_csv = logs_dir / "summary.csv"
    with out_csv.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "mode","B","epoch","n_train","split","limit","ckpt","rc","status","EM","F1"
        ])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    print(f"saved: {out_csv}")


if __name__ == "__main__":
    main()
