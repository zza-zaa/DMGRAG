#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Train+Eval Budgeter-only on 2Wiki for a grid of (epoch, n_train).
- Subsample from one FULL oracle jsonl (N=20000) with fixed seed.
- Train budgeter -> save ckpt
- Eval budgeter-only on 2wiki dev -> parse EM/F1 -> write summary.csv

Usage example:
  /path/to/python scripts/grid_train_eval_budgeter_2wiki.py \
    --cuda 3 --epochs 3 --B 5200 --limit 1500 \
    --full_oracle data/<YOUR_BUDGET_ORACLE_20000>.jsonl
"""

import argparse, os, sys, re, csv, json, random, subprocess, time
from pathlib import Path
from typing import Optional, Tuple, List


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--split", type=str, default="dev")
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--cuda", type=int, default=0, help="physical gpu id for CUDA_VISIBLE_DEVICES")
    ap.add_argument("--epochs", type=str, required=True, help="single epoch or comma list, e.g. 1 or 1,3,5")
    ap.add_argument("--ns", type=str, default="1000,5000,10000,15000,20000")
    ap.add_argument("--seed", type=int, default=42, help="seed for subsampling")
    ap.add_argument("--smoke", type=int, default=0, help="1 => limit=20 and only N=1000")
    ap.add_argument("--force", type=int, default=0, help="1 => retrain even if ckpt exists")

    # paths
    ap.add_argument("--ckpt_dir", type=str, default="ckpts/grid_budgeter_B5200")
    ap.add_argument("--log_dir", type=str, default="logs/grid_budgeter_train_eval_B5200")
    ap.add_argument("--tmp_oracle_dir", type=str, default="data/tmp_budget_oracles_B5200")

    # budgeter training module (you can override if your module name differs)
    ap.add_argument("--train_module", type=str, default="", help="e.g., mog_rag.train_budgeter_from_oracle")
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--lr", type=float, default=2e-4)

    # FULL oracle file (2w lines)
    ap.add_argument("--full_oracle", type=str, default="", help="path to full N=20000 budget oracle jsonl")

    # env passthrough (optional but recommended)
    ap.add_argument("--data_root", type=str, default=os.getenv("DATA_ROOT", "/mnt/raid/peiyu/data"))
    ap.add_argument("--llm_path", type=str, default=os.getenv("LLM_PATH", os.getenv("LLM_MODEL_PATH", "")))
    ap.add_argument("--emb_model_path", type=str, default=os.getenv("EMB_MODEL_PATH", ""))
    ap.add_argument("--reranker_model_path", type=str, default=os.getenv("RERANKER_MODEL_PATH", ""))
    return ap.parse_args()


def _parse_list_int(s: str) -> List[int]:
    out = []
    for x in (s or "").split(","):
        x = x.strip()
        if not x:
            continue
        out.append(int(x))
    return out


def _read_all_lines(p: Path) -> List[str]:
    with p.open("r", encoding="utf-8") as f:
        return f.readlines()


def make_oracle_subset(full_oracle: Path, out_path: Path, n: int, seed: int) -> None:
    lines = _read_all_lines(full_oracle)
    if n > len(lines):
        raise ValueError(f"Requested n={n} but full_oracle has only {len(lines)} lines: {full_oracle}")
    rng = random.Random(seed)
    idxs = list(range(len(lines)))
    rng.shuffle(idxs)
    chosen = idxs[:n]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as w:
        for i in chosen:
            w.write(lines[i])


def pick_full_oracle_auto(root: Path, B: int) -> Optional[Path]:
    # Try to find a budget oracle file in data/ by pattern
    cand = []
    data_dir = root / "data"
    if not data_dir.exists():
        return None
    pats = [
        f"*budget*B{B}*N20000*.jsonl",
        f"*Budget*B{B}*N20000*.jsonl",
        f"*oracle*budget*B{B}*N20000*.jsonl",
        f"*budget*{B}*20000*.jsonl",
    ]
    for pat in pats:
        cand.extend(sorted(data_dir.glob(pat)))
    # remove duplicates
    uniq = []
    seen = set()
    for p in cand:
        rp = str(p.resolve())
        if rp not in seen:
            seen.add(rp); uniq.append(p)
    return uniq[0].resolve() if uniq else None


def run_cmd(cmd: List[str], env: dict, log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as lf:
        lf.write("[CMD] " + " ".join(cmd) + "\n")
        for k in ["CUDA_VISIBLE_DEVICES", "DATASET_NAME", "DATA_ROOT", "USE_ROUTER", "USE_BUDGETER",
                  "BUDGETER_CKPT", "CTX_BUDGET", "STAGE1_TOTAL_TOPK", "RERANK_TOP_M", "TOTAL_TOPK",
                  "LLM_PATH", "EMB_MODEL_PATH", "RERANKER_MODEL_PATH", "PYTHONPATH"]:
            if k in env and env[k]:
                lf.write(f"[ENV] {k}={env[k]}\n")
        lf.write("\n")
        lf.flush()
        p = subprocess.run(cmd, env=env, stdout=lf, stderr=subprocess.STDOUT)
        return p.returncode


def parse_emf1_from_eval_log(log_path: Path) -> Tuple[Optional[float], Optional[float]]:
    txt = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    em = f1 = None
    # try to catch patterns like "EM=0.491 F1=0.573" or "EM: 0.491  F1: 0.573"
    pat = re.compile(r"\bEM\b\s*[:=]\s*([0-9.]+).*?\bF1\b\s*[:=]\s*([0-9.]+)", re.IGNORECASE)
    for line in reversed(txt):
        m = pat.search(line)
        if m:
            em = float(m.group(1)); f1 = float(m.group(2))
            break
    return em, f1


def detect_train_module(root: Path, prefer: str = "") -> List[str]:
    # Try user-given first, then common candidates
    cands = []
    if prefer:
        cands.append(prefer)
    cands += [
        "mog_rag.train_budgeter_from_oracle",
        "mog_rag.train_budget_regressor_from_oracle",
        "mog_rag.train_budgeter",
        "mog_rag.train_budget_regressor",
    ]
    # Filter by importable: `python -c "import importlib; importlib.import_module('...')"`
    py = sys.executable
    ok = []
    for m in cands:
        try:
            rc = subprocess.run(
                [py, "-c", f"import importlib; importlib.import_module('{m}')"],
                cwd=str(root),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode
            if rc == 0:
                ok.append(m)
        except Exception:
            pass
    return ok


def build_train_cmd(module: str, oracle_path: Path, ckpt_path: Path, epochs: int, bs: int, lr: float) -> List[List[str]]:
    """
    Return a list of candidate CLI forms to try (arg name variations).
    """
    py = sys.executable
    # Most-likely form (mirrors your router training style):
    tries = [
        [py, "-m", module, "--oracle", str(oracle_path), "--out", str(ckpt_path),
         "--epochs", str(epochs), "--batch_size", str(bs), "--lr", str(lr)],
        [py, "-m", module, "--oracle", str(oracle_path), "--out", str(ckpt_path),
         "--epochs", str(epochs), "--batch_size", str(bs)],
        # other common variants
        [py, "-m", module, "--train", str(oracle_path), "--out", str(ckpt_path),
         "--epochs", str(epochs), "--batch_size", str(bs), "--lr", str(lr)],
        [py, "-m", module, "--data", str(oracle_path), "--out", str(ckpt_path),
         "--epochs", str(epochs), "--batch_size", str(bs), "--lr", str(lr)],
    ]
    return tries


def main():
    args = parse_args()
    root = Path(__file__).resolve().parents[1]  # twowiki_router_only/
    os.chdir(root)

    epochs = _parse_list_int(args.epochs)
    ns = _parse_list_int(args.ns)

    if args.smoke == 1:
        args.limit = 20
        ns = [1000]

    ckpt_dir = (root / args.ckpt_dir).resolve()
    log_dir = (root / args.log_dir).resolve()
    tmp_oracle_dir = (root / args.tmp_oracle_dir).resolve()
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    tmp_oracle_dir.mkdir(parents=True, exist_ok=True)

    # Resolve full oracle
    full_oracle = Path(args.full_oracle).resolve() if args.full_oracle else None
    if not full_oracle or not full_oracle.exists():
        auto = pick_full_oracle_auto(root, args.B)
        if auto and auto.exists():
            full_oracle = auto
        else:
            print("[FATAL] full_oracle not found. Please pass --full_oracle data/<budget_oracle_B5200_N20000>.jsonl")
            sys.exit(2)

    # Detect training module(s)
    train_modules = detect_train_module(root, args.train_module)
    if not train_modules:
        print("[FATAL] Cannot import any budgeter training module. "
              "Set --train_module to your actual module (e.g., mog_rag.train_budgeter_from_oracle).")
        sys.exit(2)

    summary_csv = log_dir / "summary.csv"
    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "mode", "B", "epoch", "n_train", "split", "limit",
            "oracle_subset", "ckpt", "train_rc", "eval_rc", "status", "EM", "F1",
            "train_log", "eval_log"
        ])

        # Common eval env (budgeter-only)
        base_env = os.environ.copy()
        base_env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
        base_env["PYTHONPATH"] = str(root) + (":" + base_env["PYTHONPATH"] if base_env.get("PYTHONPATH") else "")
        base_env["DATASET_NAME"] = "2wiki"
        base_env["DATA_ROOT"] = args.data_root
        base_env["USE_ROUTER"] = "0"
        base_env["USE_BUDGETER"] = "1"
        base_env["CTX_BUDGET"] = str(args.B)
        base_env["STAGE1_TOTAL_TOPK"] = "160"
        base_env["RERANK_TOP_M"] = "160"
        base_env["TOTAL_TOPK"] = "100"
        base_env["FAISS_GPU_ID"] = "0"
        base_env["PYTHONHASHSEED"] = str(args.seed)
        base_env["SEED"] = str(args.seed)

        if args.llm_path:
            base_env["LLM_PATH"] = args.llm_path
        if args.emb_model_path:
            base_env["EMB_MODEL_PATH"] = args.emb_model_path
        if args.reranker_model_path:
            base_env["RERANKER_MODEL_PATH"] = args.reranker_model_path

        # Loop
        for e in epochs:
            for n in ns:
                oracle_subset = tmp_oracle_dir / f"budget_oracle_train_B{args.B}_E{e}_N{n}_seed{args.seed}.jsonl"
                ckpt = ckpt_dir / f"budget_regressor_v2_B{args.B}_E{e}_N{n}.pt"
                train_log = log_dir / f"train_budgeter_B{args.B}_E{e}_N{n}.log"
                eval_log = log_dir / f"eval_budgeter_only_B{args.B}_E{e}_N{n}_{args.split}_L{args.limit}.log"

                # Make oracle subset (deterministic)
                if (not oracle_subset.exists()) or args.force == 1:
                    print(f"[ORACLE] build subset N={n} seed={args.seed} -> {oracle_subset}")
                    make_oracle_subset(full_oracle, oracle_subset, n=n, seed=args.seed)

                # Train if needed
                train_rc = 0
                if (not ckpt.exists()) or args.force == 1:
                    t0 = time.time()
                    trained = False
                    last_rc = None

                    print(f"[TRAIN] cuda={args.cuda} B={args.B} E={e} N={n} -> {ckpt}")
                    for module in train_modules:
                        for cmd in build_train_cmd(module, oracle_subset, ckpt, e, args.batch_size, args.lr):
                            env = dict(base_env)
                            # training may not need dataset env, but keep PYTHONPATH + CUDA
                            rc = run_cmd(cmd, env, train_log)
                            last_rc = rc
                            if rc == 0 and ckpt.exists():
                                trained = True
                                break
                        if trained:
                            break

                    train_rc = int(last_rc if last_rc is not None else 1)

                    if not trained:
                        print(f"[TRAIN][FAIL] E={e} N={n} rc={train_rc} log={train_log}")
                        w.writerow(["budgeter_only", args.B, e, n, args.split, args.limit,
                                    str(oracle_subset), str(ckpt), train_rc, "", "TRAIN_CRASH", "", "",
                                    str(train_log), str(eval_log)])
                        f.flush()
                        continue
                    else:
                        print(f"[TRAIN][OK]  E={e} N={n} saved={ckpt}  ({time.time()-t0:.1f}s) log={train_log}")
                else:
                    print(f"[TRAIN][SKIP] ckpt exists: {ckpt}")

                # Eval budgeter-only
                env = dict(base_env)
                env["BUDGETER_CKPT"] = str(ckpt)

                eval_cmd = [sys.executable, "-m", "mog_rag.evaluate_hotpot", "--split", args.split, "--limit", str(args.limit)]
                print(f"[EVAL] cuda={args.cuda} E={e} N={n} ckpt={ckpt} split={args.split} L={args.limit}")
                eval_rc = run_cmd(eval_cmd, env, eval_log)

                if eval_rc != 0:
                    print(f"[EVAL][FAIL] E={e} N={n} rc={eval_rc} log={eval_log}")
                    w.writerow(["budgeter_only", args.B, e, n, args.split, args.limit,
                                str(oracle_subset), str(ckpt), train_rc, eval_rc, "EVAL_CRASH", "", "",
                                str(train_log), str(eval_log)])
                    f.flush()
                    continue

                em, f1 = parse_emf1_from_eval_log(eval_log)
                em_s = "" if em is None else f"{em:.6f}"
                f1_s = "" if f1 is None else f"{f1:.6f}"
                print(f"[EVAL][OK]  E={e} N={n} EM={em_s} F1={f1_s} log={eval_log}")

                w.writerow(["budgeter_only", args.B, e, n, args.split, args.limit,
                            str(oracle_subset), str(ckpt), train_rc, eval_rc, "OK", em_s, f1_s,
                            str(train_log), str(eval_log)])
                f.flush()

    print(f"saved: {summary_csv}")


if __name__ == "__main__":
    main()
