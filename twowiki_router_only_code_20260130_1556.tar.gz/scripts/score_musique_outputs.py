from __future__ import annotations
import argparse, json, re, string
from collections import Counter
from pathlib import Path

_ARTICLES = {"a", "an", "the"}

def normalize_answer(s: str) -> str:
    if s is None:
        return ""
    s = s.lower()

    # remove punctuation
    s = "".join(ch for ch in s if ch not in set(string.punctuation))

    # remove articles
    tokens = s.split()
    tokens = [t for t in tokens if t not in _ARTICLES]

    # fix whitespace
    return " ".join(tokens).strip()

def f1_score(pred: str, gold: str) -> float:
    pred_toks = normalize_answer(pred).split()
    gold_toks = normalize_answer(gold).split()
    if len(pred_toks) == 0 and len(gold_toks) == 0:
        return 1.0
    if len(pred_toks) == 0 or len(gold_toks) == 0:
        return 0.0
    common = Counter(pred_toks) & Counter(gold_toks)
    num_same = sum(common.values())
    if num_same == 0:
        return 0.0
    precision = num_same / len(pred_toks)
    recall = num_same / len(gold_toks)
    return 2 * precision * recall / (precision + recall)

def exact_match(pred: str, gold: str) -> float:
    return 1.0 if normalize_answer(pred) == normalize_answer(gold) else 0.0

def postprocess_pred(pred: str) -> str:
    """你的 closed-book 输出经常带一堆多余内容，这里按“第一行答案”做截断。"""
    if pred is None:
        return ""
    s = str(pred).strip()
    if not s:
        return ""
    # cut before common junk markers
    for mark in ["\nQuestion:", "\n\nQuestion:", "\nWhat is the next question", "\n\nWhat is the next question"]:
        if mark in s:
            s = s.split(mark, 1)[0].strip()
    # keep first non-empty line
    lines = [x.strip() for x in s.splitlines() if x.strip()]
    if lines:
        return lines[0]
    return s

def read_jsonl(path: str):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred_jsonl", required=True, help="outputs/*.jsonl from evaluate_closed_book")
    ap.add_argument("--gold_jsonl", required=True, help="MuSiQue *ans* file, e.g. musique_ans_v1.0_dev.jsonl")
    ap.add_argument("--out_jsonl", required=True, help="write scored jsonl")
    ap.add_argument("--limit", type=int, default=0, help="0 means all")
    args = ap.parse_args()

    gold_map = {}
    for ex in read_jsonl(args.gold_jsonl):
        qid = ex.get("id") or ex.get("qid") or ex.get("question_id") or ex.get("idx")
        if qid is None:
            continue
        ans = ex.get("answer", None)
        aliases = ex.get("answer_aliases", []) or []
        golds = []
        if ans is not None:
            golds.append(str(ans))
        for a in aliases:
            if a is None:
                continue
            a = str(a)
            if a and a not in golds:
                golds.append(a)
        gold_map[str(qid)] = golds

    out_path = Path(args.out_jsonl)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    total = 0
    em_sum = 0.0
    f1_sum = 0.0
    miss = 0

    with out_path.open("w", encoding="utf-8") as fout:
        for ex in read_jsonl(args.pred_jsonl):
            if args.limit and total >= args.limit:
                break
            qid = str(ex.get("qid") or ex.get("id") or ex.get("question_id") or ex.get("idx") or total)
            pred_raw = ex.get("pred", "")
            pred = postprocess_pred(pred_raw)

            golds = gold_map.get(qid, [])
            if not golds:
                miss += 1
                ex["gold"] = None
                ex["gold_list"] = None
                ex["em"] = None
                ex["f1"] = None
                fout.write(json.dumps(ex, ensure_ascii=False) + "\n")
                total += 1
                continue

            # pick best over multiple golds
            em = max(exact_match(pred, g) for g in golds)
            f1 = max(f1_score(pred, g) for g in golds)

            ex["pred_post"] = pred
            ex["gold"] = golds[0]
            ex["gold_list"] = golds
            ex["em"] = float(em)
            ex["f1"] = float(f1)

            em_sum += em
            f1_sum += f1
            total += 1
            fout.write(json.dumps(ex, ensure_ascii=False) + "\n")

    if total - miss > 0:
        EM = em_sum / (total - miss)
        F1 = f1_sum / (total - miss)
    else:
        EM = 0.0
        F1 = 0.0

    print(f"[DONE] N={total} matched={total-miss} missing_gold={miss}")
    print(f"EM={EM:.6f}  F1={F1:.6f}")
    print(f"[SAVED] {out_path}")

if __name__ == "__main__":
    main()
