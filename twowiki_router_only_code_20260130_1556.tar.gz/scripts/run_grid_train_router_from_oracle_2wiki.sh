#!/usr/bin/env bash
set -u

GPU_ID="${1:-0}"     # e.g. 0/1/2...
SMOKE="${2:-0}"      # 1 -> only run E=1,N=1000
FORCE="${3:-0}"      # 1 -> retrain even if ckpt exists

ROOT="/mnt/raid/peiyu/twowiki_router_only"
PY="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python"

B=5200
BATCH=128
LR="2e-4"

# grid
EPOCHS=(1 3 5 7 9)
NS=(1000 5000 10000 15000 20000)

if [[ "${SMOKE}" == "1" ]]; then
  EPOCHS=(1)
  NS=(1000)
fi

cd "${ROOT}"
mkdir -p logs ckpts

export CUDA_VISIBLE_DEVICES="${GPU_ID}"
export PYTHONPATH="${ROOT}:${PYTHONPATH:-}"
export DATASET_NAME="2wiki"
export EMB_MODEL_PATH="/mnt/raid/peiyu/models/bge-large-en-v1.5"

for E in "${EPOCHS[@]}"; do
  for N in "${NS[@]}"; do
    ORACLE="data/oracle_policy_train_v2_B${B}_N${N}.jsonl"
    OUT="ckpts/router_policy_v2_B${B}_E${E}_N${N}.pt"
    LOG="logs/train_router_policy_v2_B${B}_E${E}_N${N}.log"

    if [[ ! -f "${ORACLE}" ]]; then
      echo "[SKIP] missing oracle: ${ORACLE}"
      continue
    fi

    if [[ -f "${OUT}" && "${FORCE}" != "1" ]]; then
      echo "[SKIP] exists: ${OUT}"
      continue
    fi

    echo "[RUN] GPU=${GPU_ID} E=${E} N=${N}"
    echo "      ORACLE=${ORACLE}"
    echo "      OUT=${OUT}"
    echo "      LOG=${LOG}"

    ${PY} -m mog_rag.train_router_from_oracle \
      --oracle "${ORACLE}" \
      --out "${OUT}" \
      --epochs "${E}" --batch_size "${BATCH}" --lr "${LR}" \
      > "${LOG}" 2>&1

    RC=$?
    if [[ "${RC}" != "0" ]]; then
      echo "[FAIL] rc=${RC} see ${LOG}"
    else
      echo "[OK]  saved ${OUT}"
    fi
  done
done

