#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build fixed-length non-overlapping chunk index from *_doc.jsonl.

- Input: CORPUS_DIR/{split}_doc.jsonl (from your existing chunking outputs)
- Output: INDEX_DIR/{split}/fixed/index.faiss + meta.jsonl

Smoke:
  python scripts/build_fixed_index_from_doc.py --split dev --max_docs 200 --chunk_tokens 200

Full:
  python scripts/build_fixed_index_from_doc.py --split dev --chunk_tokens 200 --batch_size 512
"""

from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _iter_jsonl(path: Path, max_docs: int = 0):
    n = 0
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            yield json.loads(line)
            n += 1
            if max_docs and n >= max_docs:
                break


def _chunk_tokens(tok: AutoTokenizer, text: str, chunk_tokens: int) -> List[str]:
    ids = tok.encode(text or "", add_special_tokens=False)
    out = []
    for i in range(0, len(ids), chunk_tokens):
        piece = ids[i:i + chunk_tokens]
        if not piece:
            continue
        out.append(tok.decode(piece, skip_special_tokens=True).strip())
    return [x for x in out if x]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, default="dev", choices=["dev", "test", "train"])
    ap.add_argument("--chunk_tokens", type=int, default=200)
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--max_docs", type=int, default=0, help="smoke only: limit input docs")
    ap.add_argument("--llm_path", type=str, default=os.getenv("LLM_PATH", "/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct"))
    args = ap.parse_args()

    # import config from current repo
    import mog_rag.config as c

    corpus_dir = Path(str(getattr(c, "CORPUS_DIR", c.DATASET_DIR)))
    index_dir = Path(str(c.INDEX_DIR))

    doc_jsonl = corpus_dir / f"{args.split}_doc.jsonl"
    if not doc_jsonl.exists():
        raise FileNotFoundError(f"doc jsonl not found: {doc_jsonl}")

    out_dir = index_dir / args.split / "fixed"
    _ensure_dir(out_dir)
    meta_out = out_dir / "meta.jsonl"
    index_out = out_dir / "index.faiss"

    print("[IN ]", doc_jsonl)
    print("[OUT]", index_out)
    print("[OUT]", meta_out)

    tok = AutoTokenizer.from_pretrained(args.llm_path, trust_remote_code=True, use_fast=True)
    emb = SentenceTransformer(str(c.EMB_MODEL_PATH), device=("cuda" if os.getenv("CUDA_VISIBLE_DEVICES", "") != "" else "cpu"))

    metas: List[Dict] = []
    texts: List[str] = []

    doc_id = 0
    for ex in _iter_jsonl(doc_jsonl, max_docs=args.max_docs):
        title = ex.get("title", "")
        ex_id = ex.get("ex_id", -1)
        text = ex.get("text", "") or ""
        chunks = _chunk_tokens(tok, text, args.chunk_tokens)
        for j, ch in enumerate(chunks):
            metas.append({
                "text": ch,
                "title": title,
                "ex_id": ex_id,
                "doc_id": doc_id,
                "fixed_id": j,
            })
            texts.append(ch)
        doc_id += 1

    if not texts:
        raise RuntimeError("No chunks produced. Check input doc jsonl content.")

    # encode + build faiss
    dim = emb.get_sentence_embedding_dimension()
    index = faiss.IndexFlatIP(dim)

    bs = int(args.batch_size)
    for i in range(0, len(texts), bs):
        batch = texts[i:i+bs]
        embs = emb.encode(batch, normalize_embeddings=True, convert_to_numpy=True)
        embs = np.asarray(embs, dtype="float32")
        index.add(embs)
        if (i // bs) % 20 == 0:
            print(f"[EMB] {min(i+bs, len(texts))}/{len(texts)}")

    faiss.write_index(index, str(index_out))
    with meta_out.open("w", encoding="utf-8") as f:
        for m in metas:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")

    print(f"[DONE] n_chunks={len(metas)} dim={dim}")


if __name__ == "__main__":
    main()
