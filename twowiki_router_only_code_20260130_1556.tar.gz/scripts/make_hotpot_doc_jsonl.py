# scripts/make_hotpot_doc_jsonl.py
from __future__ import annotations
import argparse, json
from pathlib import Path

def iter_hotpot_docs(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    seen = set()
    for ex in data:
        # HotpotQA distractor/fullwiki format: ex["context"] = [[title, [sent1, sent2, ...]], ...]
        ctx = ex.get("context", [])
        for item in ctx:
            if not item or len(item) < 2:
                continue
            title = str(item[0]).strip()
            sents = item[1] if isinstance(item[1], list) else []
            text = " ".join([str(s).strip() for s in sents if str(s).strip()])
            if not title or not text:
                continue
            key = (title, text[:2000])  # 防止极少数重复标题但内容不同导致过度合并
            if key in seen:
                continue
            seen.add(key)
            yield title, text

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    inp = Path(args.input)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)

    n = 0
    with out.open("w", encoding="utf-8") as f:
        for title, text in iter_hotpot_docs(inp):
            f.write(json.dumps({"ex_id": n, "title": title, "text": text}, ensure_ascii=False) + "\n")
            n += 1

    print(f"[OK] wrote {n} docs -> {out}")

if __name__ == "__main__":
    main()
