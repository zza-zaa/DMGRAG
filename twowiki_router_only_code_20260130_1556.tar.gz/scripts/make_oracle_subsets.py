#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, os, random
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", type=str, required=True,
                    help="source oracle jsonl, e.g. data/oracle_policy_train_v2_B5200_N20000.jsonl")
    ap.add_argument("--out_dir", type=str, default="data",
                    help="where to write subset files")
    ap.add_argument("--sizes", type=int, nargs="+", default=[1000, 5000, 10000, 15000, 20000])
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--mode", type=str, default="head", choices=["head", "shuffle"],
                    help="head: take first N; shuffle: shuffle then take N")
    args = ap.parse_args()

    src = Path(args.src)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    assert src.exists(), f"src not found: {src}"

    # read all lines once
    lines = src.read_text(encoding="utf-8").splitlines()
    total = len(lines)
    print(f"[LOAD] {src} lines={total}")

    rng = random.Random(args.seed)
    order = list(range(total))
    if args.mode == "shuffle":
        rng.shuffle(order)

    # derive prefix like oracle_policy_train_v2_B5200
    name = src.name
    # keep everything before _N20000.jsonl
    prefix = name.split("_N")[0]  # oracle_policy_train_v2_B5200
    for n in sorted(set(args.sizes)):
        if n > total:
            raise ValueError(f"requested n={n} > total={total}")
        idx = order[:n]
        subset = [lines[i] for i in idx]
        out_path = out_dir / f"{prefix}_N{n}.jsonl"
        out_path.write_text("\n".join(subset) + "\n", encoding="utf-8")
        print(f"[SAVE] {out_path} n={n} mode={args.mode}")

if __name__ == "__main__":
    main()
