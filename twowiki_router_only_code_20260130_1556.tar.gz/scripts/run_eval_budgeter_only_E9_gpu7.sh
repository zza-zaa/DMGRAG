#!/usr/bin/env bash
set -euo pipefail
ROOT="/mnt/raid/peiyu/twowiki_router_only"
PY="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python"
E=9
GPU=7
B=5200
SPLIT="${1:-dev}"
LIMIT="${2:-1500}"
NS=(1000 5000 10000 15000 20000)
OUTDIR="$ROOT/logs/budgeter_only_eval_B5200"
mkdir -p "$OUTDIR"
summary="$OUTDIR/summary_E${E}.csv"
echo "epoch,n_train,ckpt,split,limit,status,EM,F1,log" > "$summary"
resolve_ckpt(){ local e="$1"; local n="$2"; local cands=(
"$ROOT/ckpts/budget_regressor_v2_B${B}_E${e}_N${n}.pt"
"$ROOT/ckpts/budget_regressor_v2_B${B}_E${e}_N${n}.pth"
"$ROOT/ckpts/budget_regressor_B${B}_E${e}_N${n}.pt"
"$ROOT/ckpts/budgeter_B${B}_E${e}_N${n}.pt"
"$ROOT/budget_regressor_v2_B${B}_E${e}_N${n}.pt"
"$ROOT/budget_regressor_v2_B${B}_E${e}_N${n}.pth"
); for p in "${cands[@]}"; do [[ -f "$p" ]] && { echo "$p"; return 0; }; done; echo ""; return 1; }
parse_emf1(){ local logf="$1"; "$PY" - <<PY
import re,sys
p=sys.argv[1]
txt=open(p,'r',encoding='utf-8',errors='ignore').read().splitlines()
em=f1=None
pat=re.compile(r"(EM|Exact Match)\s*[:=]\s*([0-9.]+).*?(F1)\s*[:=]\s*([0-9.]+)",re.I)
for line in txt[::-1]:
    m=pat.search(line)
    if m: em=float(m.group(2)); f1=float(m.group(4)); break
if em is None or f1 is None:
    pat_em=re.compile(r"\bEM\b\s*[:=]\s*([0-9.]+)",re.I)
    pat_f1=re.compile(r"\bF1\b\s*[:=]\s*([0-9.]+)",re.I)
    for line in txt[::-1]:
        if em is None:
            m=pat_em.search(line); 
            if m: em=float(m.group(1))
        if f1 is None:
            m=pat_f1.search(line); 
            if m: f1=float(m.group(1))
        if em is not None and f1 is not None: break
print("" if em is None else em, "" if f1 is None else f1)
PY "$logf"; }
cd "$ROOT"
for N in "${NS[@]}"; do
  ckpt="$(resolve_ckpt "$E" "$N" || true)"
  if [[ -z "${ckpt}" ]]; then
    echo "[SKIP] missing ckpt for E=$E N=$N"
    echo "$E,$N,,${SPLIT},${LIMIT},MISSING_CKPT,,," >> "$summary"
    continue
  fi
  log="$OUTDIR/eval_budgeter_only_B${B}_E${E}_N${N}_${SPLIT}_L${LIMIT}.log"
  echo "[RUN] GPU=$GPU E=$E N=$N ckpt=$ckpt"
  (
    CUDA_VISIBLE_DEVICES="$GPU" \
    PYTHONPATH="$ROOT:$PYTHONPATH" \
    DATASET_NAME=2wiki DATA_ROOT=/mnt/raid/peiyu/data \
    USE_ROUTER=0 USE_BUDGETER=1 \
    BUDGETER_CKPT="$ckpt" \
    CTX_BUDGET="$B" STAGE1_TOTAL_TOPK=160 RERANK_TOP_M=160 TOTAL_TOPK=100 \
    "$PY" -m mog_rag.evaluate_hotpot --split "$SPLIT" --limit "$LIMIT"
  ) > "$log" 2>&1 || true
  if grep -qiE "Traceback|ModuleNotFoundError|ERROR" "$log"; then status="CRASH"; em=""; f1=""
  else status="OK"; read -r em f1 < <(parse_emf1 "$log"); fi
  echo "$E,$N,$ckpt,${SPLIT},${LIMIT},$status,$em,$f1,$log" >> "$summary"
done
echo "saved: $summary"
