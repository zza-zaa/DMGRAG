#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train Router on 2Wiki with grid of (epochs, n_train) using labels for budget B=5200.
This script ONLY trains routers (no eval). It is robust to different training entrypoints / arg names.

Usage (smoke):
  /path/to/python scripts/grid_train_router_only_2wiki.py --cuda 1 --smoke 1

Full grid:
  /path/to/python scripts/grid_train_router_only_2wiki.py --cuda 1
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
import subprocess
import importlib.util
from pathlib import Path
from typing import List, Optional, Tuple


CAND_TRAIN_MODULES = [
    "mog_rag.train_router_policy",
    "mog_rag.train_router",
    "mog_rag.train_router_2wiki",
    "mog_rag.router_train",
    "mog_rag.train_router_only",
]


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _ensure_dirs(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _find_first_existing_module(prefer: Optional[str] = None) -> Optional[str]:
    if prefer:
        if importlib.util.find_spec(prefer) is not None:
            return prefer
        return None
    for m in CAND_TRAIN_MODULES:
        if importlib.util.find_spec(m) is not None:
            return m
    return None


def _run(cmd: List[str], env: dict, log_path: Path) -> Tuple[int, float]:
    t0 = time.time()
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[CMD] " + " ".join(cmd) + "\n")
        # record key env
        for k in ["CUDA_VISIBLE_DEVICES", "DATASET_NAME", "DATA_ROOT", "CTX_BUDGET", "PYTHONPATH"]:
            if k in env:
                f.write(f"[ENV] {k}={env[k]}\n")
        f.write("\n")

    with log_path.open("a", encoding="utf-8") as f:
        p = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, env=env)
        rc = p.wait()

    return rc, float(time.time() - t0)


def _ckpt_name(B: int, E: int, N: int) -> str:
    # keep consistent with your v2 naming
    return f"router_policy_v2_B{B}_E{E}_N{N}.pt"


def _candidate_argsets(B: int, E: int, N: int, ckpt_path: str) -> List[List[str]]:
    """
    Try multiple common CLI argument conventions.
    rc=2 usually means argparse reject -> we try next argset.
    """
    return [
        # very common
        ["--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--save", ckpt_path],
        ["--epochs", str(E), "--n_train", str(N), "--ctx_budget", str(B), "--save", ckpt_path],
        ["--epochs", str(E), "--train_size", str(N), "--budget", str(B), "--save", ckpt_path],
        ["--epoch", str(E), "--n_train", str(N), "--budget", str(B), "--save", ckpt_path],

        # output arg variants
        ["--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--out", ckpt_path],
        ["--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--ckpt_out", ckpt_path],
        ["--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--output", ckpt_path],

        # sometimes split needed
        ["--split", "train", "--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--save", ckpt_path],
        ["--train_split", "train", "--epochs", str(E), "--n_train", str(N), "--budget", str(B), "--save", ckpt_path],

        # sometimes label budget flag exists
        ["--epochs", str(E), "--n_train", str(N), "--label_budget", str(B), "--save", ckpt_path],
        ["--split", "train", "--epochs", str(E), "--n_train", str(N), "--label_budget", str(B), "--save", ckpt_path],
    ]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cuda", type=int, default=0, help="CUDA_VISIBLE_DEVICES id")
    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--epochs", type=str, default="1,3,5,7,9")
    ap.add_argument("--n_train", type=str, default="1000,5000,10000,15000,20000")
    ap.add_argument("--train_module", type=str, default="", help="override training module, e.g., mog_rag.train_router_policy")
    ap.add_argument("--smoke", type=int, default=0, help="1 -> only run (E=1,N=1000)")
    ap.add_argument("--force", type=int, default=0, help="1 -> retrain even if ckpt exists")
    args = ap.parse_args()

    root = _repo_root()
    os.chdir(root)

    B = int(args.B)
    epochs = [int(x) for x in args.epochs.split(",") if x.strip()]
    ns = [int(x) for x in args.n_train.split(",") if x.strip()]
    if args.smoke == 1:
        epochs = [1]
        ns = [1000]

    # IMPORTANT env: ensure mog_rag is importable in subprocess
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
    env.setdefault("DATASET_NAME", "2wiki")
    env.setdefault("DATA_ROOT", "/mnt/raid/peiyu/data")
    env["CTX_BUDGET"] = str(B)
    env["PYTHONPATH"] = str(root) + os.pathsep + env.get("PYTHONPATH", "")

    # locate training module
    prefer = args.train_module.strip() or None
    train_mod = _find_first_existing_module(prefer=prefer)
    if train_mod is None:
        print("[FATAL] cannot find router training module. Tried:")
        for m in ([prefer] if prefer else []) + CAND_TRAIN_MODULES:
            if m:
                print("  -", m)
        print("\nHint: run:")
        print(f"  PYTHONPATH={root}:$PYTHONPATH {sys.executable} -c \"import pkgutil, mog_rag; print([m.name for m in pkgutil.iter_modules(mog_rag.__path__)])\"")
        sys.exit(2)

    ckpt_dir = root / "ckpts"
    log_dir = root / "logs" / f"grid_train_router_only_2wiki_B{B}"
    _ensure_dirs(ckpt_dir)
    _ensure_dirs(log_dir)

    summary_path = log_dir / "summary.csv"
    rows = []

    for E in epochs:
        for N in ns:
            ckpt = ckpt_dir / _ckpt_name(B, E, N)
            log_path = log_dir / f"train_router_B{B}_E{E}_N{N}.log"

            if ckpt.exists() and args.force == 0:
                rows.append({
                    "mode": "router_train",
                    "B": B, "epoch": E, "n_train": N,
                    "ckpt": str(ckpt),
                    "status": "SKIP_EXISTS",
                    "rc": 0,
                    "secs": 0.0,
                    "train_log": str(log_path),
                    "train_module": train_mod,
                })
                print(f"[SKIP] exists: {ckpt}")
                continue

            ok = False
            last_rc = None
            last_secs = 0.0

            argsets = _candidate_argsets(B, E, N, str(ckpt))

            for aidx, a in enumerate(argsets):
                cmd = [sys.executable, "-m", train_mod] + a
                print(f"[RUN] E={E} N={N} try#{aidx+1}/{len(argsets)} module={train_mod}")
                rc, secs = _run(cmd, env=env, log_path=log_path)
                last_rc, last_secs = rc, secs

                # success criteria: rc==0 and ckpt file created
                if rc == 0 and ckpt.exists():
                    ok = True
                    break

                # if argparse error, try next argset quickly
                if rc == 2:
                    continue

                # otherwise also continue to next (some scripts might still be picky)
                continue

            status = "OK" if ok else f"TRAIN_CRASH(rc={last_rc})"
            rows.append({
                "mode": "router_train",
                "B": B, "epoch": E, "n_train": N,
                "ckpt": str(ckpt),
                "status": status,
                "rc": int(last_rc) if last_rc is not None else -1,
                "secs": float(last_secs),
                "train_log": str(log_path),
                "train_module": train_mod,
            })

            if ok:
                print(f"[OK] saved ckpt: {ckpt}")
            else:
                print(f"[FAIL] E={E} N={N} see log: {log_path}")

    # write summary
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "mode","B","epoch","n_train","ckpt","status","rc","secs","train_log","train_module"
        ])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    print("saved:", summary_path)


if __name__ == "__main__":
    main()
