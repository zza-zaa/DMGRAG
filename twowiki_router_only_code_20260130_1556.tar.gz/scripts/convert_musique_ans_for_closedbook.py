# scripts/convert_musique_ans_for_closedbook.py
from __future__ import annotations
import argparse
import json
from pathlib import Path

def norm_list(x):
    if x is None:
        return []
    if isinstance(x, list):
        return [str(i) for i in x if i is not None]
    return [str(x)]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_file", required=True)
    ap.add_argument("--out_file", required=True)
    args = ap.parse_args()

    in_path = Path(args.in_file)
    out_path = Path(args.out_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    n = 0
    n_has_gold = 0
    with in_path.open("r", encoding="utf-8") as fin, out_path.open("w", encoding="utf-8") as fout:
        for line in fin:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)

            qid = ex.get("id") or ex.get("qid") or ex.get("question_id") or ex.get("idx") or str(n)
            question = ex.get("question", "")
            answerable = ex.get("answerable", True)

            ans = ex.get("answer", None) if answerable else None
            aliases = norm_list(ex.get("answer_aliases", []))
            gold_list = []
            if ans is not None:
                gold_list.append(str(ans))
            gold_list.extend([a for a in aliases if a and a != ans])

            # 兼容尽可能多的 evaluator：同时写入 gold/gold_list + answer/answer_aliases
            out_ex = {
                "qid": str(qid),
                "question": question,

                "gold": (str(ans) if ans is not None else None),
                "gold_list": gold_list,

                "answer": (str(ans) if ans is not None else None),
                "answer_aliases": aliases,

                "answerable": bool(answerable),
            }

            if out_ex["gold"] is not None and (len(out_ex["gold_list"]) > 0):
                n_has_gold += 1

            fout.write(json.dumps(out_ex, ensure_ascii=False) + "\n")
            n += 1

    print(f"[OK] wrote {n} examples -> {out_path}")
    print(f"[OK] examples with gold: {n_has_gold}/{n}")

if __name__ == "__main__":
    main()

