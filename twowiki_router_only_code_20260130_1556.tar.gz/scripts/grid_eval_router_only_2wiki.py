#!/usr/bin/env python3
import argparse, os, re, subprocess
from pathlib import Path

RE_RESULT = re.compile(r"\[RESULT\]\s+N=(\d+)\s+EM=([0-9.]+)\s+F1=([0-9.]+)")

def parse_result(log_path: Path):
    if not log_path.exists():
        return None
    text = log_path.read_text(errors="ignore")
    m = RE_RESULT.search(text)
    if not m:
        return None
    return {"N": int(m.group(1)), "EM": float(m.group(2)), "F1": float(m.group(3))}

def run_cmd(cmd, env, log_path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w") as f:
        p = subprocess.Popen(cmd, env=env, stdout=f, stderr=subprocess.STDOUT)
        return p.wait()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--py", default="/mnt/raid/peiyu/envs/brmog_gpu_llm/brmog_gpu/bin/python")
    ap.add_argument("--project_dir", default=os.getcwd())
    ap.add_argument("--dataset", default="2wiki")
    ap.add_argument("--data_root", default="/mnt/raid/peiyu/data")
    ap.add_argument("--llm_path", default="/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct")
    ap.add_argument("--split", default="dev")
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--cuda", default="0")
    ap.add_argument("--B", type=int, default=5200)
    ap.add_argument("--stage1_total_topk", type=int, default=160)
    ap.add_argument("--rerank_top_m", type=int, default=160)
    ap.add_argument("--total_topk", type=int, default=100)
    ap.add_argument("--use_reranker", type=int, default=1)

    ap.add_argument("--epochs", default="1,3,5,7,9")
    ap.add_argument("--ns", default="1000,5000,10000,15000,20000")

    ap.add_argument("--router_ckpt_dir", default="ckpts")
    ap.add_argument("--router_pattern", default="router_policy_v2_B{B}_E{E}_N{N}.pt")

    ap.add_argument("--out_dir", default="logs/grid_router_only_2wiki_B5200")
    ap.add_argument("--smoke", type=int, default=0)
    args = ap.parse_args()

    proj = Path(args.project_dir).resolve()
    os.chdir(proj)

    epochs = [int(x) for x in args.epochs.split(",") if x.strip()]
    ns = [int(x) for x in args.ns.split(",") if x.strip()]
    if args.smoke:
        epochs = [3]
        ns = [20000]
        args.limit = 20

    out_dir = proj / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_csv = out_dir / "summary.csv"
    summary_csv.write_text("mode,B,epoch,n_train,split,limit,ckpt,EM,F1\n")

    ckpt_dir = (proj / args.router_ckpt_dir).resolve()

    for E in epochs:
        for N in ns:
            ckpt = ckpt_dir / args.router_pattern.format(B=args.B, E=E, N=N)
            log_path = out_dir / f"router_only_B{args.B}_E{E}_N{N}_{args.split}_L{args.limit}.log"

            if not ckpt.exists():
                print(f"[SKIP] missing router ckpt: {ckpt}")
                continue

            env = os.environ.copy()
            env["CUDA_VISIBLE_DEVICES"] = str(args.cuda)
            env["PYTHONPATH"] = f"{proj}:{env.get('PYTHONPATH','')}"
            env["DATASET_NAME"] = args.dataset
            env["DATA_ROOT"] = args.data_root
            env["LLM_PATH"] = args.llm_path
            env["USE_ROUTER"] = "1"
            env["USE_BUDGETER"] = "0"
            env["ROUTER_CKPT"] = str(ckpt)
            env["CTX_BUDGET"] = str(args.B)
            env["STAGE1_TOTAL_TOPK"] = str(args.stage1_total_topk)
            env["RERANK_TOP_M"] = str(args.rerank_top_m)
            env["TOTAL_TOPK"] = str(args.total_topk)
            env["USE_RERANKER"] = str(args.use_reranker)

            cmd = [args.py, "-m", "mog_rag.evaluate_hotpot", "--split", args.split, "--limit", str(args.limit)]
            print("[RUN]", " ".join(cmd), ">", log_path.name)
            rc = run_cmd(cmd, env, log_path)
            if rc != 0:
                print(f"[WARN] non-zero exit rc={rc} for E={E}, N={N}. see {log_path}")
                continue

            res = parse_result(log_path)
            if not res:
                print(f"[WARN] cannot parse result from {log_path}")
                continue

            summary_csv.write_text(summary_csv.read_text() + f"router,{args.B},{E},{N},{args.split},{args.limit},{ckpt},{res['EM']},{res['F1']}\n")
            print(f"[OK] E={E} N={N} EM={res['EM']:.3f} F1={res['F1']:.3f}")

    print("saved:", summary_csv)

if __name__ == "__main__":
    main()
