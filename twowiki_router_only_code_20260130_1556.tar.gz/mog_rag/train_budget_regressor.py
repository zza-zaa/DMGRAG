from __future__ import annotations
from typing import Dict, List, Tuple
from pathlib import Path
import argparse
import json

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
import faiss
from sentence_transformers import SentenceTransformer

from .config import (
    HOTPOT_TRAIN,
    INDEX_DIR,
    EMB_MODEL_PATH,
    GRANULARITIES,
    MAX_CONTEXT_TOKENS,
)
from .utils import load_hotpot, get_supporting_facts, chunk_support_overlap
from .budget_regressor import BudgetRegressor, ChunkFeature

# 检查 faiss 是否支持 GPU
FAISS_HAS_GPU = hasattr(faiss, "StandardGpuResources")


class BudgetRegressorTrainer:
    def __init__(
        self,
        device: str = "cuda",
        split: str = "train",
        topk_per_granularity: int = 32,
        max_train_examples: int = -1,
        pos_weight: float = 4.0,
        rank_loss_weight: float = 0.5,
        margin: float = 0.5,
    ):
        """
        device: 训练 BudgetRegressor MLP 的设备
        split:  使用哪一份索引（这里用 train）
        topk_per_granularity: 每个粒度检索多少候选 chunk
        max_train_examples: 最大训练样本数；<0 表示用完整 train
        pos_weight: 正样本权重（缓和全局正负不平衡）
        rank_loss_weight: 排序损失的权重 λ
        margin: pairwise ranking hinge loss 的 margin
        """
        if "cuda" in device and torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        self.split = split
        self.topk = topk_per_granularity
        self.max_train_examples = max_train_examples

        self.rank_loss_weight = rank_loss_weight
        self.margin = margin

        # 用于 FAISS 检索的 encoder（和路由器那边一样）
        encoder_device = "cuda" if torch.cuda.is_available() else "cpu"
        self.q_encoder = SentenceTransformer(str(EMB_MODEL_PATH), device=encoder_device)

        # FAISS GPU 资源
        if torch.cuda.is_available() and FAISS_HAS_GPU:
            self.gpu_id = 0
            self.gpu_res = faiss.StandardGpuResources()
            print("[FAISS] GPU 支持已启用，用 GPU 做索引检索。")
        else:
            self.gpu_id = -1
            self.gpu_res = None
            print("[FAISS] 当前环境没有 GPU 版 faiss，索引检索将使用 CPU。")

        # 加载各粒度 train 索引
        self.indices: Dict[str, faiss.Index] = {}
        self.metas: Dict[str, List[Dict]] = {}
        self._load_indices(split=self.split)

        # 粒度 -> id 映射（和运行时保持一致）
        self.gran2id = {g: i for i, g in enumerate(GRANULARITIES)}

        # 预算器模型
        self.model = BudgetRegressor().to(self.device)
        # 只训练 mlp，embedding 也是 mlp 里的一部分
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-3)

        self.pos_weight = torch.tensor(pos_weight, dtype=torch.float32, device=self.device)
        self.bce = nn.BCEWithLogitsLoss(pos_weight=self.pos_weight)

    # ----------------- 索引与编码 -----------------

    def _load_indices(self, split: str = "train"):
        """
        读取指定 split 的索引：
        - 先从磁盘读 CPU 版 index.faiss
        - 若 GPU 可用且 faiss 支持 GPU，则搬到 GPU
        """
        for gran in GRANULARITIES:
            out_dir = INDEX_DIR / split / gran
            index_path = out_dir / "index.faiss"
            meta_path = out_dir / "meta.jsonl"
            if not index_path.exists():
                print(f"[WARN] index not found for {split}-{gran}, skip.")
                continue

            index_cpu = faiss.read_index(str(index_path))
            if self.gpu_res is not None and self.gpu_id >= 0:
                index = faiss.index_cpu_to_gpu(self.gpu_res, self.gpu_id, index_cpu)
                print(f"[LOAD][GPU] {split}-{gran} index -> GPU{self.gpu_id}")
            else:
                index = index_cpu
                print(f"[LOAD][CPU] {split}-{gran} index")

            metas: List[Dict] = []
            with meta_path.open("r", encoding="utf-8") as f:
                for line in f:
                    metas.append(json.loads(line))

            self.indices[gran] = index
            self.metas[gran] = metas
            print(f"[LOAD] {split}-{gran}: {len(metas)} chunks.")

    def _encode_query(self, q: str) -> np.ndarray:
        emb = self.q_encoder.encode([q], normalize_embeddings=True)
        return np.asarray(emb, dtype="float32")

    # ----------------- 构造单个样本的 chunk 特征 + 标签 -----------------

    def _build_chunk_features_for_example(
        self,
        ex_id: int,
        ex: Dict,
    ) -> Tuple[List[ChunkFeature], List[int]]:
        """
        对单个 Hotpot 样本：
        - 在每个粒度检索 top-k chunk
        - 根据是否覆盖 supporting facts 打 label（1/0）
        返回：
          - chunk_feats: List[ChunkFeature]
          - labels:      List[int] (同长度)
        """
        question = ex.get("question", "")
        supporting_facts = get_supporting_facts(ex)
        if not supporting_facts:
            return [], []

        q_emb = self._encode_query(question)

        chunk_feats: List[ChunkFeature] = []
        labels: List[int] = []

        for gran in GRANULARITIES:
            if gran not in self.indices:
                continue

            index = self.indices[gran]
            metas = self.metas[gran]

            scores, idxs = index.search(q_emb, self.topk)
            scores = scores[0]
            idxs = idxs[0]

            for score, idx in zip(scores, idxs):
                if idx < 0:
                    continue

                meta = metas[int(idx)]
                # 只保留当前 ex_id 对应的 chunk（同一个 Hotpot 样本）
                if int(meta.get("ex_id", -1)) != ex_id:
                    continue

                cov, total = chunk_support_overlap(meta, supporting_facts)
                label = 1 if cov > 0 else 0

                text = meta.get("text", "")
                length_tokens = len(text.split())

                feat = ChunkFeature(
                    text=text,
                    granularity_id=self.gran2id.get(gran, 0),
                    length_tokens=length_tokens,
                    bm25_score=0.0,
                    dense_score=float(score),
                    diversity_score=0.0,
                )
                chunk_feats.append(feat)
                labels.append(label)

        return chunk_feats, labels

    # ----------------- pairwise ranking loss（按单个问题） -----------------

    def _pairwise_rank_loss(
        self,
        scores: torch.Tensor,
        labels: np.ndarray,
    ) -> torch.Tensor:
        """
        scores: [N] logits
        labels: [N] numpy array of 0/1

        在同一个问题内部构造 (pos, neg) 对，优化：
            s_pos - s_neg >= margin
        """
        pos_idx = np.where(labels == 1)[0]
        neg_idx = np.where(labels == 0)[0]
        if len(pos_idx) == 0 or len(neg_idx) == 0:
            return torch.tensor(0.0, device=scores.device)

        # 为了效率，不用所有 pair，随机采样若干对
        num_pairs = min(len(pos_idx) * len(neg_idx), 32)
        pos_sample = np.random.choice(pos_idx, size=num_pairs, replace=True)
        neg_sample = np.random.choice(neg_idx, size=num_pairs, replace=True)

        s_pos = scores[pos_sample]
        s_neg = scores[neg_sample]

        margin = self.margin
        loss = torch.relu(margin - (s_pos - s_neg)).mean()
        return loss

    # ----------------- 训练主循环 -----------------

    def train(
        self,
        num_epochs: int = 1,
        budget_tokens: int = MAX_CONTEXT_TOKENS,
    ):
        """
        使用 Hotpot *train* 做全量训练（或前 max_train_examples 条）：
        - 每条样本按支持事实标记 chunk 1/0
        - BCE 约束全局“好/坏”；
        - pairwise ranking loss 约束“同一问题内部正块 > 负块”。
        """
        data = load_hotpot(HOTPOT_TRAIN)
        if self.max_train_examples > 0:
            data = data[: self.max_train_examples]

        print(f"[DATA] Hotpot train examples used: {len(data)}")

        self.model.train()

        for epoch in range(num_epochs):
            total_loss = 0.0
            steps = 0
            total_pos = 0
            total_neg = 0

            pbar = tqdm(
                enumerate(data),
                total=len(data),
                desc=f"Train budget epoch {epoch+1}",
            )

            for ex_id, ex in pbar:
                chunk_feats, labels = self._build_chunk_features_for_example(ex_id, ex)
                if not chunk_feats:
                    continue

                labels_arr = np.array(labels, dtype="float32")
                pos_cnt = int(labels_arr.sum())
                neg_cnt = int(len(labels_arr) - pos_cnt)
                total_pos += pos_cnt
                total_neg += neg_cnt

                scores = self.model(
                    query=ex["question"],
                    chunks=chunk_feats,
                    budget_tokens=budget_tokens,
                )  # [N]

                y = torch.tensor(
                    labels_arr,
                    dtype=torch.float32,
                    device=scores.device,
                )

                # BCE 部分：全局好/坏分类
                bce_loss = self.bce(scores, y)

                # 排序部分：同一个问题内部正块 > 负块
                rank_loss = self._pairwise_rank_loss(scores, labels_arr)

                loss = bce_loss + self.rank_loss_weight * rank_loss

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                total_loss += float(loss.item())
                steps += 1

                if steps % 50 == 0:
                    avg_loss = total_loss / max(1, steps)
                    pbar.set_postfix(
                        loss=f"{avg_loss:.4f}",
                        pos=total_pos,
                        neg=total_neg,
                    )

            avg_loss = total_loss / max(1, steps)
            print(
                f"[BUDGET] epoch={epoch+1}  avg_loss={avg_loss:.4f}  "
                f"pos={total_pos}  neg={total_neg}"
            )

        # 保存全模型的 mlp 权重（里面含 gran_emb）
        out_path = Path("budget_regressor_mlp.pt")
        torch.save(self.model.mlp.state_dict(), out_path)
        print(f"[SAVE] budget regressor MLP -> {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        help="cuda 或 cpu",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=1,
        help="训练轮数",
    )
    parser.add_argument(
        "--max_train_examples",
        type=int,
        default=-1,
        help="使用多少条 Hotpot train 样本（<0 表示全量）",
    )
    parser.add_argument(
        "--topk",
        type=int,
        default=32,
        help="每个粒度检索多少候选 chunk",
    )
    parser.add_argument(
        "--budget_tokens",
        type=int,
        default=MAX_CONTEXT_TOKENS,
        help="训练时假定的上下文预算（token 数）",
    )
    parser.add_argument(
        "--rank_loss_weight",
        type=float,
        default=0.5,
        help="pairwise ranking loss 的权重 λ",
    )
    parser.add_argument(
        "--margin",
        type=float,
        default=0.5,
        help="ranking hinge loss 的 margin",
    )
    args = parser.parse_args()

    trainer = BudgetRegressorTrainer(
        device=args.device,
        split="train",
        topk_per_granularity=args.topk,
        max_train_examples=args.max_train_examples,
        pos_weight=4.0,
        rank_loss_weight=args.rank_loss_weight,
        margin=args.margin,
    )
    trainer.train(
        num_epochs=args.epochs,
        budget_tokens=args.budget_tokens,
    )


if __name__ == "__main__":
    main()
