# mog_rag/config.py
from __future__ import annotations
from pathlib import Path
import os

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# ---------------------------
# Dataset
# ---------------------------
DATASET_NAME = os.getenv("DATASET_NAME", "2wiki").lower()  # "hotpot" / "2wiki" / "musique"
DATA_ROOT = Path(os.getenv("DATA_ROOT", "/mnt/raid/peiyu/data"))

if DATASET_NAME.startswith("2wiki"):
    DATASET_DIR = DATA_ROOT / "2Wiki"
    TRAIN_JSON = DATASET_DIR / "train.json"
    DEV_JSON   = DATASET_DIR / "dev.json"
    TEST_JSON  = DATASET_DIR / "test.json"

elif DATASET_NAME.startswith("musique"):
    # 你给的目录：/mnt/raid/peiyu/data/MuSiQue
    DATASET_DIR = DATA_ROOT / "MuSiQue"
    TRAIN_JSON = DATASET_DIR / "musique_ans_v1.0_train.jsonl"
    DEV_JSON   = DATASET_DIR / "musique_ans_v1.0_dev.jsonl"
    TEST_JSON  = DATASET_DIR / "musique_ans_v1.0_test.jsonl"

else:
    DATASET_DIR = DATA_ROOT / "hotpot"
    TRAIN_JSON = DATASET_DIR / "hotpot_train_v1.1.json"
    DEV_JSON   = DATASET_DIR / "hotpot_dev_distractor_v1.json"
    TEST_JSON  = DATASET_DIR / "hotpot_test_distractor_v1.json"

# 兼容旧名字
HOTPOT_TRAIN = TRAIN_JSON
HOTPOT_DEV   = DEV_JSON
HOTPOT_TEST  = TEST_JSON

# 统一 chunk jsonl 命名：{split}_{gran}.jsonl
TRAIN_SENT_JSONL = DATASET_DIR / "train_sent.jsonl"
TRAIN_PARA_JSONL = DATASET_DIR / "train_para.jsonl"
TRAIN_DOC_JSONL  = DATASET_DIR / "train_doc.jsonl"
DEV_SENT_JSONL   = DATASET_DIR / "dev_sent.jsonl"
DEV_PARA_JSONL   = DATASET_DIR / "dev_para.jsonl"
DEV_DOC_JSONL    = DATASET_DIR / "dev_doc.jsonl"
TEST_SENT_JSONL  = DATASET_DIR / "test_sent.jsonl"
TEST_PARA_JSONL  = DATASET_DIR / "test_para.jsonl"
TEST_DOC_JSONL   = DATASET_DIR / "test_doc.jsonl"

CORPUS_DIR = DATASET_DIR

# ---------------------------
# Index
# ---------------------------
INDEX_DIR = Path(os.getenv("INDEX_DIR", str(PROJECT_ROOT / "indices" / DATASET_NAME)))

# ---------------------------
# Models
# ---------------------------
MODEL_ROOT = Path(os.getenv("MODEL_ROOT", "/mnt/raid/peiyu/models"))
LLM_MODEL_PATH = Path(os.getenv("LLM_MODEL_PATH", str(MODEL_ROOT / "Qwen2.5-14B-Instruct")))
EMB_MODEL_PATH = Path(os.getenv("EMB_MODEL_PATH", str(MODEL_ROOT / "bge-large-en-v1.5")))
RERANKER_MODEL_PATH = Path(os.getenv("RERANKER_MODEL_PATH", str(MODEL_ROOT / "bge-reranker-large")))

# ---------------------------
# RAG settings
# ---------------------------
GRANULARITIES = ("sent", "para", "doc")
MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "2048"))
TOTAL_TOPK = int(os.getenv("TOTAL_TOPK", "60"))
EMB_BATCH_SIZE = int(os.getenv("EMB_BATCH_SIZE", "256"))
