# mog_rag/train_router_from_jsonl.py
from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, List, Tuple

import torch
import torch.nn.functional as F

from .router import GranularityRouter
from .config import GRANULARITIES


# ---------- 文本归一化 & F1（和 evaluate_hotpot 里保持一致） ----------

import re
import string


def _normalize_answer(s: str) -> str:
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_score(prediction: str, ground_truth: str) -> float:
    pred_tokens = _normalize_answer(prediction).split()
    gold_tokens = _normalize_answer(ground_truth).split()

    if not pred_tokens and not gold_tokens:
        return 1.0
    if not pred_tokens or not gold_tokens:
        return 0.0

    common: Dict[str, int] = {}
    for t in pred_tokens:
        common[t] = common.get(t, 0) + 1

    num_same = 0
    for t in gold_tokens:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0

    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


# ---------- 读单个 run 的 jsonl ----------


def load_run_jsonl(path: Path, gran: str) -> Dict[str, Dict]:
    """
    返回:
      q2info[question] = {"f1": float, "gold": str, "pred": str}
    """
    q2info: Dict[str, Dict] = {}
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)

            # 兼容不同字段名
            q = rec.get("question") or rec.get("q")
            if not q:
                continue
            q = q.strip()

            # 优先用已有 f1，没有就现场算
            if "f1" in rec:
                f1 = float(rec["f1"])
            else:
                gold = rec.get("gold_answer") or rec.get("gold") or rec.get("answer")
                pred = rec.get("pred_answer") or rec.get("pred") or rec.get("prediction")
                if gold is None or pred is None:
                    continue
                f1 = _f1_score(str(pred), str(gold))

            q2info[q] = {
                "f1": f1,
                # 下面两个也存一下，后面想分析可以用
                "gold": rec.get("gold_answer") or rec.get("gold") or rec.get("answer", ""),
                "pred": rec.get("pred_answer") or rec.get("pred") or rec.get("prediction", ""),
                "gran": gran,
            }
    print(f"[LOAD] {gran}: {len(q2info)} examples from {path}")
    return q2info


# ---------- 构建 (question, label) 训练样本 ----------


def build_router_dataset(
    sent_jsonl: Path,
    para_jsonl: Path,
    doc_jsonl: Path,
    min_delta: float = 0.0,
) -> List[Tuple[str, int]]:
    """
    为路由器构造数据集:
      - label = 在 {sent, para, doc} 中 F1 最大的那个粒度
      - 如果 best - second_best < min_delta，可以丢掉这条（不太“确定”的样本）
    返回:
      samples = [(question, label_id), ...]
    """
    sent_run = load_run_jsonl(sent_jsonl, "sent")
    para_run = load_run_jsonl(para_jsonl, "para")
    doc_run = load_run_jsonl(doc_jsonl, "doc")

    # 只保留三种粒度都有结果的问题
    common_qs = set(sent_run.keys()) & set(para_run.keys()) & set(doc_run.keys())
    print(f"[DATA] questions in all three runs: {len(common_qs)}")

    gran2id = {g: i for i, g in enumerate(GRANULARITIES)}

    samples: List[Tuple[str, int]] = []
    for q in common_qs:
        scores = [
            ("sent", sent_run[q]["f1"]),
            ("para", para_run[q]["f1"]),
            ("doc", doc_run[q]["f1"]),
        ]
        scores.sort(key=lambda x: x[1], reverse=True)
        best_gran, best_f1 = scores[0]
        second_f1 = scores[1][1]

        # 可选：跳过“几乎打平”的样本
        if best_f1 - second_f1 < min_delta:
            continue

        label_id = gran2id[best_gran]
        samples.append((q, label_id))

    print(f"[DATA] final samples for training router: {len(samples)}")
    # 简单看一下分布
    cnt = {g: 0 for g in GRANULARITIES}
    for _, lid in samples:
        g = GRANULARITIES[lid]
        cnt[g] += 1
    print("[DATA] label distribution:", cnt)

    return samples


# ---------- 训练路由器 MLP ----------


def train_router_mlp(
    samples: List[Tuple[str, int]],
    budget_tokens: int = 1024,
    num_epochs: int = 3,
    batch_size: int = 32,
    lr: float = 1e-3,
    out_path: Path = Path("router_mlp.pt"),
):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    router = GranularityRouter().to(device)

    # 只训练 MLP，SentenceTransformer 固定
    optimizer = torch.optim.Adam(router.mlp.parameters(), lr=lr)

    n = len(samples)
    indices = list(range(n))

    for epoch in range(1, num_epochs + 1):
        import random

        random.shuffle(indices)
        total_loss = 0.0

        for start in range(0, n, batch_size):
            batch_idx = indices[start : start + batch_size]
            if not batch_idx:
                continue

            qs = [samples[i][0] for i in batch_idx]
            labels = torch.tensor(
                [samples[i][1] for i in batch_idx],
                dtype=torch.long,
                device=device,
            )

            # forward 一个个跑（query_encoder 在 forward 里自己 encode）
            probs_list = []
            for q in qs:
                out = router(q, budget_tokens=budget_tokens)
                probs_list.append(out.probs.unsqueeze(0))  # [1, G]

            probs = torch.cat(probs_list, dim=0)  # [B, G]
            loss = F.cross_entropy(probs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(batch_idx)

        avg_loss = total_loss / n
        print(f"[TRAIN] epoch={epoch}  avg_loss={avg_loss:.4f}")

    # 只保存 MLP 的参数（和你现在加载的方式保持一致）
    torch.save(router.mlp.state_dict(), out_path)
    print(f"[SAVE] router MLP weights -> {out_path}")


if __name__ == "__main__":
    # 默认文件名，你可以改成自己保存 jsonl 的名字
    base = Path("./results")
    sent_jsonl = base / "hotpot_dev_sent_only.jsonl"
    para_jsonl = base / "hotpot_dev_para_only.jsonl"
    doc_jsonl = base / "hotpot_dev_doc_only.jsonl"

    samples = build_router_dataset(
        sent_jsonl=sent_jsonl,
        para_jsonl=para_jsonl,
        doc_jsonl=doc_jsonl,
        min_delta=0.0,  # 先不要过滤，后面想更“干净”再调
    )

    train_router_mlp(
        samples=samples,
        budget_tokens=1024,
        num_epochs=3,
        batch_size=32,
        lr=1e-3,
        out_path=Path("router_mlp.pt"),
    )
