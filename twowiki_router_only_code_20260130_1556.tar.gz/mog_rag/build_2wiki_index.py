from __future__ import annotations
from pathlib import Path
from typing import List, Dict
import json
import argparse

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

from .config import (
    INDEX_DIR,
    EMB_MODEL_PATH,
)
# 我们直接用 2Wiki 切好的 jsonl：
#   /mnt/raid/peiyu/data/2Wiki/{split}_{gran}.jsonl
DATA_ROOT = Path("/mnt/raid/peiyu/data/2Wiki")


def load_chunks(jsonl_path: Path) -> List[Dict]:
    chunks: List[Dict] = []
    with jsonl_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            chunks.append(json.loads(line))
    return chunks


def build_index_for_split(split: str, batch_size: int = 1024):
    """
    为 2Wiki 的某个 split（train / dev）构建 sent/para/doc 三个粒度的索引。
    输出目录结构：
        INDEX_DIR / split / {gran} / index.faiss
                              / meta.jsonl
    """
    assert split in ("train", "dev")
    print(f"=== Build indices for 2Wiki split={split} ===")

    # 加载 embedding 模型（BGE）
    print(f"[EMB] load SentenceTransformer from {EMB_MODEL_PATH}")
    model = SentenceTransformer(str(EMB_MODEL_PATH), device="cuda")

    for gran in ["sent", "para", "doc"]:
        jsonl_path = DATA_ROOT / f"{split}_{gran}.jsonl"
        if not jsonl_path.exists():
            print(f"[WARN] {jsonl_path} not found, skip gran={gran}")
            continue

        print(f"[LOAD] {jsonl_path}")
        chunks = load_chunks(jsonl_path)
        if not chunks:
            print(f"[WARN] no chunks in {jsonl_path}, skip.")
            continue

        # 先编码一小批，确定向量维度
        first_texts = [c.get("text", "") for c in chunks[:8]]
        first_embs = model.encode(first_texts, normalize_embeddings=True)
        dim = first_embs.shape[1]
        print(f"[EMB] dim={dim}, num_chunks={len(chunks)}")

        # 建立 inner-product 索引（因为 encode 时做了 normalize_embeddings）
        index = faiss.IndexFlatIP(dim)

        # 逐批编码并写入 index & meta.jsonl
        out_dir = INDEX_DIR / split / gran
        out_dir.mkdir(parents=True, exist_ok=True)
        index_path = out_dir / "index.faiss"
        meta_path = out_dir / "meta.jsonl"

        # 重新写 meta.jsonl，确保与索引顺序对齐
        with meta_path.open("w", encoding="utf-8") as f_meta:
            batch_texts: List[str] = []
            batch_metas: List[Dict] = []
            for i, c in enumerate(chunks):
                text = c.get("text", "")
                batch_texts.append(text)
                # 保留原来的 meta 字段，并且保证有 text/ex_id/title
                meta = {
                    "text": text,
                    "ex_id": c.get("ex_id", -1),
                    "title": c.get("title", ""),
                }
                # 如果原 jsonl 里有其他字段，也一并写回去
                for k, v in c.items():
                    if k not in meta:
                        meta[k] = v
                batch_metas.append(meta)

                # 批量编码
                if len(batch_texts) >= batch_size or i == len(chunks) - 1:
                    embs = model.encode(
                        batch_texts,
                        normalize_embeddings=True,
                        convert_to_numpy=True,
                    )
                    embs = np.asarray(embs, dtype="float32")
                    index.add(embs)

                    for m in batch_metas:
                        f_meta.write(json.dumps(m, ensure_ascii=False) + "\n")

                    batch_texts = []
                    batch_metas = []

                if (i + 1) % 50000 == 0:
                    print(f"[{gran}] encoded {i+1}/{len(chunks)}")

        # 保存索引
        faiss.write_index(index, str(index_path))
        print(f"[SAVE] {split}-{gran} index -> {index_path}")
        print(f"[SAVE] {split}-{gran} meta  -> {meta_path}")

    print(f"=== Done build indices for 2Wiki split={split} ===")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--split",
        type=str,
        required=True,
        choices=["train", "dev"],
        help="which split of 2Wiki to index",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=1024,
        help="embedding batch size",
    )
    args = parser.parse_args()

    build_index_for_split(split=args.split, batch_size=args.batch_size)


if __name__ == "__main__":
    main()
