# mog_rag/rag_pipeline.py
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import os
import re
import time
import inspect

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

from .config import MAX_CONTEXT_TOKENS, TOTAL_TOPK, GRANULARITIES, LLM_MODEL_PATH
from .retrieval import MultiGranRetriever, RetrievedChunk
from .router import GranularityRouter

import os
import re
import random
import numpy as np
import torch

CLOSED_BOOK = os.getenv("CLOSED_BOOK", "0") == "1"

SYSTEM_PROMPT = (
    "You are a question answering system.\n"
    "Answer the question using only your internal knowledge (closed-book).\n"
    "Return the final answer only, with no explanation, no punctuation, and no extra words.\n"
    "If the answer contains multiple entities, return them as a comma-separated list.\n"
    "If the question asks “how many / what number”, return only the number.\n"
    'If the question is yes/no, return only "yes" or "no".\n'
)

def build_closedbook_prompt(question: str) -> str:
    return f"{SYSTEM_PROMPT}\n\nQuestion:\n{question}\n\nFinal Answer:\n"

def postprocess_pred(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip()
    s = s.split("\n")[0].strip()   # 只保留第一行，防止输出解释
    s = re.sub(r"\s+", " ", s)
    return s

def set_eval_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)




def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except Exception:
        return int(default)


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, None)
    if v is None:
        return bool(default)
    v = str(v).strip().lower()
    return v in ("1", "true", "yes", "y", "t", "on")


def _clean_spaces(s: str) -> str:
    s = (s or "").replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _filter_kwargs(fn: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Only keep kwargs that fn accepts (unless fn has **kwargs)."""
    try:
        sig = inspect.signature(fn)
        params = sig.parameters
        # if has **kwargs
        for p in params.values():
            if p.kind == inspect.Parameter.VAR_KEYWORD:
                return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in params}
    except Exception:
        return dict(kwargs)


def _build_router(emb_dim: int, num_grans: int) -> GranularityRouter:
    """
    Build GranularityRouter without assuming its __init__ signature.
    Tries common parameter name variants + positional fallbacks.
    """
    # candidate kwarg dictionaries (ordered)
    cand_kwargs = [
        {"emb_dim": emb_dim, "num_granularities": num_grans},
        {"emb_dim": emb_dim, "n_granularities": num_grans},
        {"emb_dim": emb_dim, "num_grans": num_grans},
        {"emb_dim": emb_dim, "n_grans": num_grans},
        {"emb_dim": emb_dim, "num_classes": num_grans},
        {"emb_dim": emb_dim, "n_classes": num_grans},
        {"qdim": emb_dim, "num_granularities": num_grans},
        {"qdim": emb_dim, "num_grans": num_grans},
        {"input_dim": emb_dim, "num_grans": num_grans},
        {"in_dim": emb_dim, "num_grans": num_grans},
        {"emb_dim": emb_dim},  # maybe fixed output dim inside
        {"qdim": emb_dim},
        {},  # ultimate fallback
    ]

    init_fn = GranularityRouter.__init__
    for kw in cand_kwargs:
        try:
            use_kw = _filter_kwargs(init_fn, kw)
            router = GranularityRouter(**use_kw)
            print(f"[Router] init ok with kwargs={use_kw}")
            return router
        except TypeError:
            continue
        except Exception:
            continue

    # positional fallbacks
    for args in [(emb_dim, num_grans), (emb_dim,), ()]:
        try:
            router = GranularityRouter(*args)
            print(f"[Router] init ok with args={args}")
            return router
        except Exception:
            pass

    raise RuntimeError("Failed to initialize GranularityRouter: signature mismatch")


class HotpotRAGPipeline:
    """
    Main RAG pipeline used by evaluate_hotpot.py.

    Key env vars:
      - LLM_PATH (or LLM_MODEL_PATH)
      - USE_ROUTER=0/1, ROUTER_CKPT
      - USE_BUDGETER=0/1, BUDGETER_CKPT
      - CTX_BUDGET, TOTAL_TOPK, STAGE1_TOTAL_TOPK, RERANK_TOP_M
      - NO_CTX_TOKEN_LIMIT=1 to disable ctx token limit
    """

    def __init__(self, split: str = "dev") -> None:
        self.split = split

        llm_path = os.getenv("LLM_PATH", "").strip()
        if not llm_path:
            llm_path = os.getenv("LLM_MODEL_PATH", "").strip()
        if not llm_path:
            llm_path = str(LLM_MODEL_PATH)
        self.llm_path = llm_path

        self.use_router = _env_bool("USE_ROUTER", False)
        self.use_budgeter = _env_bool("USE_BUDGETER", False)

        use_reranker = _env_bool("USE_RERANKER", True)
        self.retriever = MultiGranRetriever(split=self.split, use_reranker=use_reranker, router=None)

        # -------- Router --------
        self.router: Optional[GranularityRouter] = None
        if self.use_router:
            ckpt = os.getenv("ROUTER_CKPT", "").strip()
            if not ckpt:
                raise ValueError("USE_ROUTER=1 but ROUTER_CKPT is empty")

            qdim = int(self.retriever._encode_query("dummy").shape[1])
            self.router = _build_router(emb_dim=qdim, num_grans=len(GRANULARITIES))

            state = torch.load(ckpt, map_location="cpu")
            sd = state.get("state_dict", state) if isinstance(state, dict) else state

            cleaned: Dict[str, Any] = {}
            if isinstance(sd, dict):
                for k, v in sd.items():
                    nk = k
                    for pref in ("model.", "module.", "router."):
                        if nk.startswith(pref):
                            nk = nk[len(pref):]
                    cleaned[nk] = v

            missing, unexpected = self.router.load_state_dict(cleaned, strict=False)
            self.router.eval()
            self.router.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            print(f"[Router] loaded {ckpt} (missing={len(missing)} unexpected={len(unexpected)})")
            self.retriever.router = self.router

        # -------- Budgeter --------
        self.budgeter = None
        if self.use_budgeter:
            from .budgeter_runtime import BudgeterRuntime

            ckpt = os.getenv("BUDGETER_CKPT", os.getenv("BUDGET_CKPT", "")).strip()
            if not ckpt:
                ckpt = "budget_regressor_v2.pt"

            self.budgeter = BudgeterRuntime(
                emb_dim=0,
                device=("cuda" if torch.cuda.is_available() else "cpu"),
                ckpt_path=ckpt,
                debug=_env_bool("BUDGETER_DEBUG", False),
            )

        # -------- LLM --------
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True, use_fast=True)
        except Exception:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True, use_fast=False)

        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            self.llm_path,
            torch_dtype=dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()

        # -------- Optional packer (fallback when no budgeter) --------
        self.packer = None
        try:
            from .packer import CoveragePacker

            # do NOT assume constructor param names
            ctor_kwargs = {
                "count_tokens": self._count_tokens,
                "max_per_title": _env_int("PACKER_MAX_PER_TITLE", 2),
                "max_per_doc": _env_int("PACKER_MAX_PER_DOC", 4),
                "max_total_chunks": _env_int("PACKER_MAX_TOTAL_CHUNKS", 120),
            }
            use_kwargs = _filter_kwargs(CoveragePacker.__init__, ctor_kwargs)
            self.packer = CoveragePacker(**use_kwargs)
        except Exception as e:
            print(f"[WARN] packer disabled (import/init failed): {e}")

    def _count_tokens(self, text: str) -> int:
        try:
            return int(len(self.tokenizer.encode(text, add_special_tokens=False)))
        except Exception:
            return max(1, len((text or "").split()))

    def _chunk_to_ctx_block(self, c: RetrievedChunk, idx: int) -> str:
        title = _clean_spaces(getattr(c, "title", ""))
        text = _clean_spaces(getattr(c, "text", ""))
        if title:
            return f"[{idx}] {title}: {text}"
        return f"[{idx}] {text}"

    def _pack_greedy(self, candidates: List[RetrievedChunk], budget_tokens: int) -> Tuple[List[RetrievedChunk], Dict[str, Any]]:
        used = 0
        picked: List[RetrievedChunk] = []
        for c in candidates:
            t = self._count_tokens(getattr(c, "text", "") or "")
            if used + t > budget_tokens:
                continue
            picked.append(c)
            used += t
        return picked, {"packer": "greedy", "used_tokens": int(used)}

    def _ctx_token_stats(self, chunks: List[RetrievedChunk]) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for c in chunks:
            g = getattr(c, "granularity", "unk")
            out[g] = out.get(g, 0) + self._count_tokens(getattr(c, "text", "") or "")
        return out

    def answer(self, question: str, debug: bool = False) -> Tuple[str, Dict[str, Any]]:
        t0 = time.time()

        ctx_budget = _env_int("CTX_BUDGET", int(MAX_CONTEXT_TOKENS))
        if ctx_budget <= 0 or _env_bool("NO_CTX_TOKEN_LIMIT", False):
            ctx_budget = 10**9

        total_topk = _env_int("TOTAL_TOPK", int(TOTAL_TOPK))
        stage1_total_topk = _env_int("STAGE1_TOTAL_TOPK", int(total_topk))
        rerank_top_m = _env_int("RERANK_TOP_M", 160)

        prior_share = None
        alloc: Dict[str, int] = {}

        # candidates: ALWAYS List[RetrievedChunk]
        if stage1_total_topk > total_topk:
            candidates, alloc = self.retriever.retrieve_stagewise(
                query=question,
                budget_tokens=ctx_budget,
                stage1_total_topk=stage1_total_topk,
                rerank_top_m=rerank_top_m,
                prior_share=prior_share,
            )
        else:
            candidates = self.retriever.retrieve_multi_gran(
                query=question,
                budget_tokens=ctx_budget,
                total_topk=total_topk,
                prior_share=prior_share,
            )
            alloc = dict(getattr(self.retriever, "last_alloc", {}) or {})

        # selected: ALWAYS List[RetrievedChunk]
        budgeter_info: Dict[str, Any] = {}
        if self.use_budgeter and self.budgeter is not None:
            selected, budgeter_info = self.budgeter.select(
                question=question,
                candidates=candidates,
                budget_tokens=ctx_budget,
                tokenizer=self.tokenizer,
            )
        else:
            if self.packer is not None:
                # pack signatures vary; be robust
                try:
                    res = self.packer.pack(question, candidates, ctx_budget)
                    selected = getattr(res, "selected", None) or getattr(res, "chunks", None) or []
                    info = getattr(res, "info", None) or {}
                    budgeter_info = {"packer": "coverage_packer", **dict(info)}
                except Exception:
                    selected, budgeter_info = self._pack_greedy(candidates, ctx_budget)
            else:
                selected, budgeter_info = self._pack_greedy(candidates, ctx_budget)

        ctx_blocks = [self._chunk_to_ctx_block(c, i + 1) for i, c in enumerate(selected)]
        ctx_text = "\n".join(ctx_blocks)

        # ===== stable QA prompt (answer-only) =====
                # ===== stable prompt (Context + Question + Answer:) =====
        sys_msg = (
            "You are a question answering assistant.\n"
            "You MUST answer using the provided Context.\n"
            "Output ONLY the answer string. No explanation.\n"
            "For yes/no questions, output exactly: yes or no.\n"
        )

        user_msg = (
            f"Context:\n{ctx_text}\n\n"
            f"Question: {question}\n"
            "Answer:"
        )

        if hasattr(self.tokenizer, "apply_chat_template"):
            prompt = self.tokenizer.apply_chat_template(
                [{"role": "system", "content": sys_msg},
                 {"role": "user", "content": user_msg}],
                tokenize=False,
                add_generation_prompt=True,
            )
        else:
            # fallback: plain prompt
            prompt = sys_msg + "\n\n" + user_msg

        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        input_len = int(inputs["input_ids"].shape[-1])

        gen_kwargs = {
            "max_new_tokens": int(_env_int("MAX_NEW_TOKENS", 64)),
            "pad_token_id": self.tokenizer.eos_token_id,
            "eos_token_id": self.tokenizer.eos_token_id,
        }
        temperature = float(os.getenv("TEMPERATURE", "0.0"))
        top_p = float(os.getenv("TOP_P", "1.0"))
        if temperature > 1e-6:
            gen_kwargs.update({"do_sample": True, "temperature": float(temperature), "top_p": float(top_p)})
        else:
            gen_kwargs.update({"do_sample": False})

        with torch.inference_mode():
            out_ids = self.model.generate(**inputs, **gen_kwargs)

        # ✅ decode ONLY newly generated tokens (avoids "assistant" leak from template)
        gen_ids = out_ids[0][input_len:]
        ans = self.tokenizer.decode(gen_ids, skip_special_tokens=True).strip()

        # extra robust cleanup
        # sometimes models may start with role tokens or punctuation
        ans = ans.strip()
        if ans.lower().startswith("assistant"):
            ans = ans[len("assistant"):].lstrip(": \n\t")

        # take first non-empty line
        lines = [x.strip() for x in ans.splitlines() if x.strip()]
        ans = lines[0] if lines else ans.strip()

        # strip quotes
        ans = ans.strip().strip('"').strip("'")


  #      sys_msg = (
  #          "You are an open-domain question answering system.\n"
  #          "Rules:\n"
  #          "- Use the given Context to answer the Question.\n"
  #          "- Output ONLY the final answer string. No explanation, no steps, no extra words.\n"
  #          "- For yes/no questions, output exactly: yes or no.\n"
  #          "- If the answer is an entity, output the shortest canonical name.\n"
  #      )
  #      user_msg = (
  #          f"Context:\n{ctx_text}\n\n"
  #          f"Question: {question}\n"
  #          "Final Answer:"
  #      )

 #       if hasattr(self.tokenizer, "apply_chat_template"):
 #           prompt = self.tokenizer.apply_chat_template(
 #               [{"role": "system", "content": sys_msg}, {"role": "user", "content": user_msg}],
 #               tokenize=False,
 #               add_generation_prompt=True,
 #           )
 #       else:
 #           prompt = sys_msg + "\n" + user_msg
#
#        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)

#        gen_kwargs = {
#            "max_new_tokens": int(_env_int("MAX_NEW_TOKENS", 64)),
#            "pad_token_id": self.tokenizer.eos_token_id,
#        }
#        temperature = float(os.getenv("TEMPERATURE", "0.0"))
#        top_p = float(os.getenv("TOP_P", "1.0"))
#        if temperature > 1e-6:
#            gen_kwargs.update({"do_sample": True, "temperature": float(temperature), "top_p": float(top_p)})
#        else:
#            gen_kwargs.update({"do_sample": False})

#        with torch.inference_mode():
#            out_ids = self.model.generate(**inputs, **gen_kwargs)
#
#        decoded = self.tokenizer.decode(out_ids[0], skip_special_tokens=True)

#        ans = decoded
 #       if ans.startswith(prompt):
  #          ans = ans[len(prompt):].strip()
#
 #       for key in ("Final Answer:", "Answer:", "FINAL:", "final answer:"):
  #          if key in ans:
   #             ans = ans.split(key)[-1].strip()
#
 #       lines = [x.strip() for x in ans.splitlines() if x.strip()]
  #      ans = lines[0] if lines else ans.strip()
   #     ans = ans.strip().strip('"').strip("'")

        dbg: Dict[str, Any] = {}
        if debug or _env_bool("PRINT_CTX_STATS", False):
            dbg = {
                "alloc_topk": alloc,
                "budgeter_info": budgeter_info,
                "ctx_token_stats": self._ctx_token_stats(selected),
                "n_candidates": int(len(candidates)),
                "n_selected": int(len(selected)),
                "elapsed_sec": float(time.time() - t0),
            }
        return ans, dbg
