from __future__ import annotations
from typing import Dict, List, Tuple
from pathlib import Path
import json
import argparse

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
import faiss
from sentence_transformers import SentenceTransformer

from .config import (
    HOTPOT_TRAIN,
    INDEX_DIR,
    EMB_MODEL_PATH,
    GRANULARITIES,
    MAX_CONTEXT_TOKENS,
)
from .utils import load_hotpot, get_supporting_facts, chunk_support_overlap
from .router import GranularityRouter

# 检查当前 faiss 是否支持 GPU
FAISS_HAS_GPU = hasattr(faiss, "StandardGpuResources")


class RouterTrainer:
    """
    用 Hotpot train + train 索引训练粒度路由器。

    思路：
      1）对每个样本，在 sent / para / doc 三个粒度上分别做 top-K dense 检索；
      2）用 supporting facts 与检索到的 chunks 的重叠，估计每个粒度的“问答友好度”得分 S_g；
      3）把 {S_sent, S_para, S_doc} 经过 softmax（带温度 temp）得到 soft label y_g；
      4）路由器输入 (query, budget_tokens)，输出 p(g | q, B)，用 KLDivLoss 做 teacher-student 学习。
    """

    def __init__(
        self,
        device: str = "cuda",
        topk_per_granularity: int = 32,
        temp: float = 0.5,
        max_train_examples: int = -1,
    ):
        """
        device:   训练 MLP（router）的设备；faiss 是否用 GPU 由 FAISS_HAS_GPU 决定。
        topk_per_granularity: 每个粒度上检索的 top-K 数量。
        temp:     softmax 的温度，越小分布越尖锐。
        max_train_examples: >0 时只用前 N 个样本，<=0 表示用全量 train。
        """
        # MLP / torch 的 device
        if "cuda" in device and torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        self.topk = topk_per_granularity
        self.temp = temp
        self.max_train_examples = max_train_examples

        # encoder 放在有 GPU 时就放 GPU
        encoder_device = "cuda" if torch.cuda.is_available() else "cpu"

        # FAISS GPU 资源（如果 faiss 没 GPU，就设为 None，后面自动走 CPU 分支）
        if torch.cuda.is_available() and FAISS_HAS_GPU:
            self.gpu_id = 0
            self.gpu_res = faiss.StandardGpuResources()
            print("[FAISS] GPU 支持已启用，用 GPU 做索引检索。")
        else:
            self.gpu_id = -1
            self.gpu_res = None
            print("[FAISS] 当前环境没有 GPU 版 faiss，索引检索将使用 CPU。")

        # 冻结的 query encoder（BGE）
        self.q_encoder = SentenceTransformer(str(EMB_MODEL_PATH), device=encoder_device)

        # 加载 train 索引（FAISS，如有 GPU 则搬到 GPU）
        self.indices: Dict[str, faiss.Index] = {}
        self.metas: Dict[str, List[Dict]] = {}
        self._load_indices(split="train")

        # 路由器（MLP 在 self.device 上训练）
        self.router = GranularityRouter().to(self.device)
        self.optimizer = torch.optim.Adam(self.router.mlp.parameters(), lr=1e-3)
        self.criterion = nn.KLDivLoss(reduction="batchmean")

    # ------------------------------------------------------------------
    # 索引加载 & 查询编码
    # ------------------------------------------------------------------
    def _load_indices(self, split: str = "train") -> None:
        """
        读取 train 索引：
        - 先从磁盘读 CPU 版 index.faiss
        - 若 GPU 可用且 faiss 支持 GPU，则用 faiss.index_cpu_to_gpu 搬到 GPU
        """
        for gran in GRANULARITIES:
            out_dir = INDEX_DIR / split / gran
            index_path = out_dir / "index.faiss"
            meta_path = out_dir / "meta.jsonl"
            if not index_path.exists():
                print(f"[WARN] index not found for {split}-{gran}, skip.")
                continue

            index_cpu = faiss.read_index(str(index_path))
            if self.gpu_res is not None and self.gpu_id >= 0:
                index = faiss.index_cpu_to_gpu(self.gpu_res, self.gpu_id, index_cpu)
                print(f"[LOAD][GPU] {split}-{gran} index -> GPU{self.gpu_id}")
            else:
                index = index_cpu
                print(f"[LOAD][CPU] {split}-{gran} index")

            metas: List[Dict] = []
            with meta_path.open("r", encoding="utf-8") as f:
                for line in f:
                    metas.append(json.loads(line))

            self.indices[gran] = index
            self.metas[gran] = metas
            print(f"[LOAD] {split}-{gran}: {len(metas)} chunks.")

    def _encode_query(self, q: str) -> np.ndarray:
        emb = self.q_encoder.encode([q], normalize_embeddings=True)
        return np.asarray(emb, dtype="float32")

    # ------------------------------------------------------------------
    # 为单个粒度打分：S_g
    # ------------------------------------------------------------------
    def _score_granularity(
        self,
        q_emb: np.ndarray,
        ex_id: int,
        supporting_facts: List[Tuple[str, int]],
        gran: str,
    ) -> float:
        """
        在某个粒度上，用 top-K 检索 + supporting_facts 覆盖率 来给出一个 S_g。
        使用“较弱”的长度惩罚系数 0.5（这是你 F1≈0.698 时的版本），
        避免把 doc 粒度压制得太厉害。
        """
        if gran not in self.indices:
            return 0.0

        index = self.indices[gran]
        metas = self.metas[gran]

        scores, idxs = index.search(q_emb, self.topk)
        scores = scores[0]
        idxs = idxs[0]

        total_cov = 0
        lengths: List[int] = []

        for idx in idxs:
            if idx < 0:
                continue
            meta = metas[int(idx)]
            # 只关心同一个 Hotpot 样本的 chunk
            if int(meta.get("ex_id", -1)) != ex_id:
                continue

            cov, _ = chunk_support_overlap(meta, supporting_facts)
            total_cov += cov

            text = meta.get("text", "")
            if text:
                lengths.append(len(text.split()))

        if not supporting_facts:
            return 0.0

        # 把总覆盖数截断在 [0, len(supporting_facts)]
        max_cov = len(supporting_facts)
        total_cov = min(total_cov, max_cov)

        recall = total_cov / max_cov  # 0~1

        # 平均长度：较弱惩罚（系数 0.5）
        if not lengths:
            avg_len = 50.0
        else:
            avg_len = float(sum(lengths) / len(lengths))

        # 这是 F1≈0.698 那版用的系数：0.5
        avg_len_norm = avg_len / 200.0          # 大致每 200 token 归一
        length_penalty = 1.0 + 0.5 * avg_len_norm

        score = recall / length_penalty         # 仍然在 [0, 1] 范围内
        return float(score)

    # ------------------------------------------------------------------
    # 对一个样本构造 soft label：y_g
    # ------------------------------------------------------------------
    def _compute_soft_label_for_example(
        self,
        ex_id: int,
        ex: Dict,
    ) -> torch.Tensor:
        """
        对一个 Hotpot 样本，返回 shape [G] 的 soft label 向量。
        使用 supporting_facts 覆盖率 + 长度惩罚得到 S_g，再经 softmax(temp) 得到 y_g。
        """
        q = ex.get("question", "")
        supporting_facts = get_supporting_facts(ex)
        q_emb = self._encode_query(q)

        scores: List[float] = []
        for gran in GRANULARITIES:
            s_g = self._score_granularity(q_emb, ex_id, supporting_facts, gran)
            scores.append(s_g)

        scores_np = np.array(scores, dtype="float32")

        if np.all(scores_np == 0):
            # 如果所有粒度都没覆盖，退化为均匀分布
            probs = np.ones_like(scores_np) / max(1, len(scores_np))
        else:
            # 温度缩放：温度越小分布越尖锐
            temp = max(self.temp, 1e-6)
            scores_np = scores_np / temp
            exp = np.exp(scores_np - scores_np.max())
            probs = exp / exp.sum()

        return torch.tensor(probs, dtype=torch.float32)  # [G]

    # ------------------------------------------------------------------
    # 训练主循环
    # ------------------------------------------------------------------
    def train(self, num_epochs: int = 1, budget_tokens: int = MAX_CONTEXT_TOKENS):
        # 用 Hotpot train 做监督
        data = load_hotpot(HOTPOT_TRAIN)
        if self.max_train_examples and self.max_train_examples > 0:
            data = data[: self.max_train_examples]
            print(f"[ROUTER] use first {len(data)} examples from Hotpot train.")
        else:
            print(f"[ROUTER] use FULL train set: {len(data)} examples.")

        self.router.train()

        for epoch in range(num_epochs):
            total_loss = 0.0
            n = 0
            pbar = tqdm(
                enumerate(data),
                total=len(data),
                desc=f"Train router epoch {epoch+1}",
            )
            for ex_id, ex in pbar:
                # 1) soft label -> 搬到 self.device
                target = self._compute_soft_label_for_example(ex_id, ex)  # [G]
                target = target.to(self.device)

                # 2) router 输出（在 self.device 上）
                out = self.router(ex["question"], budget_tokens)
                probs = out.probs  # [G]
                log_probs = torch.log(probs + 1e-8).to(self.device)

                # 3) KL(target || pred)
                loss = self.criterion(
                    log_probs.unsqueeze(0), target.unsqueeze(0)
                )
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()
                n += 1
                if n % 100 == 0:
                    pbar.set_postfix(loss=total_loss / n)

            print(
                f"[ROUTER] epoch={epoch+1}  avg_loss={total_loss / max(1, n):.4f}"
            )

        # 保存 MLP 权重
        out_path = Path("router_mlp.pt")
        torch.save(self.router.mlp.state_dict(), out_path)
        print(f"[SAVE] router MLP weights -> {out_path}")


# ----------------------------------------------------------------------
# 命令行入口
# ----------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train granularity router on Hotpot train.")
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        help="torch device, e.g. 'cuda' or 'cpu'",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=3,
        help="number of training epochs (default: 3)",
    )
    parser.add_argument(
        "--max_examples",
        type=int,
        default=20000,
        help="if >0, only use first N train examples; <=0 means full train",
    )
    parser.add_argument(
        "--topk_per_gran",
        type=int,
        default=32,
        help="top-K per granularity when scoring (default: 32)",
    )
    parser.add_argument(
        "--temp",
        type=float,
        default=0.5,
        help="temperature for softmax over granularity scores (default: 0.5)",
    )

    args = parser.parse_args()

    trainer = RouterTrainer(
        device=args.device,
        topk_per_granularity=args.topk_per_gran,
        temp=args.temp,
        max_train_examples=args.max_examples,
    )

    # ====== 新增：如果指定了 init_from，就先加载已有的 MLP 权重，再继续训练 ======
    if args.init_from:
        ckpt_path = Path(args.init_from)
        if ckpt_path.exists():
            print(f"[INIT] loading router MLP weights from {ckpt_path}")
            state = torch.load(ckpt_path, map_location="cpu")
            model_state = trainer.router.mlp.state_dict()
            # 只加载匹配的 key / shape，防止以后改结构崩掉
            filtered = {
                k: v for k, v in state.items()
                if k in model_state and v.shape == model_state[k].shape
            }
            model_state.update(filtered)
            trainer.router.mlp.load_state_dict(model_state)
        else:
            print(f"[WARN] init_from ckpt not found: {ckpt_path}, training from scratch.")

    trainer.train(num_epochs=args.epochs, budget_tokens=MAX_CONTEXT_TOKENS)
