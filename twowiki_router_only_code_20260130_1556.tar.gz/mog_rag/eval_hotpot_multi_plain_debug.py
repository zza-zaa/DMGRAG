# mog_rag/eval_hotpot_multi_plain_debug.py
"""
HotpotQA 多粒度 plain baseline + debug 脚本（不用路由器和预算器）。

设计：
- 直接用 pipeline.retriever 里的 FAISS 索引，对 sent / para / doc
  三种粒度分别做 dense 检索，各取 TOPK_PER_GRANULARITY（通常是 20）；
- 把三个粒度的候选合在一起做 rerank（如果开启了 CrossEncoder）；
- 然后把上下文预算 B（默认 1024 token）按固定比例
      sent : para : doc = 1 : 2 : 4
  分成三个子预算：
      B_sent, B_para, B_doc
- 每个粒度内部按 rerank 后的顺序贪心装载：
    * 如果 chunk 长度 <= 剩余预算，就整块放进去；
    * 如果 chunk 太长，就把它 **截断** 到剩余预算长度，再放进去；
  保证：
    - 三个粒度只要有候选，就一定能拿到一些 token；
    - 总 token 数不超过 B（最多有一点点舍入误差）。

脚本会打印：
- [DEBUG][Candidates] gran_counts={...}   # 三个粒度候选数量
- [DEBUG][Budget-fixed pack] sample#k gran_tokens={...} total≈.../B
- [i] Context token stats by granularity: {...}
"""

from __future__ import annotations

import json
import os
import re
import string
from pathlib import Path
from typing import Any, Dict, List, Tuple

import torch
from tqdm import tqdm

from .config import HOTPOT_DEV, MAX_CONTEXT_TOKENS, TOPK_PER_GRANULARITY
from .rag_pipeline import HotpotRAGPipeline
from .retrieval import RetrievedChunk, MultiGranRetriever


# ====================== 文本归一化 & EM / F1 ======================


def _normalize_answer(s: str) -> str:
    """小写、去标点、去 a/an/the、压缩空格。"""
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_score(prediction: str, ground_truth: str) -> float:
    pred_tokens = _normalize_answer(prediction).split()
    gold_tokens = _normalize_answer(ground_truth).split()

    if not pred_tokens and not gold_tokens:
        return 1.0
    if not pred_tokens or not gold_tokens:
        return 0.0

    common: Dict[str, int] = {}
    for t in pred_tokens:
        common[t] = common.get(t, 0) + 1

    num_same = 0
    for t in gold_tokens:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0

    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


def _qa_em_f1(prediction: str, ground_truth: str) -> Tuple[float, float]:
    em = float(_normalize_answer(prediction) == _normalize_answer(ground_truth))
    f1 = _f1_score(prediction, ground_truth)
    return em, f1


# ====================== 读 Hotpot dev ======================


def _load_hotpot_dev(hotpot_json: str, limit: int | None) -> List[Dict[str, str]]:
    path = Path(hotpot_json)
    if not path.exists():
        raise FileNotFoundError(f"Hotpot dev 文件不存在: {path}")

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if limit is not None:
        data = data[:limit]

    examples: List[Dict[str, str]] = []
    for ex in data:
        q = ex.get("question", "").strip()
        a = ex.get("answer", "").strip()
        examples.append({"question": q, "answer": a})

    return examples


# ====================== 辅助函数：多粒度 plain 检索 ======================


ALL_GRANS = ["sent", "para", "doc"]


def multi_retrieve_plain(
    retriever: MultiGranRetriever,
    query: str,
    per_gran_topk: int,
) -> List[RetrievedChunk]:
    """
    不用 router 的情况下，直接对每个粒度做 dense 检索各取 per_gran_topk，
    然后合在一起做一次 rerank（如果 retriever.use_reranker=True）。
    """
    # 用内部 encoder 得到 query embedding
    q_emb = retriever._encode_query(query)  # [1, d]

    all_chunks: List[RetrievedChunk] = []

    for gran in ALL_GRANS:
        if gran not in retriever.indices:
            continue
        index = retriever.indices[gran]
        metas = retriever.metas.get(gran, [])
        if not metas:
            continue

        k_eff = min(per_gran_topk, len(metas))
        scores, idxs = index.search(q_emb, k_eff)
        scores = scores[0]
        idxs = idxs[0]

        for score, idx in zip(scores, idxs):
            if idx < 0:
                continue
            meta = metas[int(idx)]
            text = meta.get("text", "")
            ex_id = int(meta.get("ex_id", -1))
            title = meta.get("title", "")
            c = RetrievedChunk(
                chunk_id=int(idx),
                text=text,
                granularity=gran,
                granularity_id=retriever.gran2id.get(gran, 0),
                ex_id=ex_id,
                title=title,
                dense_score=float(score),
            )
            all_chunks.append(c)

    if not all_chunks:
        return []

    # 可选：CrossEncoder rerank
    if retriever.use_reranker and retriever.reranker is not None:
        pairs = [(query, c.text) for c in all_chunks]
        with torch.no_grad():
            rerank_scores = retriever.reranker.predict(pairs)
        for c, s in zip(all_chunks, rerank_scores):
            c.rerank_score = float(s)
        all_chunks.sort(key=lambda x: x.rerank_score, reverse=True)
    else:
        all_chunks.sort(key=lambda x: x.dense_score, reverse=True)

    return all_chunks


# ====================== 按固定比例分配 budget 并截断 ======================


def pack_chunks_fixed_ratio(
    candidates: List[RetrievedChunk],
    ctx_budget: int,
    sample_idx: int | None = None,
) -> Tuple[List[RetrievedChunk], Dict[str, int]]:
    """
    把总预算 ctx_budget 按固定比例分给各粒度，并在每个粒度内部贪心装载：

      sent : para : doc = 1 : 2 : 4

    - 对每个粒度 g：
        * 子预算 B_g = round(B * w_g / sum_w)
        * 遍历该粒度的候选（保持全局 rerank 顺序）：
            - 若 len(chunk) <= 剩余 B_g，则整块放入；
            - 若 len(chunk) > 剩余 B_g 且剩余 B_g > 0，则截断文本，放入后停止该粒度。
    - 返回：
        * selected_chunks：装载好的块列表
        * gran_tokens：每个粒度实际使用的 token 数
    """
    if not candidates:
        return [], {}

    # 1) 按粒度分组
    by_gran: Dict[str, List[RetrievedChunk]] = {g: [] for g in ALL_GRANS}
    for c in candidates:
        if c.granularity in by_gran:
            by_gran[c.granularity].append(c)

    # 2) 固定比例：sent:para:doc = 1:2:4
    weight_map = {"sent": 1.0, "para": 2.0, "doc": 4.0}
    active_grans = [g for g in ALL_GRANS if by_gran[g]]  # 有候选的粒度
    if not active_grans:
        return [], {}

    weights = {g: weight_map[g] for g in active_grans}
    sum_w = sum(weights.values())

    gran_budget: Dict[str, int] = {}
    allocated = 0
    for g in active_grans:
        b = int(ctx_budget * weights[g] / sum_w)
        gran_budget[g] = b
        allocated += b

    # 把取整损失的预算补回去（优先给权重大的一方）
    remainder = ctx_budget - allocated
    if remainder > 0:
        for g, _ in sorted(weights.items(), key=lambda x: -x[1]):  # doc 优先
            if remainder <= 0:
                break
            gran_budget[g] += 1
            remainder -= 1

    # 3) 各粒度内部贪心 + 截断
    selected: List[RetrievedChunk] = []
    gran_tokens: Dict[str, int] = {g: 0 for g in active_grans}

    # 为了保持全局排序一致，先把所有候选按 gran 分桶后，再按 gran 顺序独立遍历
    for g in active_grans:
        budget_g = gran_budget[g]
        used_g = 0
        for c in by_gran[g]:
            if used_g >= budget_g:
                break
            tokens = c.text.split()
            length = len(tokens)
            remain = budget_g - used_g
            if length <= remain:
                # 整块放入
                selected.append(c)
                used_g += length
            else:
                # 截断到 remain 个 token
                if remain <= 0:
                    break
                truncated_text = " ".join(tokens[:remain])
                truncated_chunk = RetrievedChunk(
                    chunk_id=c.chunk_id,
                    text=truncated_text,
                    granularity=c.granularity,
                    granularity_id=c.granularity_id,
                    ex_id=c.ex_id,
                    title=c.title,
                    dense_score=c.dense_score,
                    rerank_score=c.rerank_score,
                )
                selected.append(truncated_chunk)
                used_g += remain
                break  # 该粒度预算耗尽

        gran_tokens[g] = used_g

    total_tokens = sum(gran_tokens.values())
    if sample_idx is not None and sample_idx <= 10:
        print(
            f"[DEBUG][Budget-fixed pack] sample#{sample_idx} "
            f"gran_tokens={gran_tokens} total≈{total_tokens}/{ctx_budget}"
        )

    return selected, gran_tokens


# ====================== 主评测函数（multi-plain-debug） ======================


def evaluate_hotpot_multi_plain_debug(
    hotpot_json: str,
    limit: int = 50,
    ctx_budget: int | None = None,
) -> None:
    """
    多粒度 plain baseline（不用路由器/预算器）+ 详细 debug。

    流程：
    - pipeline = HotpotRAGPipeline(use_router=False, use_budget_regressor=False)
    - retriever = pipeline.retriever
    - 对每个问题：
        * multi_retrieve_plain(...) 得到 sent/para/doc 各 topK 候选；
        * pack_chunks_fixed_ratio(...) 对三粒度按 1:2:4 分配 budget 并截断；
        * 用 pipeline._build_context / _build_prompt 构造 prompt；
        * 调用 Qwen 生成答案，做后处理；
        * 打印 QA、Top-1 chunk、分粒度 token 统计；
        * 累积 EM / F1。
    """
    if ctx_budget is None:
        ctx_budget = int(os.getenv("CTX_BUDGET", MAX_CONTEXT_TOKENS))

    print(f"[INFO] Using ctx_budget={ctx_budget} tokens")

    # 1. 初始化 pipeline（只用 LLM + prompt，禁用 router / budget）
    pipeline = HotpotRAGPipeline(
        use_router=False,
        use_budget_regressor=False,
    )
    retriever: MultiGranRetriever = pipeline.retriever

    print(f"[DEBUG] retriever.indices keys = {list(retriever.indices.keys())}")

    # 2. 加载 Hotpot dev
    examples = _load_hotpot_dev(hotpot_json, limit=limit)
    n = len(examples)

    total_em = 0.0
    total_f1 = 0.0

    for idx, ex in enumerate(
        tqdm(examples, desc="Evaluating Hotpot multi-plain-debug", dynamic_ncols=True)
    ):
        question = ex["question"]
        gold = ex["answer"]

        # 3. 多粒度 plain 检索（每粒度各取 TOPK_PER_GRANULARITY）
        candidates = multi_retrieve_plain(
            retriever=retriever,
            query=question,
            per_gran_topk=TOPK_PER_GRANULARITY,
        )

        # 候选粒度分布
        gran_counts: Dict[str, int] = {}
        for c in candidates:
            gran_counts[c.granularity] = gran_counts.get(c.granularity, 0) + 1
        if idx < 10:
            print(f"[DEBUG][Candidates] gran_counts={gran_counts}")

        # 4. 按固定比例分配 token 并截断
        selected_chunks, gran_tokens = pack_chunks_fixed_ratio(
            candidates=candidates,
            ctx_budget=ctx_budget,
            sample_idx=idx + 1,
        )

        # 5. 构造 prompt & 调 LLM
        context = pipeline._build_context(question, selected_chunks)
        prompt = pipeline._build_prompt(question, context)

        inputs = pipeline.tokenizer(
            prompt,
            return_tensors="pt",
        ).to(pipeline.device)
        if "token_type_ids" in inputs:
            inputs.pop("token_type_ids")

        with torch.no_grad():
            outputs = pipeline.model.generate(
                **inputs,
                max_new_tokens=32,
                do_sample=False,
                temperature=0.0,
                top_p=1.0,
                top_k=0,
            )

        gen_ids = outputs[0, inputs["input_ids"].shape[1]:]
        raw_gen = pipeline.tokenizer.decode(gen_ids, skip_special_tokens=True)
        pred = pipeline._postprocess_answer(raw_gen)

        # 6. 打印 QA + Top-1 chunk + token 分布
        print("=" * 80)
        print(f"[{idx}] Question:")
        print(question)
        print(f"[{idx}] Gold Answer:")
        print(gold)
        print(f"[{idx}] Pred Answer:")
        print(pred)

        if selected_chunks:
            top1 = selected_chunks[0]
            print()
            print(f"[{idx}] Top-1 Retrieved Chunk (gran={top1.granularity}):")
            print(top1.text)

        print(f"[{idx}] Context token stats by granularity: {gran_tokens}")
        print("=" * 80)
        print()

        # 7. 累积 EM / F1
        em, f1 = _qa_em_f1(pred, gold)
        total_em += em
        total_f1 += f1

    avg_em = total_em / n if n > 0 else 0.0
    avg_f1 = total_f1 / n if n > 0 else 0.0
    print(f"[RESULT] N={n}  EM={avg_em:.3f}  F1={avg_f1:.3f}")


# ====================== 命令行入口 ======================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--hotpot_json",
        type=str,
        default=str(HOTPOT_DEV),
        help="Hotpot dev JSON 路径（默认用 config 里的 HOTPOT_DEV）",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="评测样本数（默认 50）",
    )
    args = parser.parse_args()

    ctx_budget = int(os.getenv("CTX_BUDGET", MAX_CONTEXT_TOKENS))

    evaluate_hotpot_multi_plain_debug(
        hotpot_json=args.hotpot_json,
        limit=args.limit,
        ctx_budget=ctx_budget,
    )
