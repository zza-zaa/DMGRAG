# mog_rag/packer.py
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Callable
from collections import Counter
import re

from .retrieval import RetrievedChunk


def extract_q_entities_light(question: str) -> List[str]:
    q = question or ""
    years = re.findall(r"\b(1[0-9]{3}|20[0-9]{2})\b", q)
    toks = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", q)
    spans = []
    cur = []
    for t in toks:
        if t[:1].isupper():
            cur.append(t)
        else:
            if cur:
                spans.append(" ".join(cur))
                cur = []
    if cur:
        spans.append(" ".join(cur))
    out = []
    seen = set()
    for x in years + spans:
        s = x.strip()
        if s and s.lower() not in seen:
            out.append(s)
            seen.add(s.lower())
    return out


@dataclass
class PackResult:
    selected: List[RetrievedChunk]
    info: Dict[str, Any]


class CoveragePacker:
    """
    目标：在预算内尽量覆盖更多 title（证据页）、更多问题实体、并保持相关性高。
    不依赖 chunk embedding，速度稳定。
    """

    def __init__(
        self,
        count_tokens: Callable[[str], int],
        max_per_title: int = 3,
        w_rel: float = 1.0,
        w_new_title: float = 0.55,
        w_new_ent: float = 0.25,
        w_new_gran: float = 0.05,
        w_title_rep: float = 0.60,
        debug_cap: int = 80,
    ):
        self.count_tokens = count_tokens
        self.max_per_title = int(max_per_title)
        self.w_rel = float(w_rel)
        self.w_new_title = float(w_new_title)
        self.w_new_ent = float(w_new_ent)
        self.w_new_gran = float(w_new_gran)
        self.w_title_rep = float(w_title_rep)
        self.debug_cap = int(debug_cap)

    def _rel(self, c: RetrievedChunk) -> float:
        return float(c.rerank_score) if c.rerank_score != 0.0 else float(c.dense_score)

    def pack(self, question: str, candidates: List[RetrievedChunk], budget_tokens: int) -> PackResult:
        if not candidates:
            return PackResult(selected=[], info={"packer": "coverage", "steps": []})

        ents = [e.lower() for e in extract_q_entities_light(question)]
        hit_cache: List[set] = []
        for c in candidates:
            tl = (c.text or "").lower()
            hits = set()
            for e in ents:
                if e and e in tl:
                    hits.add(e)
            hit_cache.append(hits)

        used_titles = Counter()
        used_grans = set()
        covered_ents = set()

        selected: List[RetrievedChunk] = []
        selected_idx = set()
        total = 0
        steps = []

        # 预计算 token cost
        costs = [max(1, int(self.count_tokens(c.text or ""))) for c in candidates]

        for _ in range(100000):
            best_i = None
            best_score = -1e18

            for i, c in enumerate(candidates):
                if i in selected_idx:
                    continue
                cost = costs[i]
                if total + cost > budget_tokens:
                    continue
                if used_titles[c.title] >= self.max_per_title:
                    continue

                gain = 0.0
                if c.title and used_titles[c.title] == 0:
                    gain += self.w_new_title
                if c.granularity not in used_grans:
                    gain += self.w_new_gran
                new_ents = hit_cache[i] - covered_ents
                if new_ents:
                    gain += self.w_new_ent * float(len(new_ents))

                pen = 0.0
                if used_titles[c.title] > 0:
                    pen += self.w_title_rep * float(used_titles[c.title])

                sc = self.w_rel * self._rel(c) + gain - pen
                if sc > best_score:
                    best_score = sc
                    best_i = i

            if best_i is None:
                break

            c = candidates[best_i]
            selected.append(c)
            selected_idx.add(best_i)
            used_titles[c.title] += 1
            used_grans.add(c.granularity)
            covered_ents |= hit_cache[best_i]
            total += costs[best_i]

            if len(steps) < self.debug_cap:
                steps.append({
                    "pick": int(best_i),
                    "title": c.title,
                    "gran": c.granularity,
                    "cost": int(costs[best_i]),
                    "total": int(total),
                    "score": float(best_score),
                    "covered_q_entities": int(len(covered_ents)),
                })

            if total >= budget_tokens:
                break

        info = {
            "packer": "coverage",
            "budget": int(budget_tokens),
            "used_tokens": int(total),
            "unique_titles": int(sum(1 for _, k in used_titles.items() if k > 0)),
            "covered_q_entities": int(len(covered_ents)),
            "steps": steps,
        }
        return PackResult(selected=selected, info=info)
