from __future__ import annotations
from pathlib import Path
import json
from typing import List, Dict
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from .config import CORPUS_DIR, INDEX_DIR, EMB_MODEL_PATH, EMB_BATCH_SIZE, GRANULARITIES

def _load_jsonl(path: Path) -> List[Dict]:
    samples = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            samples.append(json.loads(line))
    return samples

def _encode_texts(model: SentenceTransformer, texts: List[str], batch_size: int = 64) -> np.ndarray:
    embs = model.encode(
        texts,
        batch_size=batch_size,
        show_progress_bar=True,
        normalize_embeddings=True
    )
    return np.asarray(embs, dtype="float32")

def build_index_for_split(split_name: str):
    model = SentenceTransformer(str(EMB_MODEL_PATH))
    INDEX_DIR.mkdir(parents=True, exist_ok=True)

    for gran in GRANULARITIES:
        corpus_path = CORPUS_DIR / f"{split_name}_{gran}.jsonl"
        if not corpus_path.exists():
            print(f"[WARN] {corpus_path} not found, skip.")
            continue

        print(f"===> Building index for {split_name}-{gran}")
        samples = _load_jsonl(corpus_path)
        texts = [s["text"] for s in samples]

        embs = _encode_texts(model, texts, batch_size=EMB_BATCH_SIZE)
        dim = embs.shape[1]

        index = faiss.IndexFlatIP(dim)
        index.add(embs)

        # 保存向量与索引
        out_dir = INDEX_DIR / split_name / gran
        out_dir.mkdir(parents=True, exist_ok=True)

        np.save(out_dir / "emb.npy", embs)
        faiss.write_index(index, str(out_dir / "index.faiss"))
        with (out_dir / "meta.jsonl").open("w", encoding="utf-8") as f:
            for s in samples:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")

        print(f"[SAVE] {split_name}-{gran} index: {len(samples)} chunks -> {out_dir}")

def build_all_indices():
    build_index_for_split("train")
    build_index_for_split("dev")

if __name__ == "__main__":
    build_all_indices()
