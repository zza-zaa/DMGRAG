from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict
from pathlib import Path
import json
from .config import HOTPOT_TRAIN, HOTPOT_DEV, CORPUS_DIR, GRANULARITIES

@dataclass
class Chunk:
    id: str
    granularity: str   # "sent" / "para" / "doc"
    ex_id: int         # 对应 Hotpot 中样本序号
    title: str
    sent_ids: List[int]
    text: str

def _iter_hotpot_examples(hotpot_path: Path):
    with hotpot_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    for ex_id, ex in enumerate(data):
        yield ex_id, ex

def build_hotpot_chunks(hotpot_path: Path, split_name: str):
    """
    为 train / dev 构建多粒度 chunk
    """
    chunks_by_level: Dict[str, List[Chunk]] = {g: [] for g in GRANULARITIES}
    cid = 0

    for ex_id, ex in _iter_hotpot_examples(hotpot_path):
        # context: List[ [title, [sent0, sent1, ...]], ... ]
        # 细粒度：单句
        for title, sentences in ex["context"]:
            for sent_idx, sent in enumerate(sentences):
                chunks_by_level["sent"].append(
                    Chunk(
                        id=f"{split_name}_C{cid}",
                        granularity="sent",
                        ex_id=ex_id,
                        title=title,
                        sent_ids=[sent_idx],
                        text=sent.strip()
                    )
                )
                cid += 1

        # 段落粒度：同一 title 下所有句子合成一个段落
        for title, sentences in ex["context"]:
            sent_ids = list(range(len(sentences)))
            para_text = " ".join(s.strip() for s in sentences)
            chunks_by_level["para"].append(
                Chunk(
                    id=f"{split_name}_C{cid}",
                    granularity="para",
                    ex_id=ex_id,
                    title=title,
                    sent_ids=sent_ids,
                    text=para_text
                )
            )
            cid += 1

        # 文档级：把该样本所有 context 合起来
        all_text_parts = []
        all_sent_ids = []
        offset = 0
        for title, sentences in ex["context"]:
            all_text_parts.append(" ".join(s.strip() for s in sentences))
            all_sent_ids.extend(range(offset, offset + len(sentences)))
            offset += len(sentences)
        chunks_by_level["doc"].append(
            Chunk(
                id=f"{split_name}_C{cid}",
                granularity="doc",
                ex_id=ex_id,
                title="[DOC]",
                sent_ids=all_sent_ids,
                text=" ".join(all_text_parts)
            )
        )
        cid += 1

    return chunks_by_level

def save_chunks(chunks_by_level: Dict[str, List[Chunk]], split_name: str):
    CORPUS_DIR.mkdir(parents=True, exist_ok=True)
    for gran, chunks in chunks_by_level.items():
        out_path = CORPUS_DIR / f"{split_name}_{gran}.jsonl"
        with out_path.open("w", encoding="utf-8") as f:
            for ch in chunks:
                f.write(json.dumps(asdict(ch), ensure_ascii=False) + "\n")
        print(f"[SAVE] {split_name}-{gran}: {len(chunks)} chunks -> {out_path}")

def build_and_save_all():
    CORPUS_DIR.mkdir(parents=True, exist_ok=True)

    print("===> Build train chunks")
    train_chunks = build_hotpot_chunks(HOTPOT_TRAIN, split_name="train")
    save_chunks(train_chunks, "train")

    print("===> Build dev chunks")
    dev_chunks = build_hotpot_chunks(HOTPOT_DEV, split_name="dev")
    save_chunks(dev_chunks, "dev")

if __name__ == "__main__":
    build_and_save_all()
