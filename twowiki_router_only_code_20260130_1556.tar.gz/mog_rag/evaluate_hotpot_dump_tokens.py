# mog_rag/evaluate_hotpot_dump_tokens.py
from __future__ import annotations

import argparse
import json
import os
import re
from typing import Any, Dict, List, Tuple, Optional

from mog_rag.rag_pipeline import HotpotRAGPipeline


def _normalize_answer(s: str) -> str:
    if s is None:
        return ""
    s = str(s)

    def lower(text): return text.lower()
    def remove_punc(text): return re.sub(r"[^\w\s]", " ", text)
    def remove_articles(text): return re.sub(r"\b(a|an|the)\b", " ", text)
    def white_space_fix(text): return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_em(pred: str, gold: str) -> Tuple[float, float]:
    pred_n = _normalize_answer(pred)
    gold_n = _normalize_answer(gold)
    em = 1.0 if pred_n == gold_n else 0.0

    pred_toks = pred_n.split()
    gold_toks = gold_n.split()
    if len(pred_toks) == 0 and len(gold_toks) == 0:
        return 1.0, 1.0
    if len(pred_toks) == 0 or len(gold_toks) == 0:
        return 0.0, em

    common = {}
    for t in pred_toks:
        common[t] = common.get(t, 0) + 1
    num_same = 0
    for t in gold_toks:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0, em
    precision = num_same / len(pred_toks)
    recall = num_same / len(gold_toks)
    f1 = 2 * precision * recall / (precision + recall)
    return float(f1), float(em)


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _pick_split_path(split: str) -> str:
    # 优先走 config 里已经写死的路径
    try:
        from mog_rag.config import DEV_JSON, TEST_JSON, TRAIN_JSON
        if split == "dev":
            return str(DEV_JSON)
        if split == "test":
            return str(TEST_JSON)
        if split == "train":
            return str(TRAIN_JSON)
    except Exception:
        pass

    # fallback：尝试环境变量
    env_key = f"{split.upper()}_JSON"
    if os.getenv(env_key):
        return os.getenv(env_key)

    raise RuntimeError(f"Cannot locate split json for split={split}. "
                       f"Please set mog_rag.config.*_JSON or env {env_key}.")


def _extract_qa(ex: Dict[str, Any]) -> Tuple[str, str, str]:
    """
    兼容 Hotpot/2Wiki 常见字段：
    - qid/id/_id
    - question/q
    - answer/gold/answers[0]
    """
    qid = ex.get("qid") or ex.get("_id") or ex.get("id") or ex.get("idx") or ""
    q = ex.get("question") or ex.get("q") or ""
    gold = ex.get("answer")
    if gold is None:
        gold = ex.get("gold")
    if gold is None and isinstance(ex.get("answers"), list) and ex["answers"]:
        gold = ex["answers"][0]
    if gold is None:
        gold = ""
    return str(qid), str(q), str(gold)


def _safe(s: Any) -> str:
    try:
        return str(s)
    except Exception:
        return repr(s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="dev", choices=["train", "dev", "test"])
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--max_new_tokens", type=int, default=32)

    # dump 控制
    ap.add_argument("--chunk_preview_chars", type=int, default=600,
                    help="每个 chunk 打印多少字符；设为 -1 表示打印全文（非常大）")
    ap.add_argument("--print_chunks", type=int, default=1,
                    help="1=打印每题 chunks；0=不打印（只打印 token stats）")
    ap.add_argument("--out_jsonl", default="",
                    help="可选：把每题 debug 信息写入 jsonl 文件（便于后处理）")

    args = ap.parse_args()

    # 确保 pipeline 用你指定 split 的索引
    os.environ["EVAL_SPLIT"] = args.split

    data_path = _pick_split_path(args.split)
    data = _load_json(data_path)

    # 兼容 data 是 list 或 dict
    if isinstance(data, dict):
        # 常见 key：data / examples / questions
        for k in ["data", "examples", "questions", "instances"]:
            if k in data and isinstance(data[k], list):
                data = data[k]
                break
    if not isinstance(data, list):
        raise RuntimeError(f"Unexpected dataset format from {data_path}: type={type(data)}")

    # 切片
    end = min(len(data), args.start + args.limit)
    subset = data[args.start:end]

    pipeline = HotpotRAGPipeline()

    out_f = None
    if args.out_jsonl:
        os.makedirs(os.path.dirname(args.out_jsonl) or ".", exist_ok=True)
        out_f = open(args.out_jsonl, "w", encoding="utf-8")

    sum_f1 = 0.0
    sum_em = 0.0

    for i, ex in enumerate(subset):
        qid, q, gold = _extract_qa(ex)

        pred, dbg = pipeline.answer(q, max_new_tokens=args.max_new_tokens, debug=True)

        # token 统计：context tokens
        ctx_stats = dbg.get("ctx_token_stats") or {}
        ctx_tok_total = int(sum(int(v) for v in ctx_stats.values()))

        # prompt tokens（用 pipeline 内部 prompt 构造对齐）
        try:
            context_str = pipeline._build_context(dbg.get("selected_chunks") or [])
            prompt_str = pipeline._build_prompt(q, context_str)
            prompt_tok = int(len(pipeline.tokenizer.encode(prompt_str)))
        except Exception:
            prompt_tok = -1

        # 输出 tokens（用 clean answer 粗略计）
        try:
            out_tok = int(len(pipeline.tokenizer.encode(pred)))
        except Exception:
            out_tok = len(str(pred).split())

        f1, em = _f1_em(pred, gold)
        sum_f1 += f1
        sum_em += em

        # ===== 打印每题概要 =====
        print("=" * 100)
        print(f"[{args.start + i}] qid={qid}")
        print(f"Q: {q}")
        print(f"Gold: {gold}")
        print(f"Pred: {pred}")
        print(f"EM={em:.3f}  F1={f1:.3f}")
        print(f"Tokens: ctx_total={ctx_tok_total}  ctx_by_gran={ctx_stats}  prompt_tok={prompt_tok}  out_tok={out_tok}")

        # ===== 打印候选分配信息（如果有）=====
        if "gran_counts" in dbg and dbg["gran_counts"] is not None:
            print(f"[Candidates] gran_counts={dbg['gran_counts']}")

        # ===== 打印 selected chunks =====
        selected = dbg.get("selected_chunks") or []
        print(f"[Selected] n={len(selected)}  (chunk_preview_chars={args.chunk_preview_chars})")

        if args.print_chunks and selected:
            for j, c in enumerate(selected):
                txt = (getattr(c, "text", "") or "").strip()
                gran = getattr(c, "granularity", "")
                title = getattr(c, "title", "")
                ex_id = getattr(c, "ex_id", "")
                dense = getattr(c, "dense_score", 0.0)
                rerank = getattr(c, "rerank_score", 0.0)
                try:
                    ctok = int(pipeline._count_llm_tokens(txt))
                except Exception:
                    ctok = len(txt.split())

                print("-" * 100)
                print(f"  [{j}] gran={gran} title={title} ex_id={ex_id} tok={ctok} dense={dense} rerank={rerank}")

                if args.chunk_preview_chars == -1:
                    print(txt)
                else:
                    pv = txt[: max(0, args.chunk_preview_chars)]
                    print(pv + ("..." if len(txt) > len(pv) else ""))

        # ===== 写 jsonl（可选）=====
        if out_f is not None:
            rec = {
                "i": args.start + i,
                "qid": qid,
                "question": q,
                "gold": gold,
                "pred": pred,
                "em": em,
                "f1": f1,
                "ctx_token_stats": ctx_stats,
                "ctx_tok_total": ctx_tok_total,
                "prompt_tok": prompt_tok,
                "out_tok": out_tok,
                "gran_counts": dbg.get("gran_counts"),
                "budget_tokens": dbg.get("budget_tokens"),
                "prior_share": dbg.get("prior_share"),
                "packer_info": dbg.get("packer_info"),
                "selected_chunks": [
                    {
                        "granularity": getattr(c, "granularity", ""),
                        "title": getattr(c, "title", ""),
                        "ex_id": getattr(c, "ex_id", ""),
                        "dense_score": getattr(c, "dense_score", 0.0),
                        "rerank_score": getattr(c, "rerank_score", 0.0),
                        "tok": int(pipeline._count_llm_tokens((getattr(c, "text", "") or "").strip())),
                        "text": (getattr(c, "text", "") or "").strip(),
                    }
                    for c in (dbg.get("selected_chunks") or [])
                ],
            }
            out_f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            out_f.flush()

    n = len(subset)
    if n > 0:
        print("=" * 100)
        print(f"[DONE] split={args.split}  range=[{args.start}, {end})  n={n}")
        print(f"[AVG] EM={sum_em/n:.4f}  F1={sum_f1/n:.4f}")

    if out_f is not None:
        out_f.close()


if __name__ == "__main__":
    main()
