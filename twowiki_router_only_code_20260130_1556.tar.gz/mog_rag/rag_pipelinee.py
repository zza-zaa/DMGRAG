# mog_rag/rag_pipeline.py
from __future__ import annotations

import os
import re
from dataclasses import asdict
from typing import Any, Dict, List, Optional, Tuple

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .retrieval import MultiGranRetriever, RetrievedChunk

# 这些 import 可能在你项目里存在；即便不存在也不影响本文件核心逻辑
try:
    from .config import MAX_CONTEXT_TOKENS as _DEFAULT_CTX_BUDGET
except Exception:
    _DEFAULT_CTX_BUDGET = 2048


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, str(int(default))).strip().lower()
    return v in ("1", "true", "yes", "y", "on")


def _env_int(name: str, default: int) -> int:
    v = os.getenv(name, str(default)).strip()
    try:
        return int(v)
    except Exception:
        return default


def _clean_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def _norm_text_for_dedup(s: str) -> str:
    s = _clean_spaces(s).lower()
    # 轻量归一：去掉多余引号/奇怪空白，不做 aggressive 的标点删除，避免不同实体被误合并
    s = s.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
    return s


class HotpotRAGPipeline:
    """
    兼容你现有 evaluate_* 脚本的 Pipeline：
    - answer(question, debug=True) -> (pred, debug_dict)
    """

    def __init__(
        self,
        split: Optional[str] = None,
        llm_path: Optional[str] = None,
    ) -> None:
        self.split = split or os.getenv("SPLIT", "dev").strip()

        # ===== Switches (先停掉路由器/预算器) =====
        self.use_router = _env_bool("USE_ROUTER", False)
        # 兼容你之前可能写过的 USE_BUDGET / USE_BUDGETER
        self.use_budgeter = _env_bool("USE_BUDGETER", False) or _env_bool("USE_BUDGET", False)

        # ===== Retriever =====
        # reranker 是否用，由你环境变量控制（默认关，先把 pipeline 跑通）
        use_reranker = _env_bool("USE_RERANKER", False)
        self.retriever = MultiGranRetriever(split=self.split, use_reranker=use_reranker, router=None)

        # 你后续要启用 router/budgeter 时，再在这里挂载（现在先保持 None）
        if self.use_router:
            # 你项目里若有 router runtime，可在此加载并传给 retriever.router
            # 这里不强行猜你的 ckpt 路径，避免“为了修而修”
            raise RuntimeError(
                "USE_ROUTER=1 但当前版本按你的要求先停路由器。请先设 USE_ROUTER=0 把 pipeline 修好。"
            )
        if self.use_budgeter:
            raise RuntimeError(
                "USE_BUDGETER=1 但当前版本按你的要求先停预算器。请先设 USE_BUDGETER=0 把 pipeline 修好。"
            )

        # ===== LLM =====
        self.llm_path = llm_path or os.getenv("LLM_PATH", "").strip()
        if not self.llm_path:
            # 给一个“合理但不强绑定”的默认值：你没设就报错，避免 silently 用错模型
            raise RuntimeError(
                "请设置环境变量 LLM_PATH 指向你的本地模型目录，例如：\n"
                "export LLM_PATH=/mnt/raid/peiyu/models/Qwen2.5-14B-Instruct"
            )

        self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True)
        # Qwen Instruct 通常没有 pad_token，统一一下避免 generate 报警
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # dtype：H100 用 bf16 最稳；如果你环境不支持就让 transformers 自动
        torch_dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            self.llm_path,
            torch_dtype=torch_dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()

    # ----------------------------
    # Context packing
    # ----------------------------
    def _chunk_to_ctx_block(self, c: RetrievedChunk, idx: int) -> str:
        title = _clean_spaces(c.title)
        text = _clean_spaces(c.text)
        # 保持清晰、可读、对齐你现在日志里“gran=xxx/title=xxx”的习惯
        return f"[{idx}][{c.granularity}] title={title}\n{text}"

    def _count_tokens(self, s: str) -> int:
        # 只用于预算估计，不需要返回 tensor
        return int(len(self.tokenizer.encode(s, add_special_tokens=False)))

    def _effective_ctx_budget(self, req_budget: int, max_new_tokens: int) -> int:
        # 你日志里 eff=130544 这种就是 model_max_len - safety_margin
        model_max = int(getattr(self.tokenizer, "model_max_length", 0) or 0)
        if model_max <= 0 or model_max > 10**7:
            # tokenizer 有时给一个特别大的哑值，兜底用 config
            model_max = int(getattr(self.model.config, "max_position_embeddings", 8192) or 8192)

        safety_margin = _env_int("PROMPT_SAFETY_MARGIN", 512)
        eff = model_max - max_new_tokens - safety_margin
        eff = max(256, eff)
        return min(req_budget, eff)

    def _dedup_chunks(self, chunks: List[RetrievedChunk]) -> Tuple[List[RetrievedChunk], int]:
        seen = set()
        out = []
        removed = 0
        for c in chunks:
            key = _norm_text_for_dedup(c.text)
            if not key:
                continue
            if key in seen:
                removed += 1
                continue
            seen.add(key)
            out.append(c)
        return out, removed

    def _rank_score(self, c: RetrievedChunk) -> float:
        # reranker 开了就用 rerank_score，否则 dense_score
        if getattr(c, "rerank_score", 0.0) and float(c.rerank_score) != 0.0:
            return float(c.rerank_score)
        return float(c.dense_score)

    def _pack_context(
        self,
        candidates: List[RetrievedChunk],
        ctx_budget: int,
        max_ctx_chunks: int,
    ) -> Tuple[List[RetrievedChunk], Dict[str, int]]:
        """
        贪心 packing：按 score 从高到低，塞到 token budget。
        """
        # 排序（稳定）
        cand_sorted = sorted(candidates, key=self._rank_score, reverse=True)

        selected: List[RetrievedChunk] = []
        stats: Dict[str, int] = {}
        used = 0

        for c in cand_sorted:
            if len(selected) >= max_ctx_chunks:
                break
            block = self._chunk_to_ctx_block(c, idx=len(selected) + 1)
            t = self._count_tokens(block) + 2  # +2 给换行/分隔符一点冗余
            if used + t > ctx_budget:
                continue
            selected.append(c)
            used += t
            stats[c.granularity] = stats.get(c.granularity, 0) + t

        return selected, stats

    # ----------------------------
    # Prompt + Generation
    # ----------------------------
    def _build_messages(self, question: str, ctx_blocks: str) -> List[Dict[str, str]]:
        strict = _env_bool("STRICT_CONTEXT", False)

        system = (
            "You are a question answering assistant. "
            "Answer with a short span (entity / name / place / date)."
        )

        if strict:
            instr = (
                "Use ONLY the provided context to answer. "
                "If the answer is not present, output unknown."
            )
        else:
            instr = (
                "Use the provided context as primary evidence. "
                "If the context is insufficient, make your best guess."
            )

        user = (
            f"{instr}\n\n"
            f"Question:\n{question}\n\n"
            f"Context:\n{ctx_blocks}\n\n"
            f"Answer (only the answer string):"
        )
        return [{"role": "system", "content": system}, {"role": "user", "content": user}]

    def _generate(self, messages: List[Dict[str, str]]) -> str:
        # 规范化 generation 配置，避免你日志里的 do_sample/temperature 冲突 warning :contentReference[oaicite:10]{index=10}
        max_new_tokens = _env_int("MAX_NEW_TOKENS", 64)
        do_sample = _env_bool("DO_SAMPLE", False)
        num_beams = _env_int("NUM_BEAMS", 1)

        temperature = float(os.getenv("TEMPERATURE", "0.7"))
        top_p = float(os.getenv("TOP_P", "0.9"))
        top_k = _env_int("TOP_K", 50)

        prompt = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)

        gen_kwargs: Dict[str, Any] = dict(
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            num_beams=num_beams,
            eos_token_id=self.tokenizer.eos_token_id,
            pad_token_id=self.tokenizer.pad_token_id,
        )
        if do_sample and num_beams == 1:
            gen_kwargs.update(dict(temperature=temperature, top_p=top_p, top_k=top_k))

        with torch.inference_mode():
            out = self.model.generate(**inputs, **gen_kwargs)

        # 只取新生成部分
        new_tokens = out[0, inputs["input_ids"].shape[1] :]
        text = self.tokenizer.decode(new_tokens, skip_special_tokens=True)
        return text.strip()

    def _postprocess_answer(self, s: str) -> str:
        s = (s or "").strip()
        if not s:
            return "unknown"

        # 取第一行，去掉多余前缀
        s = s.splitlines()[0].strip()
        s = re.sub(r"^(answer\s*[:\-]\s*)", "", s, flags=re.IGNORECASE).strip()

        # 去掉首尾引号
        s = s.strip().strip('"').strip("'").strip()

        # 如果模型复读了提示，做一次轻量清理
        s = re.sub(r"^(only the answer string[:\-]?\s*)", "", s, flags=re.IGNORECASE).strip()

        # 避免输出空/单字符（你现在大量 Over/Plain/F 这种）
        if len(s) <= 1:
            return "unknown"
        return s

    # ----------------------------
    # Public API
    # ----------------------------
    def answer(self, question: str, debug: bool = False) -> Tuple[str, Dict[str, Any]]:
        question = _clean_spaces(question)

        # ==== budgets / knobs ====
        req_budget = _env_int("CTX_BUDGET", int(_DEFAULT_CTX_BUDGET))
        max_new_tokens = _env_int("MAX_NEW_TOKENS", 64)
        eff_budget = self._effective_ctx_budget(req_budget, max_new_tokens)

        total_topk = _env_int("TOTAL_TOPK", 100)
        max_ctx_chunks = _env_int("MAX_CTX_CHUNKS", 64)

        # ==== retrieve ====
        candidates = self.retriever.retrieve_multi_gran(
            question,
            budget_tokens=req_budget,
            total_topk=total_topk,
        )

        # 统计粒度分布（对齐你现有日志：gran_counts={'sent':33,...}）
        gran_counts: Dict[str, int] = {}
        for c in candidates:
            gran_counts[c.granularity] = gran_counts.get(c.granularity, 0) + 1

        # ==== dedup candidates ====
        cand_dedup, removed_cand = self._dedup_chunks(candidates)

        # ==== pack ====
        selected, ctx_token_stats = self._pack_context(
            cand_dedup,
            ctx_budget=eff_budget,
            max_ctx_chunks=max_ctx_chunks,
        )

        # selected 内再次检查重复（理论上 0；你日志也基本是 removed_sel=0 :contentReference[oaicite:11]{index=11}）
        selected_dedup, removed_sel = self._dedup_chunks(selected)

        # ==== build ctx blocks ====
        ctx_blocks = "\n\n".join(
            [self._chunk_to_ctx_block(c, idx=i + 1) for i, c in enumerate(selected_dedup)]
        )

        # ==== generate ====
        messages = self._build_messages(question, ctx_blocks)
        raw = self._generate(messages)
        pred = self._postprocess_answer(raw)

        # ==== logging ====
        if _env_bool("PRINT_CTX_STATS", False):
            total_ctx_tokens = self._count_tokens(ctx_blocks)
            print(
                f"[CTX] req={req_budget} eff={eff_budget} total_ctx_tokens={total_ctx_tokens} "
                f"removed_cand={removed_cand} removed_sel={removed_sel} ctx_token_stats={ctx_token_stats}"
            )

        if debug:
            print(f"[DEBUG][Candidates] gran_counts={gran_counts}")

        dbg: Dict[str, Any] = {}
        if debug:
            dbg = dict(
                question=question,
                pred=pred,
                raw=raw,
                req_budget=req_budget,
                eff_budget=eff_budget,
                total_topk=total_topk,
                max_ctx_chunks=max_ctx_chunks,
                removed_cand=removed_cand,
                removed_sel=removed_sel,
                gran_counts=gran_counts,
                ctx_token_stats=ctx_token_stats,
                selected_chunks=[asdict(c) for c in selected_dedup],
            )

        return pred, dbg
