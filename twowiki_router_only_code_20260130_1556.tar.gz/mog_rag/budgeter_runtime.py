# mog_rag/budgeter_runtime.py
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple
import os
import re
import inspect

import torch

from .budget_regressor import BudgetRegressor, ChunkFeature


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, None)
    if v is None:
        return bool(default)
    v = str(v).strip().lower()
    return v in ("1", "true", "yes", "y", "t", "on")


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)).strip())
    except Exception:
        return float(default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except Exception:
        return int(default)


_word_re = re.compile(r"[A-Za-z0-9]+", re.UNICODE)


def _word_set(text: str, max_words: int = 256) -> set:
    ws = set()
    for i, m in enumerate(_word_re.finditer((text or "").lower())):
        if i >= max_words:
            break
        ws.add(m.group(0))
    return ws


def _jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if inter == 0:
        return 0.0
    union = len(a | b)
    return float(inter) / float(union) if union else 0.0


def _filter_kwargs(fn: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(fn)
        params = sig.parameters
        for p in params.values():
            if p.kind == inspect.Parameter.VAR_KEYWORD:
                return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in params}
    except Exception:
        return dict(kwargs)


class BudgeterRuntime:
    """
    Runtime selector that picks a subset of candidate chunks under a token budget.

    Backward-compatible:
      - __init__(emb_dim=0, device=..., ckpt_path=..., debug=..., **kwargs)
      - set_token_counter(fn)
      - set_chunk_formatter(fn)
      - select(question, candidates, budget_tokens, tokenizer=None)
    """

    def __init__(
        self,
        emb_dim: int = 0,  # kept for compatibility; ignored
        device: str = "cpu",
        ckpt_path: Optional[str] = None,
        ckpt: Optional[str] = None,
        debug: bool = False,
        **kwargs,
    ) -> None:
        self.debug = bool(debug)
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")

        self._count_tokens: Optional[Callable[[str], int]] = None
        self._chunk_formatter: Optional[Callable[[Any], str]] = None

        path = (ckpt_path or ckpt or "").strip()
        if not path:
            path = os.getenv("BUDGETER_CKPT", os.getenv("BUDGET_CKPT", "")).strip()
        self.ckpt_path = path

        self.model: Optional[BudgetRegressor] = None
        if self.ckpt_path:
            self.model = BudgetRegressor()
            state = torch.load(self.ckpt_path, map_location="cpu")
            sd = state.get("state_dict", state) if isinstance(state, dict) else state

            cleaned = {}
            if isinstance(sd, dict):
                for k, v in sd.items():
                    nk = k
                    for pref in ("model.", "module.", "budgeter.", "scorer."):
                        if nk.startswith(pref):
                            nk = nk[len(pref):]
                    cleaned[nk] = v

            missing, unexpected = self.model.load_state_dict(cleaned, strict=False)
            self.model.to(self.device)
            self.model.eval()
            print(f"[Budgeter] loaded ckpt={self.ckpt_path} missing={len(missing)} unexpected={len(unexpected)}")
        else:
            print("[Budgeter] no ckpt provided; will use heuristic greedy selector")

    def set_token_counter(self, fn: Callable[[str], int]) -> None:
        self._count_tokens = fn

    def set_chunk_formatter(self, fn: Callable[[Any], str]) -> None:
        self._chunk_formatter = fn

    def _tok_len(self, tokenizer: Any, text: str) -> int:
        text = text or ""
        if tokenizer is not None:
            try:
                return int(len(tokenizer.encode(text, add_special_tokens=False)))
            except Exception:
                pass
        if self._count_tokens is not None:
            try:
                return int(self._count_tokens(text))
            except Exception:
                pass
        return max(1, len(text.split()))

    def _build_features(
        self, tokenizer: Any, candidates: List[Any]
    ) -> Tuple[List[ChunkFeature], List[int], List[float]]:
        feats: List[ChunkFeature] = []
        tok_lens: List[int] = []
        heur: List[float] = []

        for c in candidates:
            text = getattr(c, "text", "") or ""
            g_id = int(getattr(c, "granularity_id", 0))
            tlen = self._tok_len(tokenizer, text)

            dense = float(getattr(c, "dense_score", 0.0))
            rr = float(getattr(c, "rerank_score", 0.0))
            score = rr if abs(rr) > 1e-12 else dense

            # IMPORTANT: only pass fields that definitely exist in ChunkFeature
            feats.append(
                ChunkFeature(
                    text=text,
                    granularity_id=int(g_id),
                    length_tokens=int(tlen),
                    dense_score=float(score),
                    bm25_score=0.0,
                    diversity_score=0.0,
                )
            )
            tok_lens.append(int(tlen))
            heur.append(float(score))

        return feats, tok_lens, heur

    def select(
        self,
        question: str,
        candidates: List[Any],
        budget_tokens: int,
        tokenizer: Any = None,
    ) -> Tuple[List[Any], Dict[str, Any]]:
        # MUST always return (list, dict)
        if not candidates:
            return [], {"packer": "budgeter_v2", "used_tokens": 0, "n_selected": 0, "n_candidates": 0}

        if _env_bool("BUDGETER_OVERRIDE_BUDGET", False):
            budget_tokens = 10**9

        feats, tok_lens, heur_scores = self._build_features(tokenizer, candidates)

        # score
        if self.model is not None:
            with torch.no_grad():
                kwargs = {
                    "question": question,
                    "chunk_features": feats,
                    "budget_tokens": int(budget_tokens),
                }
                use_kwargs = _filter_kwargs(self.model.__call__, kwargs)
                try:
                    scores_t = self.model(**use_kwargs)
                except TypeError:
                    scores_t = self.model(question, feats, int(budget_tokens))

            scores = scores_t.detach().float().cpu().tolist()
        else:
            scores = heur_scores

        order = sorted(range(len(candidates)), key=lambda i: float(scores[i]), reverse=True)

        red_thr = _env_float("BUDGETER_REDUND_THR", 0.60)
        max_chunks = _env_int("MAX_CTX_CHUNKS", 200)

        used = 0
        selected: List[Any] = []
        selected_ws: List[set] = []

        for i in order:
            if len(selected) >= max_chunks:
                break
            tlen = int(tok_lens[i])
            if used + tlen > int(budget_tokens):
                continue

            if red_thr < 0.999:
                ws = _word_set(getattr(candidates[i], "text", "") or "")
                bad = False
                for prev in selected_ws:
                    if _jaccard(ws, prev) >= red_thr:
                        bad = True
                        break
                if bad:
                    continue
                selected_ws.append(ws)

            selected.append(candidates[i])
            used += tlen

        info: Dict[str, Any] = {
            "packer": "budgeter_v2",
            "used_tokens": int(used),
            "n_selected": int(len(selected)),
            "n_candidates": int(len(candidates)),
        }
        if self.debug:
            info["top_scores"] = [float(scores[i]) for i in order[:20]]
        return selected, info

