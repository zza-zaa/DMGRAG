# mog_rag/evaluate_hotpot_dump.py
"""
HotpotQA dev 评测 + 导出每个样本结果到 JSONL，用于后续训练路由器 / 预算器。

和 evaluate_hotpot.py 的主要区别：
- 多了命令行参数（--hotpot_json, --limit, --out）
- 每个样本会写一行到 out JSONL：包含 question / gold / pred / em / f1 / idx
"""

import json
import re
import string
import argparse
from pathlib import Path
from typing import Any, Dict, List, Tuple

from tqdm import tqdm

from .rag_pipeline import HotpotRAGPipeline


# ========== 文本归一化 & EM / F1 计算 ==========

def _normalize_answer(s: str) -> str:
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_score(prediction: str, ground_truth: str) -> float:
    pred_tokens = _normalize_answer(prediction).split()
    gold_tokens = _normalize_answer(ground_truth).split()

    if not pred_tokens and not gold_tokens:
        return 1.0
    if not pred_tokens or not gold_tokens:
        return 0.0

    common: Dict[str, int] = {}
    for t in pred_tokens:
        common[t] = common.get(t, 0) + 1

    num_same = 0
    for t in gold_tokens:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0

    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


def _qa_em_f1(prediction: str, ground_truth: str) -> Tuple[float, float]:
    em = float(_normalize_answer(prediction) == _normalize_answer(ground_truth))
    f1 = _f1_score(prediction, ground_truth)
    return em, f1


# ========== 读取 Hotpot dev JSON ==========

def _load_hotpot_dev(hotpot_json: str, limit: int = 50) -> List[Dict[str, str]]:
    path = Path(hotpot_json)
    if not path.exists():
        raise FileNotFoundError(f"Hotpot dev 文件不存在: {path}")

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if limit is not None:
        data = data[:limit]

    examples: List[Dict[str, str]] = []
    for ex in data:
        q = ex.get("question", "").strip()
        a = ex.get("answer", "").strip()
        examples.append({"question": q, "answer": a})

    return examples


# ========== 主评测 + 导出函数 ==========

def evaluate_and_dump(
    hotpot_json: str,
    limit: int,
    out_path: str,
) -> None:
    """
    - 初始化 HotpotRAGPipeline（当前 GRAN_MODE 下的行为）
    - 对前 limit 个样本逐条调用 pipeline.answer(question)
    - 计算 EM / F1
    - 将每个样本结果写入 out_path JSONL
    """
    out_file = Path(out_path)
    out_file.parent.mkdir(parents=True, exist_ok=True)

    pipeline = HotpotRAGPipeline()
    examples = _load_hotpot_dev(hotpot_json, limit=limit)
    n = len(examples)

    total_em = 0.0
    total_f1 = 0.0

    with out_file.open("w", encoding="utf-8") as fw:
        for idx, ex in enumerate(
            tqdm(examples, desc="Evaluating Hotpot dev", dynamic_ncols=True)
        ):
            question = ex["question"]
            gold = ex["answer"]

            pred, debug_ctx = pipeline.answer(question, debug=True)

            em, f1 = _qa_em_f1(pred, gold)
            total_em += em
            total_f1 += f1

            # 写一行 JSON
            record = {
                "idx": idx,
                "question": question,
                "gold": gold,
                "pred": pred,
                "em": em,
                "f1": f1,
            }
            fw.write(json.dumps(record, ensure_ascii=False) + "\n")

    avg_em = total_em / n if n > 0 else 0.0
    avg_f1 = total_f1 / n if n > 0 else 0.0
    print(f"[RESULT] N={n}  EM={avg_em:.3f}  F1={avg_f1:.3f}")
    print(f"[SAVE] per-example results -> {out_file}")


# ========== 命令行入口 ==========

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--hotpot_json",
        type=str,
        default="/home/peiyu/data/hotpot/hotpot_dev_distractor_v1.json",
    )
    parser.add_argument("--limit", type=int, default=1500)
    parser.add_argument("--out", type=str, required=True)
    args = parser.parse_args()

    evaluate_and_dump(
        hotpot_json=args.hotpot_json,
        limit=args.limit,
        out_path=args.out,
    )


if __name__ == "__main__":
    main()
