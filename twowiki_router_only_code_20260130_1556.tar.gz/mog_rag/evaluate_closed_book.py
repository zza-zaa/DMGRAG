# mog_rag/evaluate_closed_book.py
from __future__ import annotations

import argparse
import json
import os
import random
import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

try:
    from tqdm import tqdm
except Exception:
    tqdm = None


# -----------------------------
# Reproducibility
# -----------------------------
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    try:
        from transformers import set_seed as hf_set_seed
        hf_set_seed(seed)
    except Exception:
        pass
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# -----------------------------
# EM/F1 helpers (SQuAD-style)
# -----------------------------
def normalize_answer(s: str) -> str:
    s = s.lower()
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def f1_score(pred: str, gold: str) -> float:
    pred_toks = normalize_answer(pred).split()
    gold_toks = normalize_answer(gold).split()
    if len(pred_toks) == 0 and len(gold_toks) == 0:
        return 1.0
    if len(pred_toks) == 0 or len(gold_toks) == 0:
        return 0.0
    common = {}
    for t in pred_toks:
        common[t] = common.get(t, 0) + 1
    num_same = 0
    for t in gold_toks:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1
    if num_same == 0:
        return 0.0
    precision = num_same / len(pred_toks)
    recall = num_same / len(gold_toks)
    return 2 * precision * recall / (precision + recall)


def exact_match(pred: str, gold: str) -> float:
    return 1.0 if normalize_answer(pred) == normalize_answer(gold) else 0.0


def best_over_gold(pred: str, gold_list: List[str]) -> Tuple[float, float]:
    """Return best (EM, F1) over multiple gold aliases."""
    best_em, best_f1 = 0.0, 0.0
    for g in gold_list:
        best_em = max(best_em, exact_match(pred, g))
        best_f1 = max(best_f1, f1_score(pred, g))
    return best_em, best_f1


# -----------------------------
# Data loading
# -----------------------------
def _get_qid(ex: Dict[str, Any]) -> Optional[str]:
    for k in ["id", "qid", "question_id", "_id", "uid"]:
        v = ex.get(k, None)
        if v is not None:
            return str(v)
    return None


def _extract_question(ex: Dict[str, Any]) -> str:
    for k in ["question", "query", "q"]:
        if k in ex and isinstance(ex[k], str):
            return ex[k]
    return ""


def _extract_gold_list(ex: Dict[str, Any]) -> List[str]:
    """
    Try common fields:
      - answer: str
      - answers: list[str] / list[dict]
      - gold_answer: str
      - answer_aliases: list[str]
      - final_answer: str
    """
    # direct string fields
    for k in ["answer", "gold_answer", "final_answer"]:
        if k in ex and isinstance(ex[k], str) and ex[k].strip():
            return [ex[k].strip()]

    # list fields
    if "answer_aliases" in ex and isinstance(ex["answer_aliases"], list):
        alias = [str(x).strip() for x in ex["answer_aliases"] if str(x).strip()]
        if alias:
            return alias

    if "answers" in ex:
        ans = ex["answers"]
        if isinstance(ans, list):
            out: List[str] = []
            for a in ans:
                if isinstance(a, str) and a.strip():
                    out.append(a.strip())
                elif isinstance(a, dict):
                    # common: {"text": "..."}
                    t = a.get("text", None)
                    if isinstance(t, str) and t.strip():
                        out.append(t.strip())
            if out:
                return out

    return []


def load_jsonl(path: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    data: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
            if limit is not None and len(data) >= limit:
                break
    return data


def build_answer_index(answer_file: str, limit: Optional[int] = None) -> Tuple[Dict[str, List[str]], Dict[str, List[str]]]:
    """
    Return:
      - by_id: qid -> gold_list
      - by_question: normalized_question -> gold_list
    """
    ans = load_jsonl(answer_file, limit=None)
    by_id: Dict[str, List[str]] = {}
    by_q: Dict[str, List[str]] = {}

    for ex in ans:
        q = _extract_question(ex)
        gold = _extract_gold_list(ex)
        if not gold:
            continue
        qid = _get_qid(ex)
        if qid is not None:
            by_id[qid] = gold
        if q:
            by_q[normalize_answer(q)] = gold

    return by_id, by_q


def attach_gold(
    base: List[Dict[str, Any]],
    answer_file: Optional[str],
) -> List[Dict[str, Any]]:
    if not answer_file:
        return base

    by_id, by_q = build_answer_index(answer_file)
    out: List[Dict[str, Any]] = []

    hit = 0
    for ex in base:
        gold = _extract_gold_list(ex)
        if not gold:
            qid = _get_qid(ex)
            q = _extract_question(ex)
            if qid is not None and qid in by_id:
                gold = by_id[qid]
            elif q and normalize_answer(q) in by_q:
                gold = by_q[normalize_answer(q)]
        if gold:
            hit += 1
        ex2 = dict(ex)
        ex2["_gold_list"] = gold  # attach
        out.append(ex2)

    print(f"[GOLD] attached from answer_file: {hit}/{len(base)} have gold")
    return out


# -----------------------------
# Prompt
# -----------------------------
def build_prompt(question: str) -> str:
    # 简洁稳定：让模型只输出答案短语
    return (
        "You are a question answering system.\n"
        "Answer the question with a short phrase or entity.\n"
        "Do NOT explain.\n\n"
        f"Question: {question}\n"
        "Answer:"
    )


# -----------------------------
# Main
# -----------------------------
def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, default="dev", choices=["train", "dev", "test"])
    ap.add_argument("--limit", type=int, default=1500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--top_p", type=float, default=1.0)
    ap.add_argument("--max_new_tokens", type=int, default=64)
    ap.add_argument("--data_file", type=str, default="")
    ap.add_argument("--answer_file", type=str, default="")  # optional for full-test without answers
    ap.add_argument("--out_jsonl", type=str, default="outputs/closedbook.jsonl")
    return ap.parse_args()


def default_data_path(dataset: str, split: str, data_root: str) -> str:
    # 只给常见默认；你可以一直用 --data_file 覆盖
    if dataset == "musique":
        # default to dev-answer file (commonly has answers)
        return os.path.join(data_root, "MuSiQue", f"musique_ans_v1.0_{split}.jsonl")
    if dataset == "2wiki":
        return os.path.join(data_root, "2Wiki", f"{split}.jsonl")
    if dataset == "hotpot":
        # hotpot typically json (not jsonl); closed-book建议你用你自己预处理后的jsonl
        return os.path.join(data_root, "hotpot", f"hotpot_{split}.jsonl")
    return ""


def main() -> None:
    args = parse_args()
    set_seed(args.seed)

    dataset = (os.getenv("DATASET_NAME") or "").strip().lower()
    if not dataset:
        raise RuntimeError("Please set DATASET_NAME=musique/2wiki/hotpot in env.")

    data_root = os.getenv("DATA_ROOT", "/mnt/raid/peiyu/data")
    llm_path = os.getenv("LLM_PATH", "")
    if not llm_path:
        raise RuntimeError("Please set LLM_PATH to your local generator model path.")

    data_file = args.data_file.strip() or default_data_path(dataset, args.split, data_root)
    if not data_file or not os.path.exists(data_file):
        raise FileNotFoundError(f"data_file not found: {data_file}")

    base = load_jsonl(data_file, limit=args.limit)
    base = attach_gold(base, args.answer_file.strip() or None)

    print(f"[LOAD] dataset={dataset} split={args.split} file={data_file} N={len(base)}")

    tokenizer = AutoTokenizer.from_pretrained(llm_path, use_fast=True, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        llm_path,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True,
    )
    model.eval()

    os.makedirs(os.path.dirname(args.out_jsonl), exist_ok=True)

    total = len(base)
    has_gold = sum(1 for ex in base if ex.get("_gold_list"))
    do_eval = has_gold > 0
    if not do_eval:
        print("[WARN] No gold answers found in data_file (and answer_file not matched). "
              "EM/F1 will be skipped (reported as N/A).")

    em_sum, f1_sum, eval_cnt = 0.0, 0.0, 0

    iterator = tqdm(range(total)) if tqdm is not None else range(total)

    with open(args.out_jsonl, "w", encoding="utf-8") as wf:
        for i in iterator:
            ex = base[i]
            q = _extract_question(ex)
            qid = _get_qid(ex) or str(i)
            prompt = build_prompt(q)

            inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
            with torch.no_grad():
                out = model.generate(
                    **inputs,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=(args.temperature > 1e-8),
                    temperature=args.temperature if args.temperature > 1e-8 else None,
                    top_p=args.top_p,
                )
            gen = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip()

            gold_list: List[str] = ex.get("_gold_list") or []
            em, f1 = None, None
            if do_eval and gold_list:
                bem, bf1 = best_over_gold(gen, gold_list)
                em_sum += bem
                f1_sum += bf1
                eval_cnt += 1
                em, f1 = float(bem), float(bf1)

            rec = {
                "qid": qid,
                "question": q,
                "pred": gen,
                "gold": gold_list[0] if gold_list else None,
                "gold_list": gold_list if gold_list else None,
                "em": em,
                "f1": f1,
            }
            wf.write(json.dumps(rec, ensure_ascii=False) + "\n")

            if tqdm is None and (i + 1) % 50 == 0:
                if do_eval and eval_cnt > 0:
                    print(f"[PROGRESS] {i+1}/{total}  EM={em_sum/eval_cnt:.4f}  F1={f1_sum/eval_cnt:.4f}")
                else:
                    print(f"[PROGRESS] {i+1}/{total}")

    if do_eval and eval_cnt > 0:
        EM = em_sum / eval_cnt
        F1 = f1_sum / eval_cnt
        print("\n== Closed-book QA Result ==")
        print(f"dataset={dataset} split={args.split} N={total} eval_N={eval_cnt}")
        print(f"EM={EM:.6f}  F1={F1:.6f}")
    else:
        print("\n== Closed-book QA Result ==")
        print(f"dataset={dataset} split={args.split} N={total}")
        print("EM=N/A  F1=N/A  (no gold answers)")

    print(f"[SAVED] {args.out_jsonl}")


if __name__ == "__main__":
    main()
