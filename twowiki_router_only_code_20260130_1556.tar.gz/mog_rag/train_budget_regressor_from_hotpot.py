# mog_rag/train_budget_regressor_from_hotpot.py
from __future__ import annotations
import json
import random
from pathlib import Path
from typing import List, Tuple

import torch
import torch.nn as nn

from .config import HOTPOT_DEV, MAX_CONTEXT_TOKENS
from .retrieval import MultiGranRetriever, RetrievedChunk
from .budget_regressor import BudgetRegressor, ChunkFeature

# ---------- 跟 evaluate_hotpot 一致的归一化 & F1 ----------

import re
import string


def _normalize_answer(s: str) -> str:
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


# ---------- 从 Hotpot dev 读 (q, a) ----------


def load_hotpot_qa(path: Path, max_n: int | None = None):
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if max_n is not None:
        data = data[:max_n]

    qa_list = []
    for ex in data:
        q = ex.get("question", "").strip()
        a = ex.get("answer", "").strip()
        if not q or not a:
            continue
        qa_list.append((q, a))
    print(f"[LOAD] Hotpot dev for budget training: {len(qa_list)} examples")
    return qa_list


# ---------- 根据“是否包含答案”给 chunk 打标签 ----------


def label_chunks_by_answer(
    chunks: List[RetrievedChunk],
    answer: str,
) -> List[int]:
    """
    简单策略：规范化后，answer 是否为 chunk 文本的子串。
    """
    labels: List[int] = []
    ans_norm = _normalize_answer(answer)
    if not ans_norm:
        return [0] * len(chunks)

    for c in chunks:
        text_norm = _normalize_answer(c.text)
        if ans_norm in text_norm:
            labels.append(1)
        else:
            labels.append(0)
    return labels


# ---------- 构造训练样本 ----------


def build_budget_training_data(
    qa_list: List[Tuple[str, str]],
    total_topk: int = 60,
    max_samples: int | None = None,
) -> List[Tuple[str, List[RetrievedChunk], List[int]]]:
    """
    返回:
      samples = [
        (question, [chunks...], [labels...]),
        ...
      ]
    """
    # 为了简单，训练预算器时 router 不参与粒度分配
    retriever = MultiGranRetriever(
        split="dev",
        use_reranker=True,
        router=None,
    )

    samples: List[Tuple[str, List[RetrievedChunk], List[int]]] = []

    for idx, (q, a) in enumerate(qa_list):
        # yes/no 问题对“是否包含答案”不适合做监督，先跳过
        if a.lower() in ("yes", "no"):
            continue

        # 检索候选块
        cands = retriever.retrieve_multi_gran(
            query=q,
            budget_tokens=MAX_CONTEXT_TOKENS,
            total_topk=total_topk,
        )
        if not cands:
            continue

        labels = label_chunks_by_answer(cands, a)
        pos_indices = [i for i, y in enumerate(labels) if y == 1]
        if not pos_indices:
            # 没有任何块包含答案，跳过
            continue

        # 可选：负样本下采样，避免 1:59 过于极端
        neg_indices = [i for i, y in enumerate(labels) if y == 0]
        random.shuffle(neg_indices)
        max_neg = min(len(neg_indices), len(pos_indices) * 5)
        keep = set(pos_indices + neg_indices[:max_neg])

        filtered_chunks = [c for i, c in enumerate(cands) if i in keep]
        filtered_labels = [labels[i] for i in range(len(labels)) if i in keep]

        samples.append((q, filtered_chunks, filtered_labels))

        if max_samples is not None and len(samples) >= max_samples:
            break

        if (idx + 1) % 200 == 0:
            print(f"[DATA] processed {idx+1} questions, collected {len(samples)} samples")

    print(f"[DATA] final budget training samples: {len(samples)}")
    # 粗略看一下正负比例
    total_pos = sum(sum(lbls) for _, _, lbls in samples)
    total_neg = sum(len(lbls) - sum(lbls) for _, _, lbls in samples)
    print(f"[DATA] pos={total_pos} neg={total_neg} (ratio pos:neg = {total_pos}:{total_neg})")
    return samples


# ---------- 把 RetrievedChunk 转为 ChunkFeature ----------


def build_chunk_features(chunks: List[RetrievedChunk]) -> List[ChunkFeature]:
    feats: List[ChunkFeature] = []
    for c in chunks:
        length_tokens = len(c.text.split())
        feat = ChunkFeature(
            text=c.text,
            granularity_id=c.granularity_id,
            length_tokens=length_tokens,
            bm25_score=0.0,        # 目前没有用 BM25
            dense_score=c.dense_score,
            diversity_score=0.0,   # 先不算多样性
        )
        feats.append(feat)
    return feats


# ---------- 训练预算回归器 ----------


def train_budget_regressor(
    samples: List[Tuple[str, List[RetrievedChunk], List[int]]],
    budget_tokens: int = 1024,
    num_epochs: int = 3,
    lr: float = 1e-3,
    out_path: Path = Path("budget_regressor_mlp.pt"),
):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = BudgetRegressor().to(device)

    # 只训练 MLP，SentenceTransformer encoder 固定
    optimizer = torch.optim.Adam(model.mlp.parameters(), lr=lr)
    criterion = nn.BCEWithLogitsLoss()

    n = len(samples)
    indices = list(range(n))

    for epoch in range(1, num_epochs + 1):
        random.shuffle(indices)
        total_loss = 0.0
        total_pos = 0
        total_neg = 0

        for idx in indices:
            q, chunks, labels = samples[idx]
            y = torch.tensor(labels, dtype=torch.float32, device=device)

            feat_list = build_chunk_features(chunks)

            # forward：得到每个 chunk 的 score（logit）
            scores = model(
                query=q,
                chunks=feat_list,
                budget_tokens=budget_tokens,
            )  # [N]
            scores = scores.to(device)

            loss = criterion(scores, y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(labels)
            total_pos += sum(labels)
            total_neg += len(labels) - sum(labels)

        avg_loss = total_loss / (total_pos + total_neg)
        print(
            f"[TRAIN][budget] epoch={epoch} "
            f"avg_loss={avg_loss:.4f} pos={total_pos} neg={total_neg}"
        )

    torch.save(model.mlp.state_dict(), out_path)
    print(f"[SAVE] budget regressor MLP -> {out_path}")


if __name__ == "__main__":
    # 1) 从 Hotpot dev 构造 (q, a)
    qa_list = load_hotpot_qa(Path(HOTPOT_DEV), max_n=1500)

    # 2) 构造预算器训练样本（默认每条最多 60 候选）
    samples = build_budget_training_data(
        qa_list=qa_list,
        total_topk=60,
        max_samples=None,   # 如果显存吃紧可以设成 500 或 1000 先试
    )

    # 3) 训练预算回归器
    train_budget_regressor(
        samples=samples,
        budget_tokens=MAX_CONTEXT_TOKENS,
        num_epochs=3,
        lr=1e-3,
        out_path=Path("budget_regressor_mlp.pt"),
    )
