from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from transformers import AutoTokenizer

from .budget_regressor import BudgetRegressor, ChunkFeature
from .retrieval import MultiGranRetriever, RetrievedChunk
from .budgeter_runtime import BudgeterRuntime
from .policies import get_policies_from_env
from .config import LLM_MODEL_PATH


def _robust_load_tokenizer(model_path: str):
    try:
        return AutoTokenizer.from_pretrained(model_path, trust_remote_code=True, use_fast=False)
    except Exception:
        try:
            return AutoTokenizer.from_pretrained(model_path, trust_remote_code=True, use_fast=True)
        except Exception:
            return None


def _rank_score(c: RetrievedChunk) -> float:
    try:
        r = float(getattr(c, "rerank_score", 0.0) or 0.0)
        if r != 0.0:
            return r
    except Exception:
        pass
    try:
        return float(getattr(c, "dense_score", 0.0) or 0.0)
    except Exception:
        return 0.0


def _selected_set_from_record(r: Dict[str, Any]) -> set:
    sel = r.get("selected_ids", r.get("selected", None))
    if not isinstance(sel, list):
        return set()
    out = set()
    for x in sel:
        if not isinstance(x, dict):
            continue
        g = str(x.get("granularity", ""))
        try:
            cid = int(x.get("chunk_id", -1))
        except Exception:
            cid = -1
        if g and cid >= 0:
            out.add((g, cid))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--oracle", type=str, required=True)
    ap.add_argument("--out", type=str, default="budget_regressor_v2.pt")
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--accum", type=int, default=8)
    ap.add_argument("--max_examples", type=int, default=0)
    ap.add_argument("--retrieval_split", type=str, default="train", choices=["train", "dev", "test"])
    ap.add_argument("--stage1_topk", type=int, default=120)
    ap.add_argument("--rerank_top_m", type=int, default=160)
    ap.add_argument("--total_topk", type=int, default=120)
    ap.add_argument("--use_reranker", action="store_true")
    ap.add_argument("--max_ctx_chunks", type=int, default=64)
    args = ap.parse_args()

    oracle_path = Path(args.oracle)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    pols = get_policies_from_env()

    tok = _robust_load_tokenizer(str(LLM_MODEL_PATH))

    def count_tokens(t: str) -> int:
        if not t:
            return 0
        if tok is None:
            return len(t.split())
        try:
            return len(tok.encode(t, add_special_tokens=False))
        except Exception:
            return len(t.split())

    retriever = MultiGranRetriever(split=args.retrieval_split, use_reranker=bool(args.use_reranker), router=None)

    # teacher selector (heuristic) to rebuild labels if oracle doesn't contain selected_ids
    teacher_budgeter = BudgeterRuntime(emb_dim=0, device=str(device), ckpt_path=None, debug=False)
    teacher_budgeter.set_token_counter(count_tokens)

    model = BudgetRegressor().to(device)
    model.train()

    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=0.01)

    # load oracle
    rows: List[Dict[str, Any]] = []
    with oracle_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            if "teacher" in r and isinstance(r["teacher"], dict):
                # legacy wrapper
                t = r["teacher"]
                r = {
                    "question": r.get("question", ""),
                    "budget_tokens": int(t.get("budget_tokens", r.get("budget_tokens", 2048))),
                    "best_policy_id": int(t.get("best_policy_id", r.get("best_policy_id", 0))),
                    "selected_ids": t.get("selected_ids", r.get("selected_ids", None)),
                }
            else:
                r = {
                    "question": r.get("question", ""),
                    "budget_tokens": int(r.get("budget_tokens", r.get("best_budget", 2048))),
                    "best_policy_id": int(r.get("best_policy_id", 0)),
                    "selected_ids": r.get("selected_ids", r.get("selected", None)),
                }
            if r["question"]:
                rows.append(r)
            if args.max_examples and len(rows) >= int(args.max_examples):
                break

    print(f"[DATA] oracle rows={len(rows)}")

    for ep in range(1, int(args.epochs) + 1):
        np.random.shuffle(rows)
        total_loss = 0.0
        n_examples = 0

        opt.zero_grad(set_to_none=True)

        for i, r in enumerate(rows, start=1):
            q = str(r.get("question", ""))
            if not q:
                continue
            pid = int(r.get("best_policy_id", 0))
            pid = max(0, min(pid, len(pols) - 1))
            budget = int(r.get("budget_tokens", 2048))
            share = dict(pols[pid].share)

            cands, _alloc = retriever.retrieve_stagewise(
                query=q,
                budget_tokens=budget,
                stage1_total_topk=int(args.stage1_topk),
                rerank_top_m=int(args.rerank_top_m),
                prior_share=share,
            )
            if not cands:
                continue

            # optionally cap pool
            if len(cands) > int(args.total_topk):
                cands = cands[: int(args.total_topk)]

            sel_set = _selected_set_from_record(r)
            if not sel_set:
                selected, _info = teacher_budgeter.select(
                    question=q,
                    candidates=cands,
                    budget_tokens=budget,
                    max_ctx_chunks=int(args.max_ctx_chunks),
                )
                sel_set = {(c.granularity, int(c.chunk_id)) for c in selected}

            # build features + labels
            feats: List[ChunkFeature] = []
            y: List[float] = []
            for c in cands:
                feats.append(
                    ChunkFeature(
                        text=c.text or "",
                        granularity_id=int(getattr(c, "granularity_id", 0)),
                        length_tokens=max(1, count_tokens(c.text or "")),
                        dense_score=float(_rank_score(c)),
                    )
                )
                y.append(1.0 if (c.granularity, int(c.chunk_id)) in sel_set else 0.0)

            if sum(y) <= 0:
                continue

            logits = model(query=q, chunks=feats, budget_tokens=budget)
            y_t = torch.tensor(y, dtype=torch.float32, device=device)

            # imbalance-aware BCE
            pos = float(y_t.sum().item())
            neg = float(y_t.numel() - pos)
            pos_weight = torch.tensor([max(1.0, neg / max(1.0, pos))], device=device)

            loss = F.binary_cross_entropy_with_logits(logits, y_t, pos_weight=pos_weight)
            (loss / float(args.accum)).backward()

            total_loss += float(loss.item())
            n_examples += 1

            if i % int(args.accum) == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
                opt.zero_grad(set_to_none=True)

            if i % 50 == 0:
                print(f"[ep={ep}] i={i} loss(avg)={total_loss/max(1,n_examples):.4f} n={n_examples}")

        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        opt.zero_grad(set_to_none=True)

        print(f"[EPOCH {ep}] loss(avg)={total_loss/max(1,n_examples):.4f} n={n_examples}")

    torch.save({"state_dict": model.state_dict()}, out_path)
    print(f"[OK] saved budget scorer ckpt to {out_path}")


if __name__ == "__main__":
    main()
