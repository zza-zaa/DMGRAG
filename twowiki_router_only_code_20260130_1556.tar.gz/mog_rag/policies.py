from __future__ import annotations

"""Discrete policy set for budget allocation across granularities.

A *policy* is a distribution over GRANULARITIES (sent/para/doc).
The router predicts a distribution over a finite policy set, then converts it
into a soft share over granularities by expectation.

You can override the policy set at runtime via env:
  ROUTER_POLICIES='name1=sent:0.2,para:0.6,doc:0.2;name2=sent:1,para:0,doc:0'
"""

from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

import os

import torch

from .config import GRANULARITIES


@dataclass(frozen=True)
class Policy:
    name: str
    share: Dict[str, float]  # keys are in GRANULARITIES


def normalize_share(share: Dict[str, float], gran_order: Sequence[str] = GRANULARITIES) -> Dict[str, float]:
    out = {g: float(share.get(g, 0.0)) for g in gran_order}
    out = {g: (v if v > 0.0 else 0.0) for g, v in out.items()}
    s = float(sum(out.values()))
    if s <= 1e-12:
        return {g: 1.0 / float(len(gran_order)) for g in gran_order}
    return {g: out[g] / s for g in gran_order}


def parse_share_str(s: str, gran_order: Sequence[str] = GRANULARITIES) -> Dict[str, float]:
    """Parse 'sent:0.2,para:0.6,doc:0.2' -> normalized share."""
    share = {g: 0.0 for g in gran_order}
    for part in (s or "").split(","):
        part = part.strip()
        if not part or ":" not in part:
            continue
        k, v = part.split(":", 1)
        k = k.strip()
        try:
            share[k] = float(v.strip())
        except Exception:
            pass
    return normalize_share(share, gran_order)


def get_default_policies(gran_order: Sequence[str] = GRANULARITIES) -> List[Policy]:
    """Compact policy set (good coverage, not too many classes)."""

    def P(name: str, sent: float, para: float, doc: float) -> Policy:
        return Policy(name=name, share=normalize_share({"sent": sent, "para": para, "doc": doc}, gran_order))

    pols: List[Policy] = []

    # Pure
    pols += [P("sent_only", 1, 0, 0), P("para_only", 0, 1, 0), P("doc_only", 0, 0, 1)]

    # Two-way mixes
    pols += [
        P("sent_para_70_30", 0.7, 0.3, 0.0),
        P("sent_para_50_50", 0.5, 0.5, 0.0),
        P("sent_para_30_70", 0.3, 0.7, 0.0),
        P("para_doc_70_30", 0.0, 0.7, 0.3),
        P("para_doc_50_50", 0.0, 0.5, 0.5),
        P("para_doc_30_70", 0.0, 0.3, 0.7),
        P("sent_doc_70_30", 0.7, 0.0, 0.3),
        P("sent_doc_50_50", 0.5, 0.0, 0.5),
        P("sent_doc_30_70", 0.3, 0.0, 0.7),
    ]

    # Three-way mixes
    pols += [
        P("uniform", 1 / 3, 1 / 3, 1 / 3),
        P("para_heavy", 0.20, 0.60, 0.20),
        P("para_strong", 0.10, 0.80, 0.10),
        P("doc_heavy", 0.15, 0.25, 0.60),
        P("doc_strong", 0.10, 0.20, 0.70),
        P("sent_heavy", 0.60, 0.25, 0.15),
        P("sent_strong", 0.70, 0.20, 0.10),
        P("sent_para_bias", 0.45, 0.45, 0.10),
        P("para_doc_bias", 0.10, 0.55, 0.35),
        P("sent_doc_bias", 0.45, 0.10, 0.45),
    ]

    # Deduplicate by share
    uniq: List[Policy] = []
    seen = set()
    for p in pols:
        key = tuple(round(p.share[g], 4) for g in gran_order)
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    return uniq


def get_policies_from_env(gran_order: Sequence[str] = GRANULARITIES) -> List[Policy]:
    """If ROUTER_POLICIES is set, use it; else return defaults."""
    raw = os.getenv("ROUTER_POLICIES", "").strip()
    if not raw:
        return get_default_policies(gran_order)

    pols: List[Policy] = []
    for item in raw.split(";"):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            continue
        name, share_s = item.split("=", 1)
        name = name.strip()
        share = parse_share_str(share_s.strip(), gran_order)
        pols.append(Policy(name=name, share=share))

    return pols if pols else get_default_policies(gran_order)


def policy_share_matrix(policies: Sequence[Policy], gran_order: Sequence[str] = GRANULARITIES) -> torch.Tensor:
    """Tensor [P, G] where rows are policy shares aligned with gran_order."""
    mat = []
    for p in policies:
        s = normalize_share(p.share, gran_order)
        mat.append([float(s[g]) for g in gran_order])
    return torch.tensor(mat, dtype=torch.float32)


def policy_name_to_id(policies: Sequence[Policy], name: str) -> int:
    for i, p in enumerate(policies):
        if p.name == name:
            return i
    return 0


def nearest_policy_id_from_share(policies: Sequence[Policy], share: Dict[str, float], gran_order: Sequence[str] = GRANULARITIES) -> int:
    s = normalize_share(share, gran_order)
    tgt = torch.tensor([s[g] for g in gran_order], dtype=torch.float32)
    mat = policy_share_matrix(policies, gran_order)
    # L1 distance
    dist = torch.sum(torch.abs(mat - tgt.unsqueeze(0)), dim=1)
    return int(torch.argmin(dist).item())
