# mog_rag/retrieval.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any
import json
import os
import inspect

import numpy as np
import torch
import faiss
from sentence_transformers import SentenceTransformer, CrossEncoder

from .config import (
    INDEX_DIR,
    EMB_MODEL_PATH,
    RERANKER_MODEL_PATH,
    GRANULARITIES,
    MAX_CONTEXT_TOKENS,
    TOTAL_TOPK,
)

FAISS_HAS_GPU = hasattr(faiss, "StandardGpuResources")


@dataclass
class RetrievedChunk:
    chunk_id: int
    text: str
    granularity: str
    granularity_id: int
    ex_id: int
    title: str
    dense_score: float
    rerank_score: float = 0.0


def _filter_kwargs(fn: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(fn)
        params = sig.parameters
        for p in params.values():
            if p.kind == inspect.Parameter.VAR_KEYWORD:
                return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in params}
    except Exception:
        return dict(kwargs)


def _router_device(router: Any) -> torch.device:
    # prefer any parameter device
    try:
        for p in router.parameters():
            return p.device
    except Exception:
        pass
    # fallback
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _extract_probs(out: Any) -> np.ndarray:
    """
    Support out.probs / dict['probs'] / tensor / out.logits
    Return shape [G]
    """
    probs_t: Optional[torch.Tensor] = None

    if isinstance(out, torch.Tensor):
        probs_t = out
    elif isinstance(out, dict):
        if "probs" in out and isinstance(out["probs"], torch.Tensor):
            probs_t = out["probs"]
        elif "logits" in out and isinstance(out["logits"], torch.Tensor):
            probs_t = torch.softmax(out["logits"], dim=-1)
    else:
        if hasattr(out, "probs") and isinstance(getattr(out, "probs"), torch.Tensor):
            probs_t = getattr(out, "probs")
        elif hasattr(out, "logits") and isinstance(getattr(out, "logits"), torch.Tensor):
            probs_t = torch.softmax(getattr(out, "logits"), dim=-1)

    if probs_t is None:
        raise RuntimeError("Router output has no probs/logits tensor; cannot allocate topk")

    probs = probs_t.detach().float().cpu().numpy()
    if getattr(probs, "ndim", 0) == 2:
        probs = probs[0]
    probs = probs.reshape(-1)
    return probs


class MultiGranRetriever:
    def __init__(
        self,
        split: str = "dev",
        use_reranker: bool = True,
        router: Optional[object] = None,
    ):
        self.split = split
        self.use_reranker = use_reranker
        self.router = router

        # GRAN_MODE=sent-only / para-only / doc-only / default(all)
        gran_mode = os.getenv("GRAN_MODE", "").strip().lower()
        if gran_mode == "sent-only":
            self.active_grans = ["sent"]
        elif gran_mode == "para-only":
            self.active_grans = ["para"]
        elif gran_mode == "doc-only":
            self.active_grans = ["doc"]
        else:
            self.active_grans = list(GRANULARITIES)

        print(f"[Retrieval] active_granularities={self.active_grans}")

        # FAISS GPU resource
        if torch.cuda.is_available() and FAISS_HAS_GPU:
            self.gpu_id = int(os.getenv("FAISS_GPU_ID", "0"))
            self.gpu_res = faiss.StandardGpuResources()
            print(f"[FAISS] {split}: index on GPU{self.gpu_id}")
        else:
            self.gpu_id = -1
            self.gpu_res = None
            print(f"[FAISS] {split}: index on CPU")

        self.indices: Dict[str, faiss.Index] = {}
        self.metas: Dict[str, List[Dict]] = {}
        self._load_indices()

        emb_device = "cuda" if torch.cuda.is_available() else "cpu"
        self.emb_model = SentenceTransformer(str(EMB_MODEL_PATH), device=emb_device)

        if self.use_reranker:
            rr_device = "cuda" if torch.cuda.is_available() else "cpu"
            self.reranker = CrossEncoder(str(RERANKER_MODEL_PATH), device=rr_device)
        else:
            self.reranker = None

        self.gran2id = {g: i for i, g in enumerate(GRANULARITIES)}
        self.last_alloc: Dict[str, int] = {}

    def _load_indices(self) -> None:
        for gran in self.active_grans:
            out_dir = INDEX_DIR / self.split / gran
            index_path = out_dir / "index.faiss"
            meta_path = out_dir / "meta.jsonl"
            if not index_path.exists():
                print(f"[WARN] index not found for {self.split}-{gran}, skip.")
                continue

            index_cpu = faiss.read_index(str(index_path))
            if self.gpu_res is not None and self.gpu_id >= 0:
                index = faiss.index_cpu_to_gpu(self.gpu_res, self.gpu_id, index_cpu)
                print(f"[LOAD][GPU] {self.split}-{gran}")
            else:
                index = index_cpu
                print(f"[LOAD][CPU] {self.split}-{gran}")

            metas: List[Dict] = []
            with meta_path.open("r", encoding="utf-8") as f:
                for line in f:
                    metas.append(json.loads(line))

            self.indices[gran] = index
            self.metas[gran] = metas
            print(f"[LOAD] {self.split}-{gran}: {len(metas)} chunks")

    def _encode_query(self, q: str) -> np.ndarray:
        emb = self.emb_model.encode([q], normalize_embeddings=True)
        return np.asarray(emb, dtype="float32")  # [1,d]

    def _call_router(self, q_emb_t: torch.Tensor, query: str, budget_tokens: int) -> np.ndarray:
        """
        Call router with best-effort kwargs filtering.
        """
        kwargs = {
            "budget_tokens": int(budget_tokens),
            "q_len_chars": int(len(query)),
            "budget_norm": float(MAX_CONTEXT_TOKENS),
        }
        fn = self.router  # __call__
        use_kwargs = _filter_kwargs(fn, kwargs)
        try:
            out = fn(q_emb_t, **use_kwargs)
        except TypeError:
            # maybe router doesn't accept extra args
            out = fn(q_emb_t)
        return _extract_probs(out)

    def _allocate_topk(
        self,
        query: str,
        q_emb: np.ndarray,
        budget_tokens: int,
        total_topk: int,
        prior_share: Optional[Dict[str, float]] = None,
    ) -> Dict[str, int]:
        available = [g for g in self.active_grans if g in self.indices]
        if not available:
            return {}
        if len(available) == 1:
            return {available[0]: int(total_topk)}

        # ---- no router ----
        if self.router is None:
            # uniform or prior_share
            if prior_share:
                pairs = [(g, float(prior_share.get(g, 0.0))) for g in available]
                s = sum(p for _, p in pairs)
                if s <= 0:
                    pairs = [(g, 1.0 / len(available)) for g in available]
                else:
                    pairs = [(g, p / s) for g, p in pairs]
            else:
                pairs = [(g, 1.0 / len(available)) for g in available]

            alloc: Dict[str, int] = {}
            left = int(total_topk)
            for i, (g, p) in enumerate(pairs):
                k = left if i == len(pairs) - 1 else int(round(total_topk * p))
                k = max(1, k)
                alloc[g] = k
                left -= k

            cur = sum(alloc.values())
            if cur != int(total_topk):
                diff = int(total_topk - cur)
                alloc[available[0]] = max(1, alloc[available[0]] + diff)
            return alloc

        # ---- router exists ----
        dev = _router_device(self.router)
        q_emb_t = torch.from_numpy(q_emb).to(dev)

        probs = self._call_router(q_emb_t=q_emb_t, query=query, budget_tokens=int(budget_tokens))

        pairs = []
        for g in available:
            idx = self.gran2id.get(g, 0)
            p = float(probs[idx]) if idx < len(probs) else 0.0
            pairs.append((g, p))

        alpha = float(os.getenv("PRIOR_MIX_ALPHA", "0.0"))
        if prior_share and alpha > 0:
            pairs = [(g, (1 - alpha) * p + alpha * float(prior_share.get(g, 0.0))) for g, p in pairs]

        s = sum(p for _, p in pairs)
        if s <= 0:
            pairs = [(g, 1.0 / len(pairs)) for g, _ in pairs]
        else:
            pairs = [(g, p / s) for g, p in pairs]

        # base quota to avoid starving
        base_default = {"doc": 6, "para": 10, "sent": 10}
        alloc: Dict[str, int] = {}
        base_sum = 0
        for g in available:
            k = int(base_default.get(g, 0))
            if k > 0:
                alloc[g] = k
                base_sum += k

        if base_sum >= int(total_topk):
            G = len(available)
            base = max(1, int(total_topk) // G)
            rem = int(total_topk) - base * G
            return {g: base + (1 if i < rem else 0) for i, g in enumerate(available)}

        remain = int(total_topk) - base_sum
        left = remain
        for i, (g, p) in enumerate(pairs):
            k = left if i == len(pairs) - 1 else max(0, int(round(remain * p)))
            alloc[g] = alloc.get(g, 0) + k
            left -= k

        # cap sent
        sent_cap = int(int(total_topk) * 0.45)
        if "sent" in alloc and alloc["sent"] > sent_cap:
            overflow = alloc["sent"] - sent_cap
            alloc["sent"] = sent_cap
            targets = [g for g in available if g != "sent"]
            if targets and overflow > 0:
                per = overflow // len(targets)
                rem2 = overflow % len(targets)
                for i, tg in enumerate(targets):
                    alloc[tg] = alloc.get(tg, 0) + per + (1 if i < rem2 else 0)

        # fix sum
        cur = sum(max(0, v) for v in alloc.values())
        if cur != int(total_topk):
            diff = int(total_topk - cur)
            for pref in ("doc", "para", "sent"):
                if pref in alloc:
                    alloc[pref] = max(1, alloc[pref] + diff)
                    break

        return {g: int(v) for g, v in alloc.items() if v > 0}

    def retrieve_multi_gran(
        self,
        query: str,
        budget_tokens: int = MAX_CONTEXT_TOKENS,
        total_topk: int = TOTAL_TOPK,
        prior_share: Optional[Dict[str, float]] = None,
    ) -> List[RetrievedChunk]:
        if not self.indices:
            return []

        q_emb = self._encode_query(query)

        available = [g for g in self.active_grans if g in self.indices and g in self.metas]
        if not available:
            return []
        if len(available) == 1:
            g = available[0]
            metas = self.metas[g]
            k_eff = min(int(total_topk), len(metas))
            scores, idxs = self.indices[g].search(q_emb, k_eff)
            out: List[RetrievedChunk] = []
            for score, idx in zip(scores[0], idxs[0]):
                if idx < 0:
                    continue
                meta = metas[int(idx)]
                out.append(
                    RetrievedChunk(
                        chunk_id=int(idx),
                        text=meta.get("text", ""),
                        granularity=g,
                        granularity_id=self.gran2id.get(g, 0),
                        ex_id=int(meta.get("ex_id", -1)),
                        title=meta.get("title", ""),
                        dense_score=float(score),
                    )
                )
            out.sort(key=lambda x: x.dense_score, reverse=True)
            return out[: int(total_topk)]

        # global pool when no router/prior_share
        no_router_global = (
            self.router is None
            and prior_share is None
            and os.getenv("NO_ROUTER_GLOBAL_RETRIEVE", "1") == "1"
        )
        if no_router_global:
            pool_per_gran = int(os.getenv("NO_ROUTER_POOL_PER_GRAN", str(int(total_topk))))
            alloc = {g: min(pool_per_gran, len(self.metas[g])) for g in available}
        else:
            alloc = self._allocate_topk(query, q_emb, budget_tokens, total_topk, prior_share=prior_share)

        self.last_alloc = dict(alloc)

        all_chunks: List[RetrievedChunk] = []
        for gran, k in alloc.items():
            if gran not in self.indices or int(k) <= 0:
                continue
            metas = self.metas.get(gran, [])
            if not metas:
                continue
            k_eff = min(int(k), len(metas))
            scores, idxs = self.indices[gran].search(q_emb, k_eff)
            for score, idx in zip(scores[0], idxs[0]):
                if idx < 0:
                    continue
                meta = metas[int(idx)]
                all_chunks.append(
                    RetrievedChunk(
                        chunk_id=int(idx),
                        text=meta.get("text", ""),
                        granularity=gran,
                        granularity_id=self.gran2id.get(gran, 0),
                        ex_id=int(meta.get("ex_id", -1)),
                        title=meta.get("title", ""),
                        dense_score=float(score),
                    )
                )

        if not all_chunks:
            return []

        if self.use_reranker and self.reranker is not None:
            all_chunks.sort(key=lambda x: x.dense_score, reverse=True)
            rerank_m = int(os.getenv("RERANK_TOP_M", "160"))
            rerank_m = max(1, min(rerank_m, len(all_chunks)))

            head = all_chunks[:rerank_m]
            pairs = [(query, c.text) for c in head]
            with torch.no_grad():
                rr = self.reranker.predict(pairs)
            for c, s in zip(head, rr):
                c.rerank_score = float(s)

            all_chunks.sort(
                key=lambda x: (x.rerank_score if abs(x.rerank_score) > 1e-12 else x.dense_score),
                reverse=True,
            )
        else:
            all_chunks.sort(key=lambda x: x.dense_score, reverse=True)

        return all_chunks[: int(total_topk)]

    def retrieve_stagewise(
        self,
        query: str,
        budget_tokens: int,
        stage1_total_topk: int,
        rerank_top_m: int,
        prior_share: Optional[Dict[str, float]] = None,
    ) -> Tuple[List[RetrievedChunk], Dict[str, int]]:
        """
        MUST return (pool_chunks, alloc_dict) in all branches.
        """
        if not self.indices:
            return [], {}

        q_emb = self._encode_query(query)
        alloc = self._allocate_topk(query, q_emb, budget_tokens, stage1_total_topk, prior_share=prior_share)
        self.last_alloc = dict(alloc)

        pool: List[RetrievedChunk] = []
        for gran, k in alloc.items():
            if gran not in self.indices or int(k) <= 0:
                continue
            metas = self.metas.get(gran, [])
            if not metas:
                continue
            k_eff = min(int(k), len(metas))
            scores, idxs = self.indices[gran].search(q_emb, k_eff)
            for score, idx in zip(scores[0], idxs[0]):
                if idx < 0:
                    continue
                meta = metas[int(idx)]
                pool.append(
                    RetrievedChunk(
                        chunk_id=int(idx),
                        text=meta.get("text", ""),
                        granularity=gran,
                        granularity_id=self.gran2id.get(gran, 0),
                        ex_id=int(meta.get("ex_id", -1)),
                        title=meta.get("title", ""),
                        dense_score=float(score),
                    )
                )

        if not pool:
            return [], alloc

        pool.sort(key=lambda x: x.dense_score, reverse=True)

        if self.use_reranker and self.reranker is not None:
            m = min(int(rerank_top_m), len(pool))
            head = pool[:m]
            pairs = [(query, c.text) for c in head]
            with torch.no_grad():
                rr = self.reranker.predict(pairs)
            for c, s in zip(head, rr):
                c.rerank_score = float(s)
            head.sort(key=lambda x: x.rerank_score, reverse=True)
            pool = head + pool[m:]

        return pool, alloc
