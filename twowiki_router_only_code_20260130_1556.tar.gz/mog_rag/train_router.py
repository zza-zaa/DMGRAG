# mog_rag/train_router.py
from __future__ import annotations
from typing import Dict, List, Tuple
from pathlib import Path
import json
import argparse

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
import faiss
from sentence_transformers import SentenceTransformer

from .config import (
    HOTPOT_TRAIN,
    INDEX_DIR,
    EMB_MODEL_PATH,
    GRANULARITIES,
    MAX_CONTEXT_TOKENS,
    DATASET_NAME,
)
from .utils import load_hotpot, get_supporting_facts, chunk_support_overlap, get_answer, answer_in_chunk
from .router import GranularityRouter

FAISS_HAS_GPU = hasattr(faiss, "StandardGpuResources")

class RouterTrainer:
    """
    2Wiki/Hotpot 通用 Router 训练：
    - Hotpot: supporting_facts overlap teacher
    - 2Wiki: if no supporting_facts, fallback to answer-in-chunk recall teacher
    """

    def __init__(
        self,
        device: str = "cuda",
        topk_per_granularity: int = 64,
        temp: float = 0.5,
        max_train_examples: int = -1,
    ):
        self.device = torch.device("cuda" if ("cuda" in device and torch.cuda.is_available()) else "cpu")
        self.temp = temp
        self.max_train_examples = max_train_examples

        self.dataset = DATASET_NAME.lower()
        self.topk = int(topk_per_granularity)

        print(f"[ROUTER] dataset={self.dataset}, topk_per_granularity={self.topk}, temp={self.temp}")

        encoder_device = "cuda" if torch.cuda.is_available() else "cpu"

        if torch.cuda.is_available() and FAISS_HAS_GPU:
            self.gpu_id = 0
            self.gpu_res = faiss.StandardGpuResources()
            print("[FAISS] GPU enabled for teacher retrieval.")
        else:
            self.gpu_id = -1
            self.gpu_res = None
            print("[FAISS] CPU teacher retrieval.")

        self.q_encoder = SentenceTransformer(str(EMB_MODEL_PATH), device=encoder_device)
        self.emb_dim = int(self.q_encoder.get_sentence_embedding_dimension())

        self.indices: Dict[str, faiss.Index] = {}
        self.metas: Dict[str, List[Dict]] = {}
        self._load_indices(split="train")

        self.router = GranularityRouter(emb_dim=self.emb_dim).to(self.device)
        self.optimizer = torch.optim.Adam(self.router.mlp.parameters(), lr=1e-3)
        self.criterion = nn.KLDivLoss(reduction="batchmean")

    def _load_indices(self, split: str = "train") -> None:
        for gran in GRANULARITIES:
            out_dir = INDEX_DIR / split / gran
            index_path = out_dir / "index.faiss"
            meta_path = out_dir / "meta.jsonl"
            if not index_path.exists():
                print(f"[WARN] index not found for {split}-{gran}, skip.")
                continue

            index_cpu = faiss.read_index(str(index_path))
            if self.gpu_res is not None and self.gpu_id >= 0:
                index = faiss.index_cpu_to_gpu(self.gpu_res, self.gpu_id, index_cpu)
                print(f"[LOAD][GPU] {split}-{gran} index -> GPU{self.gpu_id}")
            else:
                index = index_cpu
                print(f"[LOAD][CPU] {split}-{gran} index")

            metas: List[Dict] = []
            with meta_path.open("r", encoding="utf-8") as f:
                for line in f:
                    metas.append(json.loads(line))

            self.indices[gran] = index
            self.metas[gran] = metas
            print(f"[LOAD] {split}-{gran}: {len(metas)} chunks.")

    def _encode_query(self, q: str) -> np.ndarray:
        emb = self.q_encoder.encode([q], normalize_embeddings=True)
        return np.asarray(emb, dtype="float32")  # [1,d]

    def _score_granularity(
        self,
        q: str,
        q_emb: np.ndarray,
        ex_id: int,
        supporting_facts: List[Tuple[str, int]],
        answer: str,
        gran: str,
    ) -> float:
        """
        Teacher score S_g:
        - if supporting_facts available: overlap recall
        - else (2Wiki typical): answer coverage recall (whether answer appears in retrieved chunks)
        + mild length penalty (0.5) to avoid doc dominating purely by length
        """
        if gran not in self.indices:
            return 0.0

        index = self.indices[gran]
        metas = self.metas[gran]

        scores, idxs = index.search(q_emb, self.topk)
        idxs = idxs[0]

        lengths: List[int] = []
        cov = 0.0
        denom = 0.0

        use_sf = len(supporting_facts) > 0

        for idx in idxs:
            if idx < 0:
                continue
            meta = metas[int(idx)]
            if int(meta.get("ex_id", -1)) != ex_id:
                continue

            text = meta.get("text", "") or ""
            if text:
                lengths.append(len(text.split()))

            if use_sf:
                c, tot = chunk_support_overlap(meta, supporting_facts)
                cov += float(c)
                denom = float(tot) if tot > 0 else denom
            else:
                # fallback: answer-in-chunk
                if answer and answer_in_chunk(answer, text):
                    cov += 1.0
                denom = 1.0  # binary recall for answer coverage

        if denom <= 0:
            return 0.0

        recall = min(1.0, cov / denom)

        avg_len = float(sum(lengths) / len(lengths)) if lengths else 50.0
        avg_len_norm = avg_len / 200.0
        length_penalty = 1.0 + 0.5 * avg_len_norm  # mild

        return float(recall / length_penalty)

    def _compute_soft_label_for_example(self, ex_id: int, ex: Dict) -> torch.Tensor:
        q = ex.get("question", "")
        supporting_facts = get_supporting_facts(ex)
        answer = get_answer(ex)
        q_emb = self._encode_query(q)

        scores: List[float] = []
        for gran in GRANULARITIES:
            s = self._score_granularity(q, q_emb, ex_id, supporting_facts, answer, gran)
            scores.append(s)

        scores_np = np.asarray(scores, dtype="float32")
        if np.all(scores_np == 0):
            probs = np.ones_like(scores_np) / max(1, len(scores_np))
        else:
            temp = max(self.temp, 1e-6)
            z = scores_np / temp
            exp = np.exp(z - z.max())
            probs = exp / exp.sum()

        return torch.tensor(probs, dtype=torch.float32)

    def train(self, num_epochs: int = 1, budget_tokens: int = MAX_CONTEXT_TOKENS):
        data = load_hotpot(HOTPOT_TRAIN)
        if self.max_train_examples and self.max_train_examples > 0:
            data = data[: self.max_train_examples]
            print(f"[ROUTER] use first {len(data)} examples from {self.dataset} train.")
        else:
            print(f"[ROUTER] use FULL train set: {len(data)} examples.")

        self.router.train()

        for epoch in range(num_epochs):
            total_loss = 0.0
            n = 0
            pbar = tqdm(enumerate(data), total=len(data), desc=f"Train router epoch {epoch+1}")
            for ex_id, ex in pbar:
                target = self._compute_soft_label_for_example(ex_id, ex).to(self.device)

                # IMPORTANT: router now takes embedding (DEVICE SAFE)
                with torch.no_grad():
                    q_emb = self.q_encoder.encode([ex["question"]], normalize_embeddings=True)
                q_emb_t = torch.tensor(q_emb, dtype=torch.float32, device=self.device)

                out = self.router(
                    q_emb_t,
                    budget_tokens=budget_tokens,
                    q_len_chars=len(ex["question"]),
                    budget_norm=float(MAX_CONTEXT_TOKENS),
                )
                probs = out.probs
                log_probs = torch.log(probs + 1e-8)

                loss = self.criterion(log_probs.unsqueeze(0), target.unsqueeze(0))
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                total_loss += float(loss.item())
                n += 1
                if n % 100 == 0:
                    pbar.set_postfix(loss=total_loss / n)

            print(f"[ROUTER] epoch={epoch+1}  avg_loss={total_loss / max(1,n):.4f}")

        out_path = Path("router_mlp.pt")
        torch.save(self.router.mlp.state_dict(), out_path)
        print(f"[SAVE] router MLP weights -> {out_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train granularity router.")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--max_examples", type=int, default=20000)
    parser.add_argument("--topk_per_gran", type=int, default=64)
    parser.add_argument("--temp", type=float, default=0.5)
    parser.add_argument("--init_from", type=str, default="")

    args = parser.parse_args()

    trainer = RouterTrainer(
        device=args.device,
        topk_per_granularity=args.topk_per_gran,
        temp=args.temp,
        max_train_examples=args.max_examples,
    )

    if args.init_from:
        ckpt = Path(args.init_from)
        if ckpt.exists():
            state = torch.load(ckpt, map_location="cpu")
            model_state = trainer.router.mlp.state_dict()
            filtered = {k: v for k, v in state.items() if k in model_state and v.shape == model_state[k].shape}
            trainer.router.mlp.load_state_dict(filtered, strict=False)
            print(f"[INIT] loaded from {ckpt}")

    trainer.train(num_epochs=args.epochs, budget_tokens=MAX_CONTEXT_TOKENS)
