# mog_rag/train_budgeter_from_oracle.py
from __future__ import annotations
import argparse
import json
from typing import List, Dict

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sentence_transformers import SentenceTransformer

from .config import EMB_MODEL_PATH, MAX_CONTEXT_TOKENS
from .budgeter_runtime import BudgetRegressor


def _kl(p: torch.Tensor, q: torch.Tensor) -> torch.Tensor:
    eps = 1e-8
    p = torch.clamp(p, eps, 1.0)
    q = torch.clamp(q, eps, 1.0)
    return torch.sum(q * (torch.log(q) - torch.log(p)), dim=-1).mean()


class OracleBudgetDS(Dataset):
    def __init__(self, jsonl: str, emb: SentenceTransformer):
        self.rows: List[Dict] = []
        with open(jsonl, "r", encoding="utf-8") as f:
            for line in f:
                self.rows.append(json.loads(line))
        self.emb = emb

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        q = (r.get("question") or "").strip()
        bucket_id = int(r.get("budget_bucket_id", 1))

        share = r.get("prior_share", None)
        if not isinstance(share, dict):
            share = {"doc": 1/3, "para": 1/3, "sent": 1/3}
        y_share = torch.tensor([float(share.get("doc", 0.0)),
                                float(share.get("para", 0.0)),
                                float(share.get("sent", 0.0))], dtype=torch.float32)
        s = float(y_share.sum().item())
        if s > 0:
            y_share = y_share / s
        else:
            y_share[:] = 1/3

        q_emb = self.emb.encode([q], normalize_embeddings=True)[0]
        return torch.tensor(q_emb, dtype=torch.float32), torch.tensor(bucket_id, dtype=torch.long), y_share, len(q)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsonl", type=str, required=True)
    ap.add_argument("--out", type=str, default="budget_mlp.pt")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--hidden", type=int, default=512)
    ap.add_argument("--kl_w", type=float, default=1.0)
    ap.add_argument("--cuda", type=int, default=1)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() and args.cuda else "cpu")

    emb = SentenceTransformer(str(EMB_MODEL_PATH), device=("cuda" if torch.cuda.is_available() and args.cuda else "cpu"))
    emb_dim = int(emb.get_sentence_embedding_dimension())

    # buckets 与 build_oracle_labels 一致：4个 buckets（512/1024/1536/2048）
    model = BudgetRegressor(emb_dim=emb_dim, hidden=args.hidden, num_buckets=4, num_grans=3).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)

    ds = OracleBudgetDS(args.jsonl, emb=emb)
    dl = DataLoader(ds, batch_size=args.bs, shuffle=True, num_workers=0)

    ce = nn.CrossEntropyLoss()

    model.train()
    for ep in range(args.epochs):
        tot = 0.0
        for q_emb, b_idx, y_share, qlen in dl:
            q_emb = q_emb.to(device)
            b_idx = b_idx.to(device)
            y_share = y_share.to(device)

            bucket_logits, share_logits = model(
                q_emb=q_emb,
                budget_tokens=1024,
                q_len_chars=int(qlen[0].item()) if hasattr(qlen, "shape") else 0,
                hop_feat=0.0,
                type_feat=0.0,
                budget_norm=float(MAX_CONTEXT_TOKENS),
                qlen_norm=256.0,
            )
            p_share = torch.softmax(share_logits, dim=-1)

            loss = ce(bucket_logits, b_idx) + float(args.kl_w) * _kl(p_share, y_share)
            opt.zero_grad()
            loss.backward()
            opt.step()
            tot += float(loss.item())

        print(f"[EP {ep}] loss={tot/max(1,len(dl)):.4f}")

    torch.save(model.state_dict(), args.out)
    print(f"[OK] saved budgeter: {args.out}")


if __name__ == "__main__":
    main()
