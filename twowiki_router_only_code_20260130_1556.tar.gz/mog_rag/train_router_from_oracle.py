from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from sentence_transformers import SentenceTransformer

from .config import EMB_MODEL_PATH, GRANULARITIES
from .policies import get_policies_from_env
from .router import GranularityRouter


class OracleRouterDataset(Dataset):
    def __init__(self, oracle_path: Path, max_examples: int = 0):
        self.rows: List[Dict[str, Any]] = []
        with oracle_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                r = json.loads(line)
                # Accept both new format and legacy "teacher" wrapper
                if "teacher" in r and isinstance(r["teacher"], dict):
                    t = r["teacher"]
                    r = {
                        "question": r.get("question", ""),
                        "budget_tokens": int(t.get("budget_tokens", r.get("budget_tokens", 2048))),
                        "best_policy_id": int(t.get("best_policy_id", r.get("best_policy_id", 0))),
                    }
                else:
                    r = {
                        "question": r.get("question", ""),
                        "budget_tokens": int(r.get("budget_tokens", r.get("best_budget", 2048))),
                        "best_policy_id": int(r.get("best_policy_id", 0)),
                    }
                if not r["question"]:
                    continue
                self.rows.append(r)
                if max_examples and len(self.rows) >= max_examples:
                    break

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        r = self.rows[idx]
        q = str(r["question"])
        return {
            "q": q,
            "pid": int(r["best_policy_id"]),
            "budget": float(r["budget_tokens"]),
            "q_len": float(len(q)),
        }


def collate(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "q": [x["q"] for x in batch],
        "pid": torch.tensor([x["pid"] for x in batch], dtype=torch.long),
        "budget": torch.tensor([x["budget"] for x in batch], dtype=torch.float32),
        "q_len": torch.tensor([x["q_len"] for x in batch], dtype=torch.float32),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--oracle", type=str, required=True)
    ap.add_argument("--out", type=str, default="ckpts/router_policy_v2.pt")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--hidden", type=int, default=512)
    ap.add_argument("--max_examples", type=int, default=0)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--label_smoothing", type=float, default=0.05)
    ap.add_argument("--num_workers", type=int, default=2)
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    oracle_path = Path(args.oracle)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    policies = get_policies_from_env(GRANULARITIES)
    P = len(policies)

    ds = OracleRouterDataset(oracle_path, max_examples=args.max_examples)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, collate_fn=collate)

    # frozen encoder
    enc_device = "cuda" if torch.cuda.is_available() else "cpu"
    encoder = SentenceTransformer(str(EMB_MODEL_PATH), device=enc_device)

    dummy = encoder.encode(["dummy"], normalize_embeddings=True)
    emb_dim = int(np.asarray(dummy).shape[1])

    model = GranularityRouter(emb_dim=emb_dim, hidden_size=args.hidden, policies=policies).to(device)
    model.train()

    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=0.01)

    # for stable normalization
    max_budget_seen = 2048.0

    for ep in range(1, int(args.epochs) + 1):
        total_loss = 0.0
        total = 0
        correct = 0

        for it, batch in enumerate(dl, start=1):
            qs = batch["q"]
            y = batch["pid"].to(device)
            budgets = batch["budget"].to(device)
            qlens = batch["q_len"].to(device)

            max_budget_seen = max(max_budget_seen, float(budgets.max().item()))

            q_emb = encoder.encode(qs, normalize_embeddings=True)
            q_emb_t = torch.from_numpy(np.asarray(q_emb, dtype="float32")).to(device)

            out = model(
                q_emb_t,
                budget_tokens=budgets,
                q_len_chars=qlens,
                budget_norm=float(max(2048.0, max_budget_seen)),
                qlen_norm=256.0,
            )
            logits = out.policy_logits
            assert logits is not None
            if logits.shape[-1] != P:
                raise RuntimeError(f"Policy head dim mismatch: got {logits.shape[-1]} expected {P}")

            loss = F.cross_entropy(logits, y, label_smoothing=float(args.label_smoothing))

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

            total_loss += float(loss.item()) * int(y.numel())
            total += int(y.numel())
            with torch.no_grad():
                pred = torch.argmax(logits, dim=-1)
                correct += int((pred == y).sum().item())

            if it % 50 == 0:
                print(f"[ep={ep}] iter={it} loss={total_loss/max(1,total):.4f} acc={correct/max(1,total):.4f}")

        print(f"[EPOCH {ep}] loss={total_loss/max(1,total):.4f} acc={correct/max(1,total):.4f}")

    ckpt = {
        "state_dict": model.state_dict(),
        "policies": [{"name": p.name, "share": dict(p.share)} for p in policies],
        "granularities": list(GRANULARITIES),
        "emb_dim": emb_dim,
    }
    torch.save(ckpt, out_path)
    print(f"[OK] saved router ckpt to {out_path}")


if __name__ == "__main__":
    main()
