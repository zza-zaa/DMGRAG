# mog_rag/rag_pipeline_nopack.py
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import os
import re
import time
import inspect

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

from .config import MAX_CONTEXT_TOKENS, TOTAL_TOPK, GRANULARITIES, LLM_MODEL_PATH
from .retrieval import MultiGranRetriever, RetrievedChunk
from .router import GranularityRouter


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except Exception:
        return int(default)


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, None)
    if v is None:
        return bool(default)
    v = str(v).strip().lower()
    return v in ("1", "true", "yes", "y", "t", "on")


def _clean_spaces(s: str) -> str:
    s = (s or "").replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _filter_kwargs(fn: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(fn)
        params = sig.parameters
        for p in params.values():
            if p.kind == inspect.Parameter.VAR_KEYWORD:
                return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in params}
    except Exception:
        return dict(kwargs)


def _build_router(emb_dim: int, num_grans: int) -> GranularityRouter:
    cand_kwargs = [
        {"emb_dim": emb_dim, "num_granularities": num_grans},
        {"emb_dim": emb_dim, "n_granularities": num_grans},
        {"emb_dim": emb_dim, "num_grans": num_grans},
        {"emb_dim": emb_dim, "n_grans": num_grans},
        {"emb_dim": emb_dim, "num_classes": num_grans},
        {"emb_dim": emb_dim, "n_classes": num_grans},
        {"qdim": emb_dim, "num_granularities": num_grans},
        {"qdim": emb_dim, "num_grans": num_grans},
        {"input_dim": emb_dim, "num_grans": num_grans},
        {"in_dim": emb_dim, "num_grans": num_grans},
        {"emb_dim": emb_dim},
        {"qdim": emb_dim},
        {},
    ]
    init_fn = GranularityRouter.__init__
    for kw in cand_kwargs:
        try:
            use_kw = _filter_kwargs(init_fn, kw)
            router = GranularityRouter(**use_kw)
            print(f"[Router] init ok with kwargs={use_kw}")
            return router
        except Exception:
            continue
    for args in [(emb_dim, num_grans), (emb_dim,), ()]:
        try:
            router = GranularityRouter(*args)
            print(f"[Router] init ok with args={args}")
            return router
        except Exception:
            pass
    raise RuntimeError("Failed to initialize GranularityRouter: signature mismatch")


class HotpotRAGPipeline:
    """
    NO-PACK pipeline:
      - 不进行 pack/贪心选块；直接把 candidates 全部塞进 Context
      - 不使用 CTX_BUDGET 限制；最终由 tokenizer 按 max_input_tokens 自动截断
      - TOTAL_TOPK/STAGE1_TOTAL_TOPK 若 <=0，则用 AUTO_TOPK(默认2000)
    """

    def __init__(self, split: str = "dev") -> None:
        self.split = split

        llm_path = os.getenv("LLM_PATH", "").strip() or os.getenv("LLM_MODEL_PATH", "").strip()
        if not llm_path:
            llm_path = str(LLM_MODEL_PATH)
        self.llm_path = llm_path

        self.use_router = _env_bool("USE_ROUTER", False)
        self.use_budgeter = _env_bool("USE_BUDGETER", False)  # 保留字段，但本 nopack 版本不会用

        use_reranker = _env_bool("USE_RERANKER", True)
        self.retriever = MultiGranRetriever(split=self.split, use_reranker=use_reranker, router=None)

        # Router（可选：你要“仅路由器”也可以复用）
        self.router: Optional[GranularityRouter] = None
        if self.use_router:
            ckpt = os.getenv("ROUTER_CKPT", "").strip()
            if not ckpt:
                raise ValueError("USE_ROUTER=1 but ROUTER_CKPT is empty")
            qdim = int(self.retriever._encode_query("dummy").shape[1])
            self.router = _build_router(emb_dim=qdim, num_grans=len(GRANULARITIES))
            state = torch.load(ckpt, map_location="cpu")
            sd = state.get("state_dict", state) if isinstance(state, dict) else state
            cleaned: Dict[str, Any] = {}
            if isinstance(sd, dict):
                for k, v in sd.items():
                    nk = k
                    for pref in ("model.", "module.", "router."):
                        if nk.startswith(pref):
                            nk = nk[len(pref):]
                    cleaned[nk] = v
            missing, unexpected = self.router.load_state_dict(cleaned, strict=False)
            self.router.eval()
            self.router.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            print(f"[Router] loaded {ckpt} (missing={len(missing)} unexpected={len(unexpected)})")
            self.retriever.router = self.router

        # LLM
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True, use_fast=True)
        except Exception:
            self.tokenizer = AutoTokenizer.from_pretrained(self.llm_path, trust_remote_code=True, use_fast=False)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            self.llm_path,
            torch_dtype=dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()

    def _count_tokens(self, text: str) -> int:
        try:
            return int(len(self.tokenizer.encode(text, add_special_tokens=False)))
        except Exception:
            return max(1, len((text or "").split()))

    def _chunk_to_ctx_block(self, c: RetrievedChunk, idx: int) -> str:
        title = _clean_spaces(getattr(c, "title", ""))
        text = _clean_spaces(getattr(c, "text", ""))
        if title:
            return f"[{idx}] {title}: {text}"
        return f"[{idx}] {text}"

    def _ctx_token_stats(self, chunks: List[RetrievedChunk]) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for c in chunks:
            g = getattr(c, "granularity", "unk")
            out[g] = out.get(g, 0) + self._count_tokens(getattr(c, "text", "") or "")
        return out

    def answer(self, question: str, debug: bool = False) -> Tuple[str, Dict[str, Any]]:
        t0 = time.time()

        # 这里不使用 ctx_budget 去做 pack；保留字段仅用于检索阶段
        ctx_budget = _env_int("CTX_BUDGET", int(MAX_CONTEXT_TOKENS))
        if ctx_budget <= 0 or _env_bool("NO_CTX_TOKEN_LIMIT", False):
            ctx_budget = 10**9

        # AUTO_TOPK：你不设置 TOP-K 时，用自动值（默认2000）
        total_topk = _env_int("TOTAL_TOPK", int(TOTAL_TOPK))
        stage1_total_topk = _env_int("STAGE1_TOTAL_TOPK", int(total_topk))
        auto_topk = _env_int("AUTO_TOPK", 2000)
        if total_topk <= 0:
            total_topk = auto_topk
        if stage1_total_topk <= 0:
            stage1_total_topk = total_topk

        rerank_top_m = _env_int("RERANK_TOP_M", 160)

        prior_share = None
        alloc: Dict[str, int] = {}

        # 取 candidates（照旧）
        if stage1_total_topk > total_topk:
            candidates, alloc = self.retriever.retrieve_stagewise(
                query=question,
                budget_tokens=ctx_budget,
                stage1_total_topk=stage1_total_topk,
                rerank_top_m=rerank_top_m,
                prior_share=prior_share,
            )
        else:
            candidates = self.retriever.retrieve_multi_gran(
                query=question,
                budget_tokens=ctx_budget,
                total_topk=total_topk,
                prior_share=prior_share,
            )
            alloc = dict(getattr(self.retriever, "last_alloc", {}) or {})

        # ✅ NO-PACK：不做任何贪心/packer/budgeter，直接全塞
        selected = list(candidates)

        ctx_blocks = [self._chunk_to_ctx_block(c, i + 1) for i, c in enumerate(selected)]
        ctx_text = "\n".join(ctx_blocks)

        # ===== prompt：把“关键规则”放在 user 里，防止 truncation 把 system 截掉 =====
        sys_msg = "You are a question answering system."
        rules = (
            "Rules:\n"
            "- Use the Context to answer the Question.\n"
            "- You MAY combine information across multiple context snippets (multi-hop is allowed).\n"
            "- Output ONLY the final answer string. No explanation.\n"
            "- For yes/no questions, output exactly: yes or no.\n"
            "- If the answer is an entity, output the shortest canonical name.\n"
        )
        user_msg = (
            f"Context:\n{ctx_text}\n\n"
            f"{rules}\n"
            f"Question: {question}\n"
            "Answer:"
        )

        if hasattr(self.tokenizer, "apply_chat_template"):
            prompt = self.tokenizer.apply_chat_template(
                [{"role": "system", "content": sys_msg},
                 {"role": "user", "content": user_msg}],
                tokenize=False,
                add_generation_prompt=True,
            )
        else:
            prompt = sys_msg + "\n\n" + user_msg

        # ✅ 关键：让 tokenizer 自动截断输入（取消人工 token budget / pack）
        max_input = _env_int("MAX_INPUT_TOKENS", int(getattr(self.tokenizer, "model_max_length", 8192)))
        if max_input <= 0:
            max_input = int(getattr(self.tokenizer, "model_max_length", 8192))

        # 保留 question / Answer: 在末尾：用 left truncation 优先丢掉前面的 context
        try:
            old_side = getattr(self.tokenizer, "truncation_side", "right")
            self.tokenizer.truncation_side = "left"
        except Exception:
            old_side = "right"

        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=max_input,
        ).to(self.model.device)

        try:
            self.tokenizer.truncation_side = old_side
        except Exception:
            pass

        input_len = int(inputs["input_ids"].shape[-1])

        gen_kwargs = {
            "max_new_tokens": int(_env_int("MAX_NEW_TOKENS", 64)),
            "pad_token_id": self.tokenizer.eos_token_id,
            "eos_token_id": self.tokenizer.eos_token_id,
        }
        temperature = float(os.getenv("TEMPERATURE", "0.0"))
        top_p = float(os.getenv("TOP_P", "1.0"))
        if temperature > 1e-6:
            gen_kwargs.update({"do_sample": True, "temperature": float(temperature), "top_p": float(top_p)})
        else:
            gen_kwargs.update({"do_sample": False})

        with torch.inference_mode():
            out_ids = self.model.generate(**inputs, **gen_kwargs)

        gen_ids = out_ids[0][input_len:]
        ans = self.tokenizer.decode(gen_ids, skip_special_tokens=True).strip()

        # 清理
        if ans.lower().startswith("assistant"):
            ans = ans[len("assistant"):].lstrip(": \n\t")
        lines = [x.strip() for x in ans.splitlines() if x.strip()]
        ans = lines[0] if lines else ans.strip()
        ans = ans.strip().strip('"').strip("'")

        dbg: Dict[str, Any] = {}
        if debug or _env_bool("PRINT_CTX_STATS", False):
            dbg = {
                "alloc_topk": alloc,
                "ctx_token_stats": self._ctx_token_stats(selected),
                "n_candidates": int(len(candidates)),
                "n_selected": int(len(selected)),
                "max_input_tokens": int(max_input),
                "elapsed_sec": float(time.time() - t0),
            }
        return ans, dbg
