# mog_rag/analyze_runs.py
"""
分析 4 组 Hotpot 结果的脚本：

- hotpot_dev_multi.jsonl
- hotpot_dev_sent_only.jsonl
- hotpot_dev_para_only.jsonl
- hotpot_dev_doc_only.jsonl

功能：
1) 重新用和 evaluate_hotpot 一样的规则计算 EM / F1（sanity check）
2) 统计 multi vs sent/para/doc 的交集/差集：
   - multi 正确 & baseline 错误
   - multi 错误 & baseline 正确
3) 打印一些典型样例，方便你人工看 case。
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Tuple

from .evaluate_hotpot import _normalize_answer, _qa_em_f1


def load_run(path: Path) -> List[Dict[str, Any]]:
    data = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
    return data


def get_q_gold_pred(ex: Dict[str, Any]) -> Tuple[str, str, str]:
    """尽量兼容不同字段名."""
    q = ex.get("question") or ex.get("q") or ""
    gold = (
        ex.get("gold")
        or ex.get("answer")
        or ex.get("gold_answer")
        or ex.get("gold_answer_text")
        or ""
    )
    pred = (
        ex.get("pred")
        or ex.get("prediction")
        or ex.get("pred_answer")
        or ex.get("model_answer")
        or ""
    )
    return str(q), str(gold), str(pred)


def compute_metrics(run: List[Dict[str, Any]]) -> Tuple[float, float]:
    total_em = 0.0
    total_f1 = 0.0
    n = len(run)
    for ex in run:
        _, gold, pred = get_q_gold_pred(ex)
        em, f1 = _qa_em_f1(pred, gold)
        total_em += em
        total_f1 += f1
    return (total_em / n if n > 0 else 0.0,
            total_f1 / n if n > 0 else 0.0)


def compare_two_runs(
    name_a: str,
    run_a: List[Dict[str, Any]],
    name_b: str,
    run_b: List[Dict[str, Any]],
) -> None:
    """
    假设两组结果是对齐的（同一个数据集，同样顺序），
    逐条比较：
      - A 正确 & B 错误
      - A 错误 & B 正确
    """
    assert len(run_a) == len(run_b), f"{name_a} 和 {name_b} 长度不一致"

    better = []  # A 正确 B 错误
    worse = []   # A 错误 B 正确

    for i, (ex_a, ex_b) in enumerate(zip(run_a, run_b)):
        q_a, gold_a, pred_a = get_q_gold_pred(ex_a)
        q_b, gold_b, pred_b = get_q_gold_pred(ex_b)

        # 简单 sanity check：问题和 gold 是否一致
        if _normalize_answer(q_a) != _normalize_answer(q_b):
            print(f"[WARN] 问题不一致 idx={i}")
        if _normalize_answer(gold_a) != _normalize_answer(gold_b):
            print(f"[WARN] gold 不一致 idx={i}")

        em_a, _ = _qa_em_f1(pred_a, gold_a)
        em_b, _ = _qa_em_f1(pred_b, gold_b)

        if em_a == 1.0 and em_b == 0.0:
            better.append((i, q_a, gold_a, pred_a, pred_b))
        elif em_a == 0.0 and em_b == 1.0:
            worse.append((i, q_a, gold_a, pred_a, pred_b))

    print(f"\n=== 对比 {name_a} vs {name_b} ===")
    print(f"{name_a} 正确 & {name_b} 错误: {len(better)}")
    print(f"{name_b} 正确 & {name_a} 错误: {len(worse)}")

    # 打印前若干条典型样例
    def print_cases(cases, title, max_show=10):
        print(f"\n---- {title}（最多显示 {max_show} 条）----")
        for (i, q, gold, pa, pb) in cases[:max_show]:
            print(f"[idx={i}] Q: {q}")
            print(f"  Gold: {gold}")
            print(f"  {name_a} pred: {pa}")
            print(f"  {name_b} pred: {pb}")
            print()

    print_cases(
        better,
        f"{name_a} 正确 / {name_b} 错误 的样例",
    )
    print_cases(
        worse,
        f"{name_b} 正确 / {name_a} 错误 的样例",
    )


def main():
    base = Path("/home/peiyu/new/results")  # 如果你放在别的路径，这里改一下

    multi_path = base / "hotpot_dev_multi.jsonl"
    sent_path = base / "hotpot_dev_sent_only.jsonl"
    para_path = base / "hotpot_dev_para_only.jsonl"
    doc_path = base / "hotpot_dev_doc_only.jsonl"

    print("[LOAD]", multi_path)
    multi = load_run(multi_path)
    print("[LOAD]", sent_path)
    sent = load_run(sent_path)
    print("[LOAD]", para_path)
    para = load_run(para_path)
    print("[LOAD]", doc_path)
    doc = load_run(doc_path)

    print(f"Loaded N={len(multi)} examples")

    # 1) 单独算每个 run 的 EM/F1（sanity check）
    for name, run in [
        ("multi", multi),
        ("sent-only", sent),
        ("para-only", para),
        ("doc-only", doc),
    ]:
        em, f1 = compute_metrics(run)
        print(f"[METRIC] {name:10s}  EM={em:.3f}  F1={f1:.3f}")

    # 2) multi vs 三个 baseline 的交集/差集
    compare_two_runs("multi", multi, "sent-only", sent)
    compare_two_runs("multi", multi, "para-only", para)
    compare_two_runs("multi", multi, "doc-only", doc)


if __name__ == "__main__":
    main()
