from __future__ import annotations
from dataclasses import dataclass
from typing import List

import numpy as np
import torch
import torch.nn as nn

from .config import GRANULARITIES


@dataclass
class ChunkFeature:
    """
    训练/推理时预算器看到的每个 chunk 的“轻量特征”。

    - text:           chunk 文本（这里只用于长度统计，LLM 不在这里出现）
    - granularity_id: 0=sent, 1=para, 2=doc（与 GRANULARITIES 顺序一致）
    - length_tokens:  粗略的 token 数（用 len(text.split()) 近似）
    - bm25_score:     BM25 得分（目前为 0，将来可以填）
    - dense_score:    向量检索得分（faiss 搜出来的）
    - diversity_score:以后可以用来加“多样性”，目前为 0 即可
    """
    text: str
    granularity_id: int
    length_tokens: int
    bm25_score: float = 0.0
    dense_score: float = 0.0
    diversity_score: float = 0.0


class BudgetRegressor(nn.Module):
    """
    把 BudgetRegressor 定义成一个“基于轻量特征的 chunk 排序器”：

    - 不在这里做大模型编码（避免重复 encode，且训练/推理都更稳定）；
    - 只使用：
        * dense_score（已包含 query-chunk 语义相似度）
        * 长度（越长在同等得分下惩罚）
        * 粒度（sent/para/doc 的 embedding）
        * （预留）BM25 / diversity 等

    forward:
        输入: query（目前不使用）、chunks、budget_tokens（目前不直接用）
        输出: 每个 chunk 的一个 logit 分数，值越大表示越重要/越值得保留。
    """

    def __init__(
        self,
        num_granularities: int = None,
        hidden_dim: int = 64,
    ) -> None:
        super().__init__()
        if num_granularities is None:
            num_granularities = len(GRANULARITIES)

        # 粒度 embedding：sent/para/doc -> 一个 8 维向量
        self.gran_emb = nn.Embedding(num_granularities, 8)

        # feature 维度：
        #   dense_norm, log_len, bm25_norm, diversity_norm, gran_emb(8), rank_norm
        in_dim = 1 + 1 + 1 + 1 + 8 + 1
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    # ----------------- 将一批 chunks 转为特征 Tensor -----------------

    def _chunks_to_features(self, chunks: List[ChunkFeature]) -> torch.Tensor:
        """
        按“单个问题”级别把 chunks 转成特征矩阵 [N, D]。

        我们在这里做 per-query 的归一：
        - dense_score 做 min-max 归一；
        - length 做 log + 归一；
        - bm25/diversity 同理；
        - rank(0…N-1) 也做 0~1 归一。
        """
        if not chunks:
            return torch.empty(0, 0)

        N = len(chunks)
        dense = np.array([c.dense_score for c in chunks], dtype="float32")
        length = np.array(
            [max(1, c.length_tokens) for c in chunks],
            dtype="float32",
        )
        bm25 = np.array([c.bm25_score for c in chunks], dtype="float32")
        diversity = np.array([c.diversity_score for c in chunks], dtype="float32")
        gran_ids = np.array([c.granularity_id for c in chunks], dtype="int64")

        # -------- per-query 归一化 --------

        def min_max_norm(x: np.ndarray) -> np.ndarray:
            if x.size == 0:
                return x
            xmin = float(x.min())
            xmax = float(x.max())
            if xmax <= xmin + 1e-6:
                return np.ones_like(x, dtype="float32")
            return (x - xmin) / (xmax - xmin + 1e-6)

        dense_norm = min_max_norm(dense)
        bm25_norm = min_max_norm(bm25)
        div_norm = min_max_norm(diversity)

        # 长度用 log，然后再做一次 min-max
        log_len = np.log(length + 1.0).astype("float32")
        log_len_norm = min_max_norm(log_len)

        # rank 特征（原始顺序视为“检索排序”）
        ranks = np.arange(N, dtype="float32")
        rank_norm = ranks / max(1.0, float(N - 1))

        # 目标 device：跟 gran_emb / mlp 一致
        device = self.gran_emb.weight.device

        # 粒度 embedding（注意把索引搬到同一个 device）
        gran_ids_t = torch.from_numpy(gran_ids).to(device)
        gran_emb = self.gran_emb(gran_ids_t)  # [N, 8]

        # 拼接所有 scalar 特征，并搬到同一个 device
        scalar_np = np.stack(
            [dense_norm, log_len_norm, bm25_norm, div_norm, rank_norm],
            axis=1,
        )  # [N, 5]

        scalar_feats = torch.from_numpy(scalar_np).to(device)  # [N, 5]

        # 最终特征: [N, 5+8] = [N, 13]
        feats = torch.cat([scalar_feats, gran_emb], dim=1)  # [N, 13]
        return feats

    # ----------------- 前向：返回每个 chunk 的 logit 分数 -----------------

    def forward(
        self,
        query: str,
        chunks: List[ChunkFeature],
        budget_tokens: int,
    ) -> torch.Tensor:
        """
        query: 目前我们不在这里显式用 query（后续可加问题类型特征），
               但保留这个参数以和现有接口兼容。
        chunks: 一条问题对应的所有候选 chunk。
        budget_tokens: 当前预算（这里也暂时不用，保持接口兼容）。
        """
        if not chunks:
            # 返回 shape [0] 的 tensor，方便上层处理
            return torch.empty(0, device=self.mlp[0].weight.device)

        feats = self._chunks_to_features(chunks)  # [N, D]，已经在正确的 device 上
        logits = self.mlp(feats).squeeze(-1)      # [N]
        return logits
