from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Union

import os

import torch
import torch.nn as nn

from .config import GRANULARITIES
from .policies import get_policies_from_env, policy_share_matrix


@dataclass
class RouterOutput:
    """Router output.

    `retrieval._allocate_topk` only consumes `probs` and `granularity_order`.
    We additionally expose `policy_logits`/`policy_probs` for training/debug.
    """

    probs: torch.Tensor  # [B, G] or [G]
    granularity_order: Sequence[str]
    policy_logits: Optional[torch.Tensor] = None  # [B, P]
    policy_probs: Optional[torch.Tensor] = None   # [B, P]


def _to_1d_float_tensor(x: Union[float, int, torch.Tensor], device: torch.device, B: int) -> torch.Tensor:
    if isinstance(x, torch.Tensor):
        t = x.to(device=device, dtype=torch.float32)
        if t.dim() == 0:
            t = t.view(1).expand(B)
        elif t.dim() == 1:
            if t.numel() == 1:
                t = t.expand(B)
            elif t.numel() != B:
                # best-effort: broadcast first value
                t = t[:1].expand(B)
        else:
            t = t.view(-1)[:1].expand(B)
        return t
    return torch.full((B,), float(x), device=device, dtype=torch.float32)


class GranularityRouter(nn.Module):
    """Policy-distilled router.

    Predicts a distribution over a discrete policy set (predefined budget splits),
    then converts it into a soft share over (sent, para, doc) by expectation.

    This keeps your original interface:
        forward(q_emb, budget_tokens=..., q_len_chars=..., hop_feat=..., type_feat=...)
        -> RouterOutput with `probs` over GRANULARITIES.
    """

    def __init__(
        self,
        emb_dim: int,
        hidden_size: int = 512,
        extra_dim: int = 4,
        policies=None,
    ) -> None:
        super().__init__()

        self.emb_dim = int(emb_dim)
        self.extra_dim = int(extra_dim)

        if policies is None:
            policies = get_policies_from_env(GRANULARITIES)
        self.policies = list(policies)

        share = policy_share_matrix(self.policies, GRANULARITIES)  # [P, G]
        self.register_buffer("policy_share", share)

        in_dim = self.emb_dim + self.extra_dim
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
        )
        self.policy_head = nn.Linear(hidden_size, len(self.policies))

    def _extra_feats(
        self,
        budget_tokens: Union[float, int, torch.Tensor],
        q_len_chars: Union[float, int, torch.Tensor],
        hop_feat: Union[float, int, torch.Tensor] = 0.0,
        type_feat: Union[float, int, torch.Tensor] = 0.0,
        budget_norm: float = 2048.0,
        qlen_norm: float = 200.0,
        device: Optional[torch.device] = None,
        B: int = 1,
    ) -> torch.Tensor:
        device = device or self.policy_head.weight.device
        bnorm = float(budget_norm) if float(budget_norm) > 0 else 2048.0
        qnorm = float(qlen_norm) if float(qlen_norm) > 0 else 200.0

        bt = _to_1d_float_tensor(budget_tokens, device, B) / bnorm
        ql = _to_1d_float_tensor(q_len_chars, device, B) / qnorm
        hf = _to_1d_float_tensor(hop_feat, device, B)
        tf = _to_1d_float_tensor(type_feat, device, B)

        return torch.stack([bt, ql, hf, tf], dim=-1)  # [B, 4]

    def forward(
        self,
        q_emb: torch.Tensor,
        budget_tokens: Union[float, int, torch.Tensor] = 2048.0,
        q_len_chars: Union[float, int, torch.Tensor] = 0.0,
        hop_feat: Union[float, int, torch.Tensor] = 0.0,
        type_feat: Union[float, int, torch.Tensor] = 0.0,
        budget_norm: float = 2048.0,
        qlen_norm: float = 200.0,
        temperature: Optional[float] = None,
        **_: object,
    ) -> RouterOutput:
        if q_emb.dim() == 1:
            q_emb = q_emb.unsqueeze(0)

        device = next(self.mlp.parameters()).device
        q_emb = q_emb.to(device)
        B = int(q_emb.shape[0])

        if self.extra_dim > 0:
            extra = self._extra_feats(
                budget_tokens=budget_tokens,
                q_len_chars=q_len_chars,
                hop_feat=hop_feat,
                type_feat=type_feat,
                budget_norm=budget_norm,
                qlen_norm=qlen_norm,
                device=device,
                B=B,
            )
            if extra.shape[1] != self.extra_dim:
                if extra.shape[1] < self.extra_dim:
                    pad = torch.zeros((B, self.extra_dim - extra.shape[1]), device=device)
                    extra = torch.cat([extra, pad], dim=1)
                else:
                    extra = extra[:, : self.extra_dim]
            x = torch.cat([q_emb, extra], dim=1)
        else:
            x = q_emb

        h = self.mlp(x)
        logits = self.policy_head(h)  # [B, P]

        if temperature is None:
            try:
                temperature = float(os.getenv("ROUTER_TEMP", "1.0"))
            except Exception:
                temperature = 1.0
        temperature = float(temperature)
        if temperature <= 0:
            temperature = 1.0

        pol_probs = torch.softmax(logits / temperature, dim=-1)
        share = pol_probs @ self.policy_share  # [B, G]
        share = torch.clamp(share, min=1e-9)
        share = share / share.sum(dim=-1, keepdim=True)

        return RouterOutput(
            probs=share,
            granularity_order=tuple(GRANULARITIES),
            policy_logits=logits,
            policy_probs=pol_probs,
        )
