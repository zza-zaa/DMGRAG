# mog_rag/evaluate_hotpot_multi_noroute_nobudget.py
"""
多粒度（sent+para+doc），但关闭：
- 粒度路由器 (use_router=False)
- 预算回归器 (use_budget_regressor=False)

其它逻辑（检索、构造 prompt、后处理、评测）和 evaluate_hotpot.py 一样，
用于作为“中间 baseline”，看：
  单粒度  -> 多粒度（无 router/预算） -> 多粒度 + router + 预算 的提升分解。
"""

import json
import re
import string
from pathlib import Path
from typing import Dict, List, Tuple

from tqdm import tqdm

from .rag_pipeline import HotpotRAGPipeline


def _normalize_answer(s: str) -> str:
    if s is None:
        return ""

    def lower(text: str) -> str:
        return text.lower()

    def remove_punc(text: str) -> str:
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def remove_articles(text: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text: str) -> str:
        return " ".join(text.split())

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def _f1_score(prediction: str, ground_truth: str) -> float:
    pred_tokens = _normalize_answer(prediction).split()
    gold_tokens = _normalize_answer(ground_truth).split()

    if not pred_tokens and not gold_tokens:
        return 1.0
    if not pred_tokens or not gold_tokens:
        return 0.0

    common: Dict[str, int] = {}
    for t in pred_tokens:
        common[t] = common.get(t, 0) + 1

    num_same = 0
    for t in gold_tokens:
        if common.get(t, 0) > 0:
            num_same += 1
            common[t] -= 1

    if num_same == 0:
        return 0.0

    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


def _qa_em_f1(prediction: str, ground_truth: str) -> Tuple[float, float]:
    em = float(_normalize_answer(prediction) == _normalize_answer(ground_truth))
    f1 = _f1_score(prediction, ground_truth)
    return em, f1


def _load_hotpot_dev(hotpot_json: str, limit: int = 50) -> List[Dict[str, str]]:
    path = Path(hotpot_json)
    if not path.exists():
        raise FileNotFoundError(f"Hotpot dev 文件不存在: {path}")

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if limit is not None:
        data = data[:limit]

    examples: List[Dict[str, str]] = []
    for ex in data:
        q = ex.get("question", "").strip()
        a = ex.get("answer", "").strip()
        examples.append({"question": q, "answer": a})

    return examples


def evaluate_hotpot_dev_noroute_nobudget(
    hotpot_json: str,
    limit: int = 1500,
) -> None:
    # 关键：关闭 router 和 budget_regressor
    pipeline = HotpotRAGPipeline(
        use_router=False,
        use_budget_regressor=False,
    )

    examples = _load_hotpot_dev(hotpot_json, limit=limit)
    n = len(examples)

    total_em = 0.0
    total_f1 = 0.0

    for idx, ex in enumerate(
        tqdm(examples, desc="Evaluating Hotpot dev (multi, no router/budget)", dynamic_ncols=True)
    ):
        question = ex["question"]
        gold = ex["answer"]

        pred, debug_ctx = pipeline.answer(question, debug=True)

        print("=" * 80)
        print(f"[{idx}] Question:")
        print(question)
        print(f"[{idx}] Gold Answer:")
        print(gold)
        print(f"[{idx}] Pred Answer:")
        print(pred)

        if isinstance(debug_ctx, dict) and debug_ctx.get("top1") is not None:
            top1 = debug_ctx["top1"]
            gran = getattr(top1, "granularity", getattr(top1, "gran", "?"))
            text = getattr(top1, "text", str(top1))

            print()
            print(f"[{idx}] Top-1 Retrieved Chunk (gran={gran}):")
            print(text)

        print("=" * 80)
        print()

        em, f1 = _qa_em_f1(pred, gold)
        total_em += em
        total_f1 += f1

    avg_em = total_em / n if n > 0 else 0.0
    avg_f1 = total_f1 / n if n > 0 else 0.0
    print(f"[RESULT] N={n}  EM={avg_em:.3f}  F1={avg_f1:.3f}")


if __name__ == "__main__":
    DEFAULT_HOTPOT_JSON = "/home/peiyu/data/hotpot/hotpot_dev_distractor_v1.json"

    evaluate_hotpot_dev_noroute_nobudget(
        hotpot_json=DEFAULT_HOTPOT_JSON,
        limit=1500,
    )
