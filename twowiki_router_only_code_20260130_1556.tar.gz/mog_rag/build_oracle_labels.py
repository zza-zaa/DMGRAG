from __future__ import annotations

"""Build teacher labels for the policy-router and the budgeter scorer.

Searches over:
  - a discrete policy set (splits over {sent, para, doc})
  - a list of context budgets (tokens)

For each (question, budget_tokens) it writes one JSONL line with:
  - best_policy_id / best_policy_share
  - selected chunk ids produced by the teacher selector (BudgeterRuntime in heuristic mode)

Then you train:
  - router: classify (query_emb + budget features) -> best_policy_id
  - budget scorer: rank chunks so teacher-selected chunks score higher

Works for HotpotQA and 2WikiMultihopQA as long as `utils.get_gold_answers` works.
"""

import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from transformers import AutoTokenizer

from .config import DEV_JSON, TEST_JSON, TRAIN_JSON
from .retrieval import MultiGranRetriever, RetrievedChunk
from .utils import get_gold_answers, load_hotpot
from .policies import get_policies_from_env
from .budgeter_runtime import BudgeterRuntime


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except Exception:
        return default


def _chunk_to_ctx_block(c: RetrievedChunk, idx: int) -> str:
    title = (c.title or "").strip()
    if title:
        head = f"#### {idx}. [{c.granularity}] {title}"
    else:
        head = f"#### {idx}. [{c.granularity}]"
    return head + "\n" + (c.text or "")


def _gold_hit(golds: List[str], ctx: str) -> bool:
    ctx_l = (ctx or "").lower()
    for a in golds:
        a = (a or "").strip().lower()
        if a and a in ctx_l:
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, default="dev", choices=["train", "dev", "test"])
    ap.add_argument("--out", type=str, default="data/oracle_policy_v2.jsonl")
    ap.add_argument("--limit", type=int, default=20000)
    ap.add_argument(
        "--budgets",
        type=str,
        default=os.getenv("ORACLE_BUDGETS", "1024,2048,3072,4096,5200"),
        help="comma-separated token budgets to search",
    )
    ap.add_argument("--stage1_topk", type=int, default=_env_int("STAGE1_TOTAL_TOPK", 160))
    ap.add_argument("--rerank_top_m", type=int, default=_env_int("RERANK_TOP_M", 160))
    ap.add_argument("--total_topk", type=int, default=_env_int("TOTAL_TOPK", 120))
    ap.add_argument("--max_ctx_chunks", type=int, default=_env_int("MAX_CTX_CHUNKS", 64))
    ap.add_argument("--use_reranker", type=int, default=int(os.getenv("USE_RERANKER", "0")))
    ap.add_argument("--max_policies", type=int, default=0, help="0=use full policy set")
    args = ap.parse_args()

    if args.split == "train":
        data_path = str(TRAIN_JSON)
    elif args.split == "test":
        data_path = str(TEST_JSON)
    else:
        data_path = str(DEV_JSON)

    # robust loader for json (Hotpot/2Wiki) and jsonl (if you created it)
    if data_path.endswith(".jsonl"):
        examples: List[Dict[str, Any]] = []
        with open(data_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                examples.append(json.loads(line))
                if args.limit and len(examples) >= int(args.limit):
                    break
    else:
        import inspect
        sig = inspect.signature(load_hotpot)
        if 'limit' in sig.parameters:
            examples = load_hotpot(data_path, limit=args.limit)
        else:
            examples = load_hotpot(data_path)
            if args.limit and len(examples) > int(args.limit):
                examples = examples[: int(args.limit)]

    llm_path = os.getenv("LLM_PATH", "").strip()
    if not llm_path:
        raise RuntimeError("LLM_PATH is required (token counting)")

    # tokenizer for token counting (should match inference)
    try:
        tok = AutoTokenizer.from_pretrained(llm_path, trust_remote_code=True)
    except Exception:
        tok = AutoTokenizer.from_pretrained(llm_path, trust_remote_code=True, use_fast=False)

    def count_tokens(s: str) -> int:
        if not s:
            return 0
        try:
            return int(len(tok.encode(s, add_special_tokens=False)))
        except Exception:
            return int(len(s.split()))

    budgets = [int(x) for x in str(args.budgets).split(",") if x.strip()]
    if not budgets:
        raise ValueError("--budgets parsed to empty list")

    policies = get_policies_from_env()
    if args.max_policies and len(policies) > int(args.max_policies):
        policies = policies[: int(args.max_policies)]

    retriever = MultiGranRetriever(split=args.split, use_reranker=bool(args.use_reranker), router=None)

    # Teacher selector in heuristic mode (no ckpt)
    teacher = BudgeterRuntime(emb_dim=768, device="cpu", ckpt_path=None, debug=False)
    teacher.set_token_counter(count_tokens)
    teacher.set_chunk_formatter(lambda c: _chunk_to_ctx_block(c, 1))

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with out_path.open("w", encoding="utf-8") as w:
        for ex in examples:
            q = str(ex.get("question", ""))
            if not q:
                continue
            golds = get_gold_answers(ex)

            for b in budgets:
                best: Optional[Dict[str, Any]] = None

                for pid, pol in enumerate(policies):
                    candidates, alloc = retriever.retrieve_stagewise(
                        query=q,
                        budget_tokens=b,
                        stage1_total_topk=int(args.stage1_topk),
                        rerank_top_m=int(args.rerank_top_m),
                        prior_share=pol.share,
                    )
                    if not candidates:
                        continue
                    if len(candidates) > int(args.total_topk):
                        candidates = candidates[: int(args.total_topk)]

                    selected, info = teacher.select(
                        question=q,
                        candidates=candidates,
                        budget_tokens=b,
                        max_ctx_chunks=int(args.max_ctx_chunks),
                    )

                    ctx = "\n".join([_chunk_to_ctx_block(c, i + 1) for i, c in enumerate(selected)])
                    ans_hit = 1.0 if _gold_hit(golds, ctx) else 0.0
                    used = int(info.get("used_tokens", 0))

                    item = dict(
                        budget_tokens=int(b),
                        best_policy_id=int(pid),
                        best_policy_name=str(pol.name),
                        best_policy_share=dict(pol.share),
                        ans_hit=float(ans_hit),
                        used_tokens=int(used),
                        alloc=alloc,
                        selected_ids=[
                            dict(granularity=c.granularity, chunk_id=int(c.chunk_id), title=(c.title or ""))
                            for c in selected
                        ],
                        teacher_info=info,
                    )

                    if best is None:
                        best = item
                    else:
                        if item["ans_hit"] > best["ans_hit"]:
                            best = item
                        elif item["ans_hit"] == best["ans_hit"] and item["used_tokens"] < best["used_tokens"]:
                            best = item

                if best is None:
                    continue

                rec = dict(
                    qid=ex.get("_id", ex.get("id", None)),
                    split=args.split,
                    question=q,
                    answers=golds,
                    budget_tokens=int(b),
                    teacher=best,
                )
                w.write(json.dumps(rec, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
