# mog_rag/dump_llm_contexts.py
import os
import json
import random
import argparse
from typing import Any, Dict

from mog_rag.rag_pipeline import HotpotRAGPipeline
from mog_rag.config import DEV_JSON, TEST_JSON, TRAIN_JSON


def load_split(split: str):
    split = split.lower()
    if split == "dev":
        path = DEV_JSON
    elif split == "test":
        path = TEST_JSON
    elif split == "train":
        path = TRAIN_JSON
    else:
        raise ValueError(f"unknown split={split}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data


def pick_gold(ex: Dict[str, Any]) -> str:
    # 兼容不同字段名
    for k in ["answer", "gold", "gold_answer", "target", "label"]:
        if k in ex and ex[k]:
            return ex[k]
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="dev")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--out", required=True)
    ap.add_argument("--limit", type=int, default=0, help="optional: use only first LIMIT samples (0 means no limit)")
    args = ap.parse_args()

    data = load_split(args.split)
    if args.limit and args.limit > 0:
        data = data[: args.limit]

    random.seed(args.seed)
    idxs = list(range(len(data)))
    random.shuffle(idxs)
    idxs = idxs[: args.n]

    pipe = HotpotRAGPipeline()

    with open(args.out, "w", encoding="utf-8") as w:
        for rank, i in enumerate(idxs):
            ex = data[i]
            q = ex.get("question", "")
            gold = pick_gold(ex)
            pred, dbg = pipe.answer(q, debug=True)

            chunks = []
            for c in dbg.get("selected_chunks", []):
                text = (getattr(c, "text", "") or "")
                chunks.append({
                    "granularity": getattr(c, "granularity", None),
                    "title": getattr(c, "title", None),
                    "ex_id": getattr(c, "ex_id", None),
                    "dense_score": float(getattr(c, "dense_score", 0.0) or 0.0),
                    "rerank_score": float(getattr(c, "rerank_score", 0.0) or 0.0),
                    "text": text,
                })

            rec = {
                "rank": rank,
                "idx": i,
                "qid": ex.get("id", ex.get("_id", ex.get("qid", ""))),
                "question": q,
                "gold": gold,
                "pred": pred,

                "ctx_budget_requested": dbg.get("ctx_budget_requested"),
                "ctx_budget_effective": dbg.get("ctx_budget_effective"),
                "budget_tokens_pred": dbg.get("budget_tokens_pred"),
                "prior_share": dbg.get("prior_share"),
                "gran_counts": dbg.get("gran_counts"),

                "dedup_removed_candidates": dbg.get("dedup_removed_candidates"),
                "dedup_removed_selected": dbg.get("dedup_removed_selected"),
                "total_ctx_tokens": dbg.get("total_ctx_tokens"),
                "ctx_token_stats": dbg.get("ctx_token_stats"),

                "selected_n": dbg.get("n_selected_dedup", len(chunks)),
                "selected_chunks": chunks,
            }

            w.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"[OK] wrote: {args.out} (n={len(idxs)})")


if __name__ == "__main__":
    main()
