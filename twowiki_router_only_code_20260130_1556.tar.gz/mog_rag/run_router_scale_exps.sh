#!/usr/bin/env bash
# 顺序跑“累积训练”的路由器缩放实验：
# N = 1w, 2w, 5w, full(-1)
# 总轮数目标：E_target = 1, 3, 5, 10
# 对于每个 N：
#   - 先删除旧的 router_mlp.pt，确保从头开始
#   - 按顺序：E=1,3,5,10
#       * 计算当前需要额外训练的轮数 delta = E_target - prev_E
#       * 若 prev_E==0：从头训 delta 轮
#         否则：在 router_mlp.pt 上用 --init_from 继续训 delta 轮
#       * 每个 E_target 之后：
#           - 备份 ckpt 为 router_mlp_E{E_target}_N{N_TAG}.pt
#           - 跑一次全量 dev 评测（只用路由器，不用预算器）

set -euo pipefail

ROOT="/home/peiyu/router_only_best"
PYTHON="/home/peiyu/envs/brmog_gpu/bin/python"
DEVICE="6"
BUDGET="1024"

cd "$ROOT"

# 避免 PYTHONPATH 未定义导致错误
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"

mkdir -p logs

# 训练样本数：10000, 20000, 50000, full(-1 表示全量)
NS=(10000 20000 50000 -1)
# 目标“总轮数”（累积）：1, 3, 5, 10
E_TARGETS=(1 3 5 10)

for N in "${NS[@]}"; do
  # N_TAG 用来区分 full/数字
  if [[ "$N" -gt 0 ]]; then
    N_TAG="$N"
    MAX_EX="--max_examples ${N}"
  else
    N_TAG="full"
    MAX_EX="--max_examples -1"
  fi

  echo "============================================="
  echo "### 开始 N=${N_TAG} 的一整组累积训练 ###"
  echo "============================================="

  # 每个 N 重新从头训练：先删掉旧的 router_mlp.pt
  rm -f router_mlp.pt

  prev_E=0

  for E_target in "${E_TARGETS[@]}"; do
    # 需要在当前 ckpt 上追加训练的轮数
    delta=$((E_target - prev_E))
    if (( delta <= 0 )); then
      continue
    fi

    echo "---------------------------------------------"
    echo ">>> N=${N_TAG}, 累积到 E=${E_target} (本次追加 ${delta} 轮)"
    echo "---------------------------------------------"

    TRAIN_LOG="logs/train_router_E${E_target}_N${N_TAG}.log"
    EVAL_LOG="logs/hotpot_dev_multi_router_only_B${BUDGET}_E${E_target}_N${N_TAG}_full.log"
    CKPT_SAVE="router_mlp_E${E_target}_N${N_TAG}.pt"

    # 是否从已有 ckpt 继续训练
    INIT_ARG=""
    if (( prev_E > 0 )); then
      # 上一次应该已经产生了 router_mlp.pt
      if [[ -f router_mlp.pt ]]; then
        INIT_ARG="--init_from router_mlp.pt"
      else
        echo "[WARN] 预期存在的 router_mlp.pt 未找到，当前轮将从头训练。"
      fi
    fi

    # 1) 训练 delta 轮
    CUDA_VISIBLE_DEVICES=${DEVICE} \
    "${PYTHON}" -m mog_rag.train_router \
      --device cuda \
      --epochs "${delta}" \
      ${MAX_EX} \
      --topk_per_gran 32 \
      --temp 0.5 \
      ${INIT_ARG} \
      > "${TRAIN_LOG}" 2>&1

    # 2) 备份当前 router 权重
    if [[ -f router_mlp.pt ]]; then
      cp router_mlp.pt "${CKPT_SAVE}"
    else
      echo "[WARN] router_mlp.pt 不存在，可能训练失败，请查看 ${TRAIN_LOG}"
    fi

    # 3) 全量评测（不使用预算器）
    echo ">>> Evaluate router: N=${N_TAG}, total epochs=${E_target} (full dev)"
    CUDA_VISIBLE_DEVICES=${DEVICE} \
    USE_ROUTER=1 USE_BUDGET=0 CTX_BUDGET=${BUDGET} \
    "${PYTHON}" -m mog_rag.evaluate_hotpot \
      --limit 0 \
      > "${EVAL_LOG}" 2>&1

    echo ">>> Result summary (from ${EVAL_LOG}):"
    grep "\[RESULT\]" "${EVAL_LOG}" || echo "[WARN] 未找到 [RESULT] 行，请检查日志。"
    echo

    # 更新“当前总轮数”
    prev_E=${E_target}
  done
done

echo "所有 router 累积训练实验已跑完。权重文件 router_mlp_E*_N*.pt 和日志在 logs/ 下。"
